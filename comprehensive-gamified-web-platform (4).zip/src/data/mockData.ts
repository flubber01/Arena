import { LeagueInfo, InvestmentPackage, LeaderboardUser, CryptoStakingPool, SurveyOffer, LootChest, NftItem } from '../types';

export const LEAGUES: LeagueInfo[] = [
  {
    name: 'Bronze',
    minInvestment: 0,
    minLevel: 1,
    roiBonus: 0,
    coinMultiplier: 1.0,
    color: 'text-amber-600 border-amber-600/30',
    bgGradient: 'from-amber-950/40 via-slate-900 to-slate-900',
    badgeUrl: '🥉',
    description: 'Der Einstieg in die Nexus Arena. Sammle Coins und steige auf!'
  },
  {
    name: 'Silver',
    minInvestment: 500,
    minLevel: 5,
    roiBonus: 10,
    coinMultiplier: 1.15,
    color: 'text-slate-300 border-slate-300/30',
    bgGradient: 'from-slate-800/50 via-slate-900 to-slate-900',
    badgeUrl: '🥈',
    description: 'Erweiterte Stufe mit +10% ROI-Boost und 1.15x Coin-Multiplikator.'
  },
  {
    name: 'Gold',
    minInvestment: 2500,
    minLevel: 15,
    roiBonus: 25,
    coinMultiplier: 1.35,
    color: 'text-yellow-400 border-yellow-400/40',
    bgGradient: 'from-yellow-950/50 via-slate-900 to-slate-900',
    badgeUrl: '🥇',
    description: 'Elite-Status. +25% höherer ROI und exklusive tägliche VIP-Spins.'
  },
  {
    name: 'Diamond',
    minInvestment: 10000,
    minLevel: 30,
    roiBonus: 50,
    coinMultiplier: 1.6,
    color: 'text-cyan-400 border-cyan-400/40',
    bgGradient: 'from-cyan-950/50 via-slate-900 to-slate-900',
    badgeUrl: '💎',
    description: 'Für wahre Krypto-Giganten. +50% ROI-Ausschüttung & 1.6x Multiplikator.'
  },
  {
    name: 'Master',
    minInvestment: 25000,
    minLevel: 42,
    roiBonus: 80,
    coinMultiplier: 2.0,
    color: 'text-purple-400 border-purple-400/40',
    bgGradient: 'from-purple-950/50 via-slate-900 to-slate-900',
    badgeUrl: '👑',
    description: 'Meisterklasse der Investoren. Verdoppelte Coin-Gewinne in allen Minispielen!'
  },
  {
    name: 'Apex',
    minInvestment: 50000,
    minLevel: 50,
    roiBonus: 120,
    coinMultiplier: 3.0,
    color: 'text-rose-500 border-rose-500/50',
    bgGradient: 'from-rose-950/60 via-slate-900 to-slate-900',
    badgeUrl: '⚡',
    description: 'Die absolute Spitze. +120% ROI-Ausschüttung, 3x Multiplikator & CEO-Support.'
  }
];

export const INVESTMENT_PACKAGES: InvestmentPackage[] = [
  {
    id: 'starter',
    name: 'Starter Tier',
    subtitle: 'Perfekt für Einsteiger',
    minAmount: 50,
    maxAmount: 499,
    baseRoi: 115,
    durationDays: 7,
    description: 'Sichere Rendite mit kurzer Laufzeit zum Kennenlernen des Nexus-Ökosystems.',
    features: [
      '115% garantierte Basis-Ausschüttung',
      '7 Tage Staking-Sperrfrist',
      'Schaltet Silber-Liga-Fortschritt frei',
      '+5 Freispiele für das Glücksrad'
    ],
    color: 'from-blue-600 to-cyan-500'
  },
  {
    id: 'pro',
    name: 'Professional Pool',
    subtitle: 'Der beliebteste Wachstumsplan',
    minAmount: 500,
    maxAmount: 2499,
    baseRoi: 145,
    durationDays: 14,
    description: 'Beschleunigtes Wachstum durch Zinseszins-Effekte und mittlere Laufzeit.',
    popular: true,
    badge: 'Bestseller',
    features: [
      '145% garantierte Basis-Ausschüttung',
      '14 Tage Staking-Sperrfrist',
      'Sofortiger Gold-Liga Boost möglich',
      '+15 Freispiele & 5.000 Bonus Coins',
      'Priorisierter Auszahlungsservice'
    ],
    color: 'from-cyan-500 to-teal-400'
  },
  {
    id: 'elite',
    name: 'Elite Syndicate',
    subtitle: 'Für ambitionierte Krypto-Anleger',
    minAmount: 2500,
    maxAmount: 9999,
    baseRoi: 185,
    durationDays: 30,
    description: 'Maximiere deine Gewinnausschüttung mit dem Premium-Liquiditätspool.',
    features: [
      '185% garantierte Basis-Ausschüttung',
      '30 Tage Staking-Sperrfrist',
      'Garantiertes Diamond-Tier Upgrade',
      '+30 Freispiele & 25.000 Bonus Coins',
      'Wöchentlicher Airdrop-Zuschlag'
    ],
    color: 'from-amber-500 to-yellow-400'
  },
  {
    id: 'whale',
    name: 'Whale Apex Fund',
    subtitle: 'Maximale prozentuale Ausschüttung',
    minAmount: 10000,
    maxAmount: 100000,
    baseRoi: 240,
    durationDays: 60,
    description: 'Der institutionelle Hochrendite-Plan mit maximaler Hebelwirkung und VIP-Status.',
    badge: 'Maximum ROI',
    features: [
      '240% garantierte Basis-Ausschüttung',
      '60 Tage Staking-Sperrfrist',
      'Master & Apex Liga Privilegien',
      '+100 Freispiele & 100.000 Bonus Coins',
      'Persönlicher Account Manager 24/7',
      'Exklusive Nexus Merchandise Box'
    ],
    color: 'from-purple-600 to-pink-500'
  }
];

export const TOP_10_CRYPTO_POOLS: CryptoStakingPool[] = [
  { id: 'btc', coin: 'BTC', name: 'Bitcoin High-Yield', icon: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png?v=029', minAmount: 100, maxAmount: 50000, roi: 25.4, durationDays: 30, color: 'from-amber-500 to-yellow-500', popular: true },
  { id: 'eth', coin: 'ETH', name: 'Ethereum Liquid Stake', icon: 'https://cryptologos.cc/logos/ethereum-eth-logo.png?v=029', minAmount: 100, maxAmount: 50000, roi: 32.8, durationDays: 30, color: 'from-indigo-500 to-purple-500', popular: true },
  { id: 'sol', coin: 'SOL', name: 'Solana Velocity Pool', icon: 'https://cryptologos.cc/logos/solana-sol-logo.png?v=029', minAmount: 50, maxAmount: 25000, roi: 54.2, durationDays: 14, color: 'from-purple-500 to-emerald-500', popular: true },
  { id: 'bnb', coin: 'BNB', name: 'Binance Smart Stake', icon: 'https://cryptologos.cc/logos/bnb-bnb-logo.png?v=029', minAmount: 50, maxAmount: 25000, roi: 41.5, durationDays: 14, color: 'from-yellow-400 to-amber-500' },
  { id: 'xrp', coin: 'XRP', name: 'Ripple Ripple Liquidity', icon: 'https://cryptologos.cc/logos/xrp-xrp-logo.png?v=029', minAmount: 50, maxAmount: 10000, roi: 28.6, durationDays: 14, color: 'from-blue-500 to-cyan-500' },
  { id: 'ada', coin: 'ADA', name: 'Cardano Eco Pool', icon: 'https://cryptologos.cc/logos/cardano-ada-logo.png?v=029', minAmount: 50, maxAmount: 10000, roi: 35.0, durationDays: 30, color: 'from-blue-600 to-indigo-600' },
  { id: 'avax', coin: 'AVAX', name: 'Avalanche Glacier', icon: 'https://cryptologos.cc/logos/avalanche-avax-logo.png?v=029', minAmount: 50, maxAmount: 20000, roi: 48.9, durationDays: 14, color: 'from-red-500 to-rose-500' },
  { id: 'doge', coin: 'DOGE', name: 'Dogecoin Meme Vault', icon: 'https://cryptologos.cc/logos/dogecoin-doge-logo.png?v=029', minAmount: 25, maxAmount: 10000, roi: 68.4, durationDays: 7, color: 'from-amber-400 to-yellow-300' },
  { id: 'dot', coin: 'DOT', name: 'Polkadot Parachain', icon: 'https://cryptologos.cc/logos/polkadot-new-dot-logo.png?v=029', minAmount: 50, maxAmount: 15000, roi: 39.2, durationDays: 30, color: 'from-pink-500 to-purple-600' },
  { id: 'link', coin: 'LINK', name: 'Chainlink Oracle Node', icon: 'https://cryptologos.cc/logos/chainlink-link-logo.png?v=029', minAmount: 50, maxAmount: 15000, roi: 44.0, durationDays: 30, color: 'from-blue-600 to-blue-400' },
];

export const SURVEY_OFFERS: SurveyOffer[] = [
  { id: 's1', provider: 'BitLabs Market', title: 'Krypto-Investitionsverhalten 2026', timeMin: 5, rewardCoins: 12500, rewardUsd: 12.50, completed: false, rating: 4.8 },
  { id: 's2', provider: 'CPX Research', title: 'Fintech & Mobile Banking Umfrage', timeMin: 12, rewardCoins: 28000, rewardUsd: 28.00, completed: false, rating: 4.9 },
  { id: 's3', provider: 'inBrain.ai', title: 'DeFi & DEX Trading Präferenzen', timeMin: 8, rewardCoins: 18500, rewardUsd: 18.50, completed: true, rating: 4.7 },
  { id: 's4', provider: 'Pollfish Offerwall', title: 'KI & Automatisierung im Alltag', timeMin: 15, rewardCoins: 45000, rewardUsd: 45.00, completed: false, rating: 5.0 },
  { id: 's5', provider: 'Wannads Premium', title: 'Gaming & Minispiel-Nutzung', timeMin: 3, rewardCoins: 7500, rewardUsd: 7.50, completed: false, rating: 4.5 },
];

export const LOOT_CHESTS: LootChest[] = [
  { id: 'c_bronze', name: 'Bronze Novice Truhe', tier: 'Bronze', minInvest: 0, icon: '📦', color: 'from-amber-800 to-amber-950', guaranteedLoot: ['2.500 Coins', '+50 XP', '1 Glücksrad Spin'], opened: false },
  { id: 'c_silver', name: 'Silver Elite Truhe', tier: 'Silver', minInvest: 500, icon: '🎁', color: 'from-slate-400 to-slate-600', guaranteedLoot: ['12.500 Coins', '+300 XP', '5 Glücksrad Spins', 'Common NFT Boost'], opened: false },
  { id: 'c_gold', name: 'Gold Master Truhe', tier: 'Gold', minInvest: 2500, icon: '🏆', color: 'from-yellow-400 to-amber-600', guaranteedLoot: ['50.000 Coins', '+1.200 XP', '15 Glücksrad Spins', 'Rare NFT Boost'], opened: true },
  { id: 'c_diamond', name: 'Diamond Gigant Truhe', tier: 'Diamond', minInvest: 10000, icon: '💎', color: 'from-cyan-400 to-blue-600', guaranteedLoot: ['250.000 Coins', '+5.000 XP', '50 Glücksrad Spins', 'Epic NFT Pass', '$100 Staking Voucher'], opened: false },
  { id: 'c_apex', name: 'Apex God Truhe', tier: 'Apex', minInvest: 50000, icon: '⚡', color: 'from-rose-500 to-purple-600', guaranteedLoot: ['1.000.000 Coins', '+25.000 XP', '100 Glücksrad Spins', 'Legendary Apex NFT', '$500 Staking Voucher', 'VIP Account Manager'], opened: false },
];

export const INITIAL_NFTS: NftItem[] = [
  { id: 'nft_1', name: 'CyberPunk Titan #8842', image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80', rarity: 'Legendary', roiBoost: 25, staked: true, valueUsd: 1250 },
  { id: 'nft_2', name: 'Apex Staker Pass #019', image: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=400&auto=format&fit=crop&q=80', rarity: 'Epic', roiBoost: 15, staked: false, valueUsd: 450 },
  { id: 'nft_3', name: 'Quantum Yield Dragon #99', image: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?w=400&auto=format&fit=crop&q=80', rarity: 'Mythic', roiBoost: 35, staked: false, valueUsd: 2800 },
  { id: 'nft_4', name: 'Nexus Genesis Key #402', image: 'https://images.unsplash.com/photo-1633167606207-d840b5070fc2?w=400&auto=format&fit=crop&q=80', rarity: 'Rare', roiBoost: 8, staked: false, valueUsd: 150 },
];

export const INITIAL_LEADERBOARD: LeaderboardUser[] = [
  { id: '1', rank: 1, name: 'Satoshi_Nakamoto', avatar: 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=150&auto=format&fit=crop&q=80', coins: 12540300, invested: 85000, level: 50, league: 'Apex' },
  { id: '2', rank: 2, name: 'Vitalik_B', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80', coins: 9840200, invested: 62000, level: 48, league: 'Apex' },
  { id: '3', rank: 3, name: 'CryptoWhale_99', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80', coins: 7420150, invested: 45000, level: 45, league: 'Master' },
  { id: '4', rank: 4, name: 'DiamondHands', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=150&auto=format&fit=crop&q=80', coins: 5120000, invested: 32000, level: 41, league: 'Master' },
  { id: '5', rank: 5, name: 'MoonShot_Trader', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80', coins: 3890400, invested: 21000, level: 36, league: 'Diamond' },
  { id: '6', rank: 6, name: 'Elena_Rostova', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80', coins: 2650000, invested: 15500, level: 32, league: 'Diamond' },
  { id: '7', rank: 7, name: 'Felix_Nexus', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', coins: 1840000, invested: 9800, level: 28, league: 'Gold' },
  { id: '8', rank: 8, name: 'HODL_Queen', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', coins: 1250000, invested: 6500, level: 24, league: 'Gold' },
  { id: '9', rank: 9, name: 'AlphaSeeker', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', coins: 890000, invested: 3500, level: 19, league: 'Gold' },
  { id: '10', rank: 10, name: 'SolanaSurfer', avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80', coins: 620000, invested: 1800, level: 14, league: 'Silver' },
];

export const PARTNER_LOGOS = [
  { name: 'Google DSS', logo: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?w=100&auto=format&fit=crop&q=80', type: 'Cloud Security', isText: true, textLogo: 'Google DSS' },
  { name: 'KuCoin', logo: 'https://cryptologos.cc/logos/kucoin-token-kcs-logo.png?v=029', type: 'Krypto-Börse' },
  { name: 'Norton Secured', logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=100&auto=format&fit=crop&q=80', type: 'Cyber Security', isText: true, textLogo: '✔ Norton Secured' },
  { name: 'Avast Shield', logo: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=100&auto=format&fit=crop&q=80', type: 'Antivirus', isText: true, textLogo: '🛡 Avast Antivirus' },
  { name: 'Google AdSense', logo: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=100&auto=format&fit=crop&q=80', type: 'Monetization Partner', isText: true, textLogo: 'Google AdSense' },
  { name: 'Google Analytics', logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&auto=format&fit=crop&q=80', type: 'Data Partner', isText: true, textLogo: 'Google Analytics' },
  { name: 'Sparkasse', logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80', type: 'TradFi Bank', isText: true, textLogo: '🢠 Sparkasse' },
  { name: 'Deutsche Börse Group', logo: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?w=100&auto=format&fit=crop&q=80', type: 'Börse', isText: true, textLogo: 'DAX | Deutsche Börse' },
  { name: 'Nasdaq Exchange', logo: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=100&auto=format&fit=crop&q=80', type: 'Börse', isText: true, textLogo: 'NASDAQ' },
  { name: 'PancakeSwap', logo: 'https://cryptologos.cc/logos/pancakeswap-cake-logo.png?v=029', type: 'DEX' },
  { name: 'Uniswap', logo: 'https://cryptologos.cc/logos/uniswap-uni-logo.png?v=029', type: 'DEX' },
  { name: 'BlackRock', logo: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f929d4?w=100&auto=format&fit=crop&q=80', type: 'Asset Manager', isText: true, textLogo: 'BLACKROCK' },
  { name: 'Binance', logo: 'https://cryptologos.cc/logos/bnb-bnb-logo.png?v=029', type: 'Krypto-Börse' },
  { name: 'Coinbase', logo: 'https://cryptologos.cc/logos/coinbase-coin-logo.png?v=029', type: 'Krypto-Börse' },
  { name: 'Kraken', logo: 'https://cryptologos.cc/logos/kraken-krak-logo.png?v=029', type: 'Krypto-Börse' },
  { name: 'Bybit', logo: 'https://cryptologos.cc/logos/bybit-logo.png?v=029', type: 'Krypto-Börse' },
  { name: 'Polygon', logo: 'https://cryptologos.cc/logos/polygon-matic-logo.png?v=029', type: 'Blockchain' },
  { name: 'Solana Foundation', logo: 'https://cryptologos.cc/logos/solana-sol-logo.png?v=029', type: 'Ecosystem Partner' },
];

export const SHARE_TEMPLATES = [
  {
    platform: 'Twitter / X',
    icon: 'Twitter',
    text: '🚀 BOOM! Ich habe gerade das nächste Level auf der NEXUS COIN Arena erreicht! Mein ROI steigt und die Minispiele brennen! 🔥 Melde dich jetzt an und sichere dir deinen FreeLaunch Airdrop! #Crypto #NexusCoin #Staking #Airdrop #BigWin',
    color: 'bg-[#1DA1F2] hover:bg-[#1a8cd8]'
  },
  {
    platform: 'Telegram',
    icon: 'Send',
    text: '🔥 Unglaublich! Schaut euch meine Stats auf NEXUS COIN an. Tägliche Login-Boni, Glücksrad & gigantische Staking-Renditen je nach Level! Komm in mein Team: https://nexus-coin-arena.io/join?ref=VIP_NEXUS',
    color: 'bg-[#0088cc] hover:bg-[#0077b5]'
  },
  {
    platform: 'WhatsApp',
    icon: 'MessageCircle',
    text: 'Hey! Ich spiele und stake gerade auf NEXUS COIN. Hab schon richtig viele Coins im Glücksrad und den Minispielen gewonnen! Hol dir deine gratis Coins im Daily Login: https://nexus-coin-arena.io/join?ref=VIP_NEXUS',
    color: 'bg-[#25D366] hover:bg-[#20ba5c]'
  },
  {
    platform: 'Link kopieren',
    icon: 'Copy',
    text: 'https://nexus-coin-arena.io/join?ref=VIP_NEXUS_BONUS_500',
    color: 'bg-slate-700 hover:bg-slate-600'
  }
];
