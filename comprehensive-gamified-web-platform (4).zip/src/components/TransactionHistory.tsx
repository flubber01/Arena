import React, { useState } from 'react';
import { UserState } from '../types';
import { History, ArrowDownLeft, ArrowUpRight, Clock, AlertCircle } from 'lucide-react';

interface TransactionHistoryProps {
  user: UserState;
}

export const TransactionHistory: React.FC<TransactionHistoryProps> = ({ user }) => {
  const [filter, setFilter] = useState<'all' | 'earn' | 'spend' | 'stake'>('all');

  const filteredTxs = filter === 'all' 
    ? user.transactions 
    : user.transactions.filter(t => t.type === filter || (filter === 'earn' && t.type === 'claim'));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-blue-500 via-indigo-600 to-purple-600 text-white shadow-lg shadow-blue-500/20">
            <History className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Transaktions- & Aktivitätsverlauf
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Dein lückenloses, dezentrales Nexus-Logbuch. Verfolge jede Kontobewegung, Staking-Auszahlung und jeden Minispiel-Erfolg in Echtzeit.
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar">
          {(['all', 'earn', 'spend', 'stake'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all uppercase tracking-wider whitespace-nowrap ${
                filter === tab ? 'bg-cyan-500 text-slate-950 font-extrabold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab === 'all' ? 'Alle Buchungen' : tab === 'earn' ? 'Einnahmen' : tab === 'spend' ? 'Ausgaben' : 'Staking'}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions Table / List */}
      <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl border border-blue-500/30 relative overflow-hidden shadow-2xl shadow-blue-500/10">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        {filteredTxs.length === 0 ? (
          <div className="text-center py-16 bg-slate-950/60 rounded-2xl border border-slate-800/80">
            <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-300 text-sm font-bold">Keine Transaktionen in dieser Kategorie gefunden.</p>
            <p className="text-xs text-slate-500 mt-1">Spiele Minispiele oder schließe Staking-Verträge ab, um dein Logbuch zu füllen.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-4 px-4">Art</th>
                  <th className="py-4 px-4">Titel / Verwendungszweck</th>
                  <th className="py-4 px-4">Transaktions-ID</th>
                  <th className="py-4 px-4">Zeitpunkt</th>
                  <th className="py-4 px-4 text-right">Betrag</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-sm">
                {filteredTxs.map((tx) => {
                  const isEarn = tx.type === 'earn' || tx.type === 'claim';
                  const isSpend = tx.type === 'spend';

                  return (
                    <tr key={tx.id} className="transition-colors hover:bg-slate-800/40">
                      <td className="py-4 px-4">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                          isEarn ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                          isSpend ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                          'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}>
                          {isEarn ? <ArrowDownLeft className="w-4 h-4" /> : isSpend ? <ArrowUpRight className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                        </div>
                      </td>

                      <td className="py-4 px-4 font-extrabold text-white font-['Space_Grotesk'] text-base">
                        {tx.title}
                      </td>

                      <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-slate-400 text-xs">
                        {tx.id}
                      </td>

                      <td className="py-4 px-4 text-slate-400 text-xs">
                        {new Date(tx.timestamp).toLocaleString('de-DE')}
                      </td>

                      <td className={`py-4 px-4 text-right font-['Space_Grotesk'] font-extrabold text-base ${
                        isEarn ? 'text-emerald-400' : isSpend ? 'text-rose-400' : 'text-amber-400'
                      }`}>
                        {isEarn ? '+' : isSpend ? '-' : ''}{tx.amount.toLocaleString()} <span className="text-xs text-slate-400 font-bold">{tx.currency}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
