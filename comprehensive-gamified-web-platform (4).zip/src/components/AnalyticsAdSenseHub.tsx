import React, { useState } from 'react';
import { UserState } from '../types';
import { BarChart3, DollarSign, Users, Activity, ShieldCheck, CheckCircle2, Gift, Sparkles, Globe } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AnalyticsAdSenseHubProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const AnalyticsAdSenseHub: React.FC<AnalyticsAdSenseHubProps> = ({ setUser, addToast }) => {
  const [adShareClaimed, setAdShareClaimed] = useState<boolean>(false);

  // Simulated Google Analytics & AdSense Live Data
  const stats = {
    dailyActiveUsers: 184250,
    pageViewsToday: 1420500,
    adSenseRevenueToday: 14842.50,
    userSharePool: 8905.50, // 60% redistributed
    serverUptime: '99.99%',
    dssStatus: 'Google DSS SecOps Level 4',
    nortonStatus: 'Norton SafeWeb Clean',
    avastStatus: 'Avast Web Shield Verified'
  };

  const handleClaimAdShare = () => {
    if (adShareClaimed) {
      addToast('error', 'Bereits abgeholt', 'Du hast deinen heutigen AdSense Werbeanteil bereits geclaimt!');
      return;
    }

    confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });

    // Reward: 25.000 Coins & +500 XP
    const rewardCoins = 25000;
    const rewardXp = 500;

    setUser(prev => {
      const newCoins = prev.coins + rewardCoins;
      const newXp = prev.xp + rewardXp;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let currentXp = newXp;
      while (currentXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        currentXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: '📊 Google AdSense Revenue Share',
        amount: rewardCoins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: currentXp,
        level: newLevel,
        nextLevelXp,
        transactions: [newTx, ...prev.transactions]
      };
    });

    setAdShareClaimed(true);
    addToast('drop', '📊 AdSense Anteil geclaimt!', `Du hast +25.000 Coins ($25.00 USD) aus dem Werbepool erhalten.`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white shadow-lg shadow-blue-500/20">
            <BarChart3 className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Google Analytics & AdSense Revenue Share
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Wir teilen unsere täglichen Google AdSense Werbeeinnahmen transparent mit der Community. Verfolge unsere Live-Analysen und sichere dir deinen Anteil!
            </p>
          </div>
        </div>

        {/* AdSense Claim Button */}
        <button
          onClick={handleClaimAdShare}
          disabled={adShareClaimed}
          className={`flex items-center gap-2.5 px-6 py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] ${
            adShareClaimed 
              ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
              : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-emerald-500/30 animate-pulse'
          }`}
        >
          <Gift className="w-5 h-5 fill-slate-950" />
          <span>{adShareClaimed ? 'Werbepool geclaimt ✓' : '💰 Heutigen AdSense Werbeanteil abholen'}</span>
        </button>
      </div>

      {/* --- SECTION 1: LIVE PLATFORM ANALYTICS --- */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-blue-500/30 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tägliche Nutzer (GA4)</span>
            <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <Users className="w-5 h-5 text-blue-400" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
              {stats.dailyActiveUsers.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">Live</span>
          </div>
          <p className="text-xs text-slate-400">Verifizierte Sessions heute</p>
        </div>

        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-cyan-500/30 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Seitenaufrufe Heute</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
              <Activity className="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
              {stats.pageViewsToday.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">+14.2%</span>
          </div>
          <p className="text-xs text-slate-400">Google Analytics 4 Stream</p>
        </div>

        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-emerald-500/30 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">AdSense Einnahmen</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <DollarSign className="w-5 h-5 text-emerald-400" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-3xl sm:text-4xl font-extrabold text-emerald-400 font-['Space_Grotesk'] tracking-tight">
              ${stats.adSenseRevenueToday.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">Heute</span>
          </div>
          <p className="text-xs text-slate-400">Google AdSense Publisher Pool</p>
        </div>

        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Ausschüttungspool</span>
            <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20">
              <Gift className="w-5 h-5 text-purple-400" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-3xl sm:text-4xl font-extrabold text-purple-400 font-['Space_Grotesk'] tracking-tight">
              ${stats.userSharePool.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">60% Share</span>
          </div>
          <p className="text-xs text-slate-400">Wird an Staker verteilt</p>
        </div>

      </div>

      {/* --- SECTION 2: GOOGLE DSS, NORTON & AVAST SECURITY HUB --- */}
      <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border-2 border-cyan-500/50 mb-16 relative overflow-hidden shadow-2xl shadow-cyan-500/10">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-3 mb-6 border-b border-slate-800 pb-4">
          <ShieldCheck className="w-8 h-8 text-cyan-400 animate-pulse" />
          <div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
              Geprüfte Sicherheits- & Cloud-Infrastruktur
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Unsere Server und Liquiditätspools sind durch modernste Antivirus-, Cloud- und Verschlüsselungstechnologien zertifiziert.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Google DSS */}
          <div className="bg-slate-950/80 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between shadow-inner group hover:border-blue-500/50 transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-black bg-blue-500/20 text-blue-400 border border-blue-500/30 px-3 py-1 rounded-full uppercase tracking-wider">
                  Google Cloud
                </span>
                <Globe className="w-6 h-6 text-blue-400" />
              </div>
              <h4 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Google DSS Security</h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-6 font-medium">
                Unsere Plattform nutzt Google Digital Signature Security (DSS) und SecOps Level 4 zur Abwehr von DDoS- und Sybil-Attacken.
              </p>
            </div>
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-emerald-400 font-bold">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Uptime: {stats.serverUptime}</span>
              </div>
              <span className="text-blue-400 font-mono">DSS-CERT-2026</span>
            </div>
          </div>

          {/* Norton Secured */}
          <div className="bg-slate-950/80 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between shadow-inner group hover:border-yellow-500/50 transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-black bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 px-3 py-1 rounded-full uppercase tracking-wider">
                  Norton LifeLock
                </span>
                <ShieldCheck className="w-6 h-6 text-yellow-400" />
              </div>
              <h4 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Norton Secured</h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-6 font-medium">
                Tägliche Malware-Scans durch Norton SafeWeb garantieren absolute Sicherheit für deine hinterlegten Wallets und User-IDs.
              </p>
            </div>
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-emerald-400 font-bold">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>SafeWeb Clean</span>
              </div>
              <span className="text-yellow-400 font-mono">NORTON-8842</span>
            </div>
          </div>

          {/* Avast Antivirus */}
          <div className="bg-slate-950/80 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between shadow-inner group hover:border-purple-500/50 transition-all">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-black bg-purple-500/20 text-purple-400 border border-purple-500/30 px-3 py-1 rounded-full uppercase tracking-wider">
                  Avast Security
                </span>
                <Sparkles className="w-6 h-6 text-purple-400 animate-spin-slow" />
              </div>
              <h4 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Avast Web Shield</h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-6 font-medium">
                Echtzeit-Schutz durch den Avast Web Shield blockiert Phishing-Versuche und sichert den Datenstrom zu unseren Krypto-Börsen-Partnern (KuCoin, Binance etc.).
              </p>
            </div>
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-emerald-400 font-bold">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Shield Active</span>
              </div>
              <span className="text-purple-400 font-mono">AVAST-CLEAN</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
