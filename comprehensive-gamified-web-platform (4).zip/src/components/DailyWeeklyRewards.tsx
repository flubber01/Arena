import React, { useState } from 'react';
import { UserState } from '../types';
import { Calendar, Gift, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface DailyWeeklyRewardsProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  onOpenShare: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const DailyWeeklyRewards: React.FC<DailyWeeklyRewardsProps> = ({
  user,
  setUser,
  onOpenShare,
  addToast
}) => {
  const [claimMessage, setClaimMessage] = useState<string | null>(null);

  const dailyRewards = [
    { day: 1, coins: 500, xp: 50, spins: 1 },
    { day: 2, coins: 1000, xp: 100, spins: 1 },
    { day: 3, coins: 1800, xp: 150, spins: 2 },
    { day: 4, coins: 2800, xp: 200, spins: 2 },
    { day: 5, coins: 4000, xp: 300, spins: 3 },
    { day: 6, coins: 6000, xp: 450, spins: 4 },
    { day: 7, coins: 10000, xp: 700, spins: 5, isBig: true },
  ];

  const handleDailyClaim = () => {
    const todayStr = new Date().toISOString().split('T')[0];
    if (user.lastDailyClaim === todayStr) {
      addToast('error', 'Bereits abgeholt', 'Du hast deinen heutigen Daily Login Bonus bereits abgeholt! Komm morgen wieder.');
      return;
    }

    const nextStreak = (user.dailyStreak % 7) + 1;
    const reward = dailyRewards[nextStreak - 1];

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    setUser(prev => {
      const newCoins = prev.coins + reward.coins;
      let newXp = prev.xp + reward.xp;
      const newSpins = prev.spinsLeft + reward.spins;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `📅 Daily Login Bonus (Tag ${nextStreak})`,
        amount: reward.coins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: newXp,
        level: newLevel,
        nextLevelXp,
        spinsLeft: newSpins,
        dailyStreak: nextStreak,
        lastDailyClaim: todayStr,
        transactions: [newTx, ...prev.transactions]
      };
    });

    const msg = `🎉 Glückwunsch! Du hast Tag ${nextStreak} abgeholt: +${reward.coins} Coins, +${reward.xp} XP & +${reward.spins} Freispiele!`;
    setClaimMessage(msg);
    addToast('success', 'Daily Bonus abgeholt!', `Tag ${nextStreak} brachte dir +${reward.coins} Coins.`);
  };

  const handleWeeklyClaim = () => {
    if (user.weeklyClaimed) {
      addToast('error', 'Bereits geöffnet', 'Du hast deine wöchentliche Truhe bereits geöffnet! Nächste Truhe am Montag.');
      return;
    }

    confetti({
      particleCount: 150,
      spread: 100,
      origin: { y: 0.5 }
    });

    setUser(prev => {
      const newCoins = prev.coins + 25000;
      let newXp = prev.xp + 1500;
      const newSpins = prev.spinsLeft + 10;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: '🏆 Wöchentliche Mega Truhe',
        amount: 25000,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: newXp,
        level: newLevel,
        nextLevelXp,
        spinsLeft: newSpins,
        weeklyClaimed: true,
        lastWeeklyClaim: new Date().toISOString(),
        transactions: [newTx, ...prev.transactions]
      };
    });

    const msg = '🏆 WÖCHENTLICHER MEGA-DROP: +25.000 Coins, +1.500 XP & +10 Freispiele gesichert!';
    setClaimMessage(msg);
    addToast('drop', 'Mega Truhe geöffnet!', 'Du hast +25.000 Coins & +10 Freispiele erhalten.');
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const canClaimDaily = user.lastDailyClaim !== todayStr;
  const canClaimWeekly = !user.weeklyClaimed;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Title */}
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20">
          <Calendar className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
            Daily & Weekly Login Belohnungen
          </h2>
          <p className="text-slate-400 text-sm">
            Melde dich jeden Tag an, um deinen Streak auszubauen. Höhere Streaks bringen drastisch mehr Coins & Freispiele!
          </p>
        </div>
      </div>

      {/* Claim Message Alert */}
      {claimMessage && (
        <div className="mb-8 p-4 rounded-2xl bg-slate-800/90 border border-cyan-500/50 flex items-center justify-between gap-4 animate-fade-in shadow-xl">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-cyan-400 flex-shrink-0 animate-spin-slow" />
            <p className="text-sm sm:text-base text-slate-100 font-semibold">{claimMessage}</p>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={onOpenShare}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs sm:text-sm font-bold rounded-xl shadow hover:scale-105 transition-all whitespace-nowrap"
            >
              Teilen (+500 Coins)
            </button>
            <button 
              onClick={() => setClaimMessage(null)}
              className="text-slate-400 hover:text-white px-2 py-1 text-sm font-bold"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* 7-Day Streak Calendar */}
        <div className="lg:col-span-2 glass-panel-premium p-6 sm:p-8 rounded-3xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-white font-['Space_Grotesk'] mb-1">
                Täglicher Login-Bonus
              </h3>
              <p className="text-xs text-slate-400">
                Aktueller Streak: <span className="text-cyan-400 font-bold">{user.dailyStreak} Tage</span>
              </p>
            </div>

            <button
              onClick={handleDailyClaim}
              disabled={!canClaimDaily}
              className={`px-6 py-3.5 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] flex items-center gap-2 ${
                canClaimDaily
                  ? 'bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-cyan-500/25 transform hover:-translate-y-1 animate-pulse'
                  : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
              }`}
            >
              <Gift className="w-4 h-4" />
              <span>{canClaimDaily ? 'Heutigen Bonus abholen' : 'Bereits abgeholt'}</span>
            </button>
          </div>

          {/* Grid of 7 days */}
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
            {dailyRewards.map((reward) => {
              const isClaimed = reward.day <= user.dailyStreak && !canClaimDaily;
              const isCurrent = reward.day === ((user.dailyStreak % 7) + 1) && canClaimDaily;

              return (
                <div
                  key={reward.day}
                  className={`p-4 rounded-2xl flex flex-col items-center justify-between text-center transition-all relative overflow-hidden ${
                    reward.isBig 
                      ? 'col-span-2 sm:col-span-1 bg-gradient-to-b from-amber-500/20 to-purple-900/40 border-2 border-amber-500/50 shadow-lg shadow-amber-500/10' 
                      : isCurrent
                      ? 'bg-gradient-to-b from-cyan-500/20 to-slate-800/80 border-2 border-cyan-400 shadow-lg shadow-cyan-500/20'
                      : isClaimed
                      ? 'bg-slate-900/60 border border-slate-800 opacity-60'
                      : 'bg-slate-800/40 border border-slate-700/50 hover:border-slate-600'
                  }`}
                >
                  {isClaimed && (
                    <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-[2px] flex items-center justify-center z-10">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                    </div>
                  )}

                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Tag {reward.day}
                  </span>

                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 ${
                    reward.isBig
                      ? 'bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 shadow-md shadow-amber-500/30 animate-bounce'
                      : isCurrent
                      ? 'bg-gradient-to-tr from-cyan-500 to-blue-500 text-white shadow-md shadow-cyan-500/30'
                      : 'bg-slate-700 text-slate-300'
                  }`}>
                    <Gift className="w-6 h-6" />
                  </div>

                  <div className="flex flex-col items-center">
                    <span className="text-sm font-extrabold text-white font-['Space_Grotesk']">
                      +{reward.coins.toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold">Coins</span>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-700/50 w-full flex flex-col gap-0.5 text-[10px] text-slate-300 font-medium">
                    <span>+{reward.xp} XP</span>
                    <span className="text-rose-400 font-bold">+{reward.spins} Spin{reward.spins > 1 ? 's' : ''}</span>
                  </div>

                  {reward.isBig && (
                    <span className="absolute top-1 right-1 text-[9px] bg-amber-500 text-slate-950 font-extrabold px-1.5 py-0.5 rounded-full">
                      VIP
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-6 flex items-center gap-2 text-xs text-slate-400 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <AlertCircle className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span>Tipp: Wenn du einen Tag verpasst, wird dein Streak zurückgesetzt. Bleib täglich aktiv für die Tag 7 VIP-Truhe!</span>
          </div>
        </div>

        {/* Weekly Mega Chest */}
        <div className="glass-panel-gold p-6 sm:p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-yellow-400 bg-yellow-500/10 px-3 py-1 rounded-full border border-yellow-500/20 uppercase tracking-wider">
                Wöchentliches Event
              </span>
              <Sparkles className="w-5 h-5 text-yellow-400 animate-spin-slow" />
            </div>

            <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
              Die Nexus Mega Truhe
            </h3>
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">
              Jede Woche schalten wir für alle treuen Arena-Mitglieder die prall gefüllte Mega Truhe frei. Sichere dir den ultimativen Krypto-Boost!
            </p>

            {/* Rewards Overview */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-yellow-500/30 mb-6 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400 font-medium">Bonus Coins:</span>
                <span className="font-extrabold text-yellow-400 font-['Space_Grotesk'] text-base">+25.000 NEX</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400 font-medium">Erfahrungspunkte:</span>
                <span className="font-extrabold text-purple-400 font-['Space_Grotesk'] text-base">+1.500 XP</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400 font-medium">Glücksrad Freispiele:</span>
                <span className="font-extrabold text-rose-400 font-['Space_Grotesk'] text-base">+10 Spins</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleWeeklyClaim}
            disabled={!canClaimWeekly}
            className={`w-full py-4 rounded-2xl font-extrabold text-base shadow-2xl transition-all font-['Space_Grotesk'] flex items-center justify-center gap-2 ${
              canClaimWeekly
                ? 'bg-gradient-to-r from-yellow-500 via-amber-500 to-yellow-600 hover:from-yellow-400 hover:to-amber-500 text-slate-950 shadow-yellow-500/30 transform hover:-translate-y-1 animate-pulse'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            <Gift className="w-5 h-5" />
            <span>{canClaimWeekly ? 'Mega Truhe jetzt öffnen' : 'Truhe geöffnet (Warten)'}</span>
          </button>

          <p className="text-[11px] text-center text-slate-400 mt-4">
            *Nächster Reset erfolgt am kommenden Montag um 00:00 UTC.
          </p>

        </div>

      </div>

    </div>
  );
};
