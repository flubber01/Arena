import React, { useState } from 'react';
import { Bot, X, Send, HelpCircle, ShieldAlert, FileText } from 'lucide-react';

interface HelpChatbotProps {
  userId: string;
}

const FAQ_QUICK_QUESTIONS = [
  { q: 'Wann findet der offizielle Coin Launch statt?', a: 'Der offizielle NEXUS Coin Launch ist für das Q3 2026 angesetzt. Bis dahin sind alle Pre-Launch Staking-Erträge im Smart Contract gesichert.' },
  { q: 'Wie funktioniert die Auszahlung per User-ID?', a: 'Deine Krypto-Auszahlung wird exklusiv für deine verifizierte User-ID freigeschaltet. Sobald der Token gelauncht ist, erfolgt der direkte Claim auf dein hinterlegtes Wallet.' },
  { q: 'Wie hoch sind die Staking-Renditen (ROI)?', a: 'Die Renditen variieren je nach Krypto-Asset zwischen 20% und 70% ROI, basierend auf unserer dezentralen Liquiditätsberechnung und Laufzeit.' },
  { q: 'Ist mein Kapital sicher?', a: 'Ja, alle Verträge sind durch unsere institutionellen Partner (u.a. Sparkasse, BlackRock, Deutsche Börse) und mehrfach auditierte Smart Contracts abgesichert.' },
];

export const HelpChatbot: React.FC<HelpChatbotProps> = ({ userId }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot', text: string }>>([
    { sender: 'bot', text: `Hallo Titan! Ich bin dein direkter KI-Support-Assistent. Deine User-ID lautet: NEX-${userId}. Wie kann ich dir heute bei Fragen zu Staking, Auszahlungen oder dem Coin Launch helfen?` }
  ]);
  const [inputText, setInputText] = useState<string>('');
  const [showDisclaimer, setShowDisclaimer] = useState<boolean>(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg = inputText.trim();
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setInputText('');

    setTimeout(() => {
      let botAnswer = 'Vielen Dank für deine Anfrage! Unser KI-Support-Team prüft deinen Status. Bei spezifischen Auszahlungswünschen halte bitte deine User-ID bereit.';
      const lower = userMsg.toLowerCase();

      if (lower.includes('auszahlung') || lower.includes('payout') || lower.includes('geld')) {
        botAnswer = `Deine Auszahlung ist fest an deine User-ID (NEX-${userId}) gebunden. Bitte beachte, dass sämtliche Auszahlungen bis zum offiziellen NEXUS Coin Börsen-Launch im Smart Contract gesperrt bleiben ("stuck"), um die Marktliquidität zu garantieren.`;
      } else if (lower.includes('launch') || lower.includes('sperre') || lower.includes('stuck')) {
        botAnswer = 'Sämtliche Auszahlungen und angelegten Krypto-Pools sind bis zum offiziellen NEXUS Coin Börsen-Launch im Smart Contract gesperrt ("stuck"). Dies sichert dir die extrem hohen Renditen von 20% bis 240% ROI.';
      } else if (lower.includes('bafin') || lower.includes('sec') || lower.includes('scam') || lower.includes('disclaimer')) {
        botAnswer = 'Nexus Arena agiert im Rahmen internationaler Krypto-Richtlinien. Bitte lies unseren vollständigen Risikohinweis und Disclaimer im Hilfe-Menü.';
      }

      setMessages(prev => [...prev, { sender: 'bot', text: botAnswer }]);
    }, 800);
  };

  const handleQuickQuestion = (qa: typeof FAQ_QUICK_QUESTIONS[0]) => {
    setMessages(prev => [
      ...prev,
      { sender: 'user', text: qa.q },
      { sender: 'bot', text: qa.a }
    ]);
  };

  return (
    <>
      {/* Floating Button right side */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 flex items-center gap-3 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white px-5 py-3.5 rounded-full shadow-2xl shadow-blue-500/30 transition-all transform hover:scale-105 group font-['Space_Grotesk'] font-extrabold text-sm"
        >
          <Bot className="w-5 h-5 animate-bounce" />
          <span>Direkte KI Hilfe 24/7</span>
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping ml-1" />
        </button>
      )}

      {/* Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-80 sm:w-96 bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl shadow-blue-500/20 flex flex-col h-[520px] animate-fade-in overflow-hidden">
          
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 p-4 flex items-center justify-between text-white shadow-md">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-slate-950/40 flex items-center justify-center border border-white/20">
                <Bot className="w-4 h-4 text-cyan-300" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold font-['Space_Grotesk'] leading-none mb-0.5">Nexus AI Support</h4>
                <p className="text-[10px] text-blue-100">User-ID: NEX-{userId}</p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button onClick={() => setShowDisclaimer(true)} className="p-1 text-blue-100 hover:text-white rounded-lg transition-colors" title="Rechtlicher Disclaimer">
                <ShieldAlert className="w-4 h-4" />
              </button>
              <button onClick={() => setIsOpen(false)} className="p-1 text-blue-100 hover:text-white rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick FAQ Options */}
          <div className="p-3 bg-slate-950/80 border-b border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
            {FAQ_QUICK_QUESTIONS.map((qa, idx) => (
              <button
                key={idx}
                onClick={() => handleQuickQuestion(qa)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-[11px] font-bold text-slate-300 hover:text-white transition-all whitespace-nowrap flex items-center gap-1"
              >
                <HelpCircle className="w-3 h-3 text-cyan-400" />
                <span>{qa.q}</span>
              </button>
            ))}
          </div>

          {/* Messages Body */}
          <div className="flex-grow p-4 overflow-y-auto space-y-4 no-scrollbar bg-slate-950/40">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold shadow ${
                  msg.sender === 'user' ? 'bg-cyan-500 text-slate-950 font-extrabold' : 'bg-slate-800 border border-slate-700 text-cyan-400'
                }`}>
                  {msg.sender === 'user' ? 'DU' : <Bot className="w-4 h-4" />}
                </div>

                <div className={`p-3 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-md max-w-[75%] ${
                  msg.sender === 'user' 
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-tr-none font-medium' 
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none font-normal'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
            <input 
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Stelle deine Support-Frage..."
              className="flex-grow bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white outline-none transition-all shadow-inner"
            />
            <button type="submit" disabled={!inputText.trim()} className="p-2.5 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 disabled:opacity-50 text-white rounded-xl shadow transition-all flex-shrink-0">
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}

      {/* Disclaimers Modal */}
      {showDisclaimer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="glass-panel-premium w-full max-w-2xl p-6 sm:p-8 rounded-3xl border-2 border-cyan-400 relative overflow-hidden shadow-2xl shadow-cyan-500/20 max-h-[80vh] flex flex-col">
            <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-gradient-to-tr from-rose-500 to-purple-600 text-white shadow-lg">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk']">Rechtliche Hinweise & Disclaimer</h3>
                  <p className="text-xs text-slate-400">Wichtige Informationen zu Krypto-Staking, Risiken und regulatorischer Compliance.</p>
                </div>
              </div>
              <button onClick={() => setShowDisclaimer(false)} className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center font-bold text-lg transition-all">✕</button>
            </div>

            <div className="overflow-y-auto space-y-6 pr-2 flex-grow text-xs sm:text-sm text-slate-300 leading-relaxed no-scrollbar">
              <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
                <h4 className="font-extrabold text-white font-['Space_Grotesk'] mb-2 flex items-center gap-1.5 text-base">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span>1. Risikohinweis (Risk Warning)</span>
                </h4>
                <p>Krypto-Investitionen und Staking-Pools bergen ein hohes Verlustrisiko. Der Kryptomarkt ist hochgradig volatil. Investiere niemals Geld, das du dir nicht leisten kannst zu verlieren. Die in dieser Simulation dargestellten Renditen (20% bis 240% ROI) basieren auf mathematischen Hochrechnungen und stellen keine garantierte Finanzberatung dar.</p>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
                <h4 className="font-extrabold text-white font-['Space_Grotesk'] mb-2 flex items-center gap-1.5 text-base">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span>2. Pre-Launch Sperrfrist ("Lockup / Stucks")</span>
                </h4>
                <p>Wie in den Staking-Bedingungen aufgeführt, werden eingezahlte Krypto-Assets bis zum offiziellen NEXUS Token Launch in dezentralen Liquiditätspools gesperrt. Eine vorzeitige Auszahlung ist vertraglich ausgeschlossen, um die Zinseszins-Berechnung und die Plattformstabilität für alle Teilnehmer zu wahren.</p>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
                <h4 className="font-extrabold text-white font-['Space_Grotesk'] mb-2 flex items-center gap-1.5 text-base">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span>3. Auszahlung per User-ID (KYC / AML)</span>
                </h4>
                <p>Um internationalen Geldwäschegesetzen (AML) und den Vorgaben von Finanzaufsichtsbehörden (BaFin, SEC) zu entsprechen, ist jede Auszahlung fest an deine persönliche User-ID gekoppelt. Transaktionen an Fremdkonten werden durch unseren automatisierten Sicherheits-Smart-Contract blockiert.</p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-center">
              <button onClick={() => setShowDisclaimer(false)} className="px-8 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-sm rounded-2xl shadow-lg transition-all">
                Ich habe die Hinweise verstanden & akzeptiert
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
