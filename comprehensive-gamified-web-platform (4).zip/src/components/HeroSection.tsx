import React, { useState, useEffect } from 'react';
import { UserState, ActiveTab } from '../types';
import { TrendingUp, ShieldCheck, Zap, Rocket, Users, Award, Play, Activity, Clock, PhoneCall, Mail, Send, HelpCircle, Gift, CheckCircle2, Key, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface HeroSectionProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  setActiveTab: (tab: ActiveTab) => void;
  onQuickDeposit: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

const CHARTS_DATA = {
  NEXUS: { price: 2.48, change: '+18.4%', points: 'M 0 120 Q 30 110 60 95 T 120 70 T 180 85 T 240 40 T 300 20', color: '#06b6d4', glow: 'rgba(6,182,212,0.5)' },
  BTC: { price: 94250, change: '+4.2%', points: 'M 0 100 Q 40 80 80 90 T 160 60 T 240 30 T 300 10', color: '#f59e0b', glow: 'rgba(245,158,11,0.5)' },
  ETH: { price: 3420, change: '+6.8%', points: 'M 0 110 Q 50 95 100 105 T 200 50 T 300 35', color: '#8b5cf6', glow: 'rgba(139,92,246,0.5)' },
  SOL: { price: 242, change: '+14.1%', points: 'M 0 130 Q 30 100 60 110 T 150 40 T 220 60 T 300 15', color: '#10b981', glow: 'rgba(16,189,129,0.5)' },
};

export const HeroSection: React.FC<HeroSectionProps> = ({
  user,
  setUser,
  setActiveTab,
  onQuickDeposit,
  addToast
}) => {
  const [selectedCrypto, setSelectedCrypto] = useState<'NEXUS' | 'BTC' | 'ETH' | 'SOL'>('NEXUS');
  const [promoCode, setPromoCode] = useState<string>('');

  const [timeframe, setTimeframe] = useState<'1H' | '24H' | '7D' | '30D' | 'ALL'>('24H');
  const [simulatedPrice, setSimulatedPrice] = useState<number>(CHARTS_DATA['NEXUS'].price);
  const [showContactModal, setShowContactModal] = useState<boolean>(false);

  const handleClaimPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const code = promoCode.trim().toUpperCase();
    if (!code) return;

    if (user.claimedPromoCodes?.includes(code)) {
      addToast('error', 'Code bereits verwendet', `Der Promo Code "${code}" wurde bereits eingelöst.`);
      return;
    }

    let rewardCoins = 0;
    let rewardXp = 0;
    let rewardSpins = 0;
    let label = '';

    if (code === 'NEXUS2026') { rewardCoins = 25000; rewardXp = 1000; label = '25.000 Coins & 1.000 XP'; }
    else if (code === 'TITAN500') { rewardCoins = 50000; rewardXp = 5000; label = '50.000 Coins & 5.000 XP'; }
    else if (code === 'CRYPTOVIP') { rewardCoins = 100000; rewardSpins = 10; label = '100.000 Coins & 10 Freispiele'; }
    else if (code === 'AIRDROP10K') { rewardCoins = 10000; rewardXp = 500; label = '10.000 Coins & 500 XP'; }
    else {
      addToast('error', 'Ungültiger Code', `Der Promo Code "${code}" existiert nicht.`);
      return;
    }

    confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });

    setUser(prev => {
      const newCoins = prev.coins + rewardCoins;
      const newXp = prev.xp + rewardXp;
      const newSpins = prev.spinsLeft + rewardSpins;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let currentXp = newXp;
      while (currentXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        currentXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `🎁 Promo Code: ${code}`,
        amount: rewardCoins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: currentXp,
        level: newLevel,
        nextLevelXp,
        spinsLeft: newSpins,
        claimedPromoCodes: [...(prev.claimedPromoCodes || []), code],
        transactions: [newTx, ...prev.transactions]
      };
    });

    addToast('success', 'Promo Code Eingelöst!', `Glückwunsch! Du hast ${label} erhalten.`);
    setPromoCode('');
  };

  // Live Countdown Timer State for Börsen-Launch
  const [countdown, setCountdown] = useState({ days: 142, hours: 18, minutes: 42, seconds: 12 });

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setSimulatedPrice(CHARTS_DATA[selectedCrypto].price);
    const interval = setInterval(() => {
      setSimulatedPrice(prev => {
        const fluctuation = prev * (Math.random() * 0.004 - 0.002);
        return parseFloat((prev + fluctuation).toFixed(2));
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [selectedCrypto]);

  const currentChart = CHARTS_DATA[selectedCrypto];

  return (
    <div className="relative overflow-hidden py-12 lg:py-20 bg-gradient-to-b from-[#0b0f19] via-[#0f172a] to-[#0b0f19]">
      
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-cyan-500/10 via-blue-600/10 to-purple-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-10 right-10 w-72 h-72 bg-purple-500/10 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-[90px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Announcement Badge */}
        <div className="flex justify-center mb-6">
          <div 
            onClick={() => setActiveTab('freelaunch')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/80 border border-cyan-500/30 text-cyan-400 text-xs sm:text-sm font-semibold shadow-lg shadow-cyan-500/10 cursor-pointer hover:border-cyan-500/60 hover:scale-105 transition-all"
          >
            <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <Rocket className="w-4 h-4 text-cyan-400 animate-float" />
            <span>FAIRLAUNCH AIRDROP LIVE: 5.000 NEXUS COINS SICHERN</span>
            <span className="text-white underline ml-1">Jetzt claimen &rarr;</span>
          </div>
        </div>

        {/* --- TRANSPARENCY & TIMER BANNER --- */}
        <div className="max-w-4xl mx-auto mb-12 glass-panel-premium p-6 sm:p-8 rounded-3xl border-2 border-cyan-500/50 shadow-2xl shadow-cyan-500/10 flex flex-col md:flex-row items-center justify-between gap-6 bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-cyan-400 animate-spin-slow" />
              <span className="text-xs font-extrabold text-cyan-400 uppercase tracking-widest">Maximale Transparenz</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
              NEXUS Coin Börsen-Launch Countdown
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-md leading-relaxed">
              Bis zum offiziellen Trading-Start bleiben Staking-Pools im geprüften Smart Contract gesichert. Wir stehen dir 24/7 für direkte Rückfragen zur Verfügung.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto justify-end">
            {/* Live Timer Boxes */}
            <div className="flex items-center gap-2 bg-slate-950/80 p-3 rounded-2xl border border-slate-800 shadow-inner">
              <div className="text-center px-2">
                <span className="text-xl font-black text-white font-['Space_Grotesk'] block">{countdown.days}</span>
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">Tage</span>
              </div>
              <span className="text-cyan-400 font-bold">:</span>
              <div className="text-center px-2">
                <span className="text-xl font-black text-white font-['Space_Grotesk'] block">{String(countdown.hours).padStart(2, '0')}</span>
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">Std</span>
              </div>
              <span className="text-cyan-400 font-bold">:</span>
              <div className="text-center px-2">
                <span className="text-xl font-black text-white font-['Space_Grotesk'] block">{String(countdown.minutes).padStart(2, '0')}</span>
                <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">Min</span>
              </div>
              <span className="text-cyan-400 font-bold">:</span>
              <div className="text-center px-2">
                <span className="text-xl font-black text-cyan-400 font-['Space_Grotesk'] block animate-pulse">{String(countdown.seconds).padStart(2, '0')}</span>
                <span className="text-[9px] text-cyan-400 uppercase font-bold tracking-wider">Sek</span>
              </div>
            </div>

            {/* 24/7 Contact Button */}
            <button
              onClick={() => setShowContactModal(true)}
              className="w-full sm:w-auto px-6 py-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-lg shadow-blue-500/25 transition-all transform hover:-translate-y-0.5 whitespace-nowrap flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-4 h-4 animate-bounce" />
              <span>Kontakt 24/7</span>
            </button>
          </div>
        </div>

        {/* Main Hero Title & Description */}
        <div className="text-center max-w-4xl mx-auto mb-12">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.1] mb-6 font-['Space_Grotesk']">
            Die Ultimative Krypto{' '}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 neon-text-cyan animate-pulse">
              Gamification & Staking
            </span>{' '}
            Arena
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto font-light leading-relaxed mb-8">
            Investiere in hochrentable Staking-Pools mit bis zu <span className="text-amber-400 font-bold">240% ROI</span>, messe dich in der Elite-Liga, drehe das Glücksrad und maximiere deine Krypto-Erträge in Echtzeit.
          </p>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
            <button
              onClick={onQuickDeposit}
              className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-extrabold px-8 py-4 rounded-2xl shadow-xl shadow-cyan-500/25 transition-all transform hover:-translate-y-1 text-base sm:text-lg font-['Space_Grotesk']"
            >
              <Zap className="w-5 h-5 fill-white" />
              <span>Investment Starten</span>
            </button>

            <button
              onClick={() => setActiveTab('minigames')}
              className="flex items-center gap-2 bg-slate-800/80 hover:bg-slate-700/80 text-white font-bold px-8 py-4 rounded-2xl border border-slate-700 hover:border-slate-600 shadow-lg transition-all transform hover:-translate-y-1 text-base sm:text-lg"
            >
              <Play className="w-5 h-5 text-purple-400 fill-purple-400" />
              <span>Minispiele testen</span>
            </button>
            
            <button
              onClick={() => setActiveTab('wheel')}
              className="flex items-center gap-2 bg-gradient-to-r from-rose-600/20 to-purple-600/20 hover:from-rose-600/30 hover:to-purple-600/30 text-rose-300 font-bold px-8 py-4 rounded-2xl border border-rose-500/30 hover:border-rose-500/50 shadow-lg transition-all transform hover:-translate-y-1 text-base sm:text-lg"
            >
              <Award className="w-5 h-5 text-rose-400" />
              <span>Glücksrad drehen ({user.spinsLeft} übrig)</span>
            </button>
          </div>

          {/* --- PROMO CODE CLAIM CARD --- */}
          <div className="max-w-xl mx-auto mb-16 glass-panel p-6 sm:p-8 rounded-3xl border-2 border-purple-500/40 shadow-2xl shadow-purple-500/10 text-left bg-gradient-to-r from-purple-950/20 via-slate-900 to-slate-900 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-400 shadow-md">
                <Gift className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk']">Promo Code Einlösen</h3>
                <p className="text-xs text-slate-400">Gib deinen Community- oder Event-Gutschein für sofortige Boni ein.</p>
              </div>
            </div>

            <form onSubmit={handleClaimPromo} className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-grow w-full sm:w-auto">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Key className="w-4 h-4 text-purple-400" />
                </div>
                <input 
                  type="text" 
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  placeholder="z.B. NEXUS2026, TITAN500..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-2xl py-3.5 pl-11 pr-4 text-sm font-bold text-white uppercase tracking-wider outline-none transition-all shadow-inner"
                />
              </div>
              <button 
                type="submit"
                disabled={!promoCode.trim()}
                className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 hover:from-purple-400 hover:to-rose-400 disabled:opacity-50 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-purple-500/25 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Einlösen</span>
              </button>
            </form>

            <div className="flex items-center gap-4 mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 overflow-x-auto no-scrollbar">
              <span className="font-bold text-slate-300 flex items-center gap-1"><Sparkles className="w-3.5 h-3.5 text-purple-400" /> Boni:</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-purple-300">NEXUS2026</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-cyan-300">TITAN500</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-amber-300">CRYPTOVIP</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-emerald-300">AIRDROP10K</span>
            </div>
          </div>

          {/* Interactive Live Chart Panel */}
          <div className="glass-panel-premium p-6 sm:p-10 rounded-3xl border border-cyan-500/30 mb-16 relative overflow-hidden text-left shadow-2xl shadow-cyan-500/10">
            <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8 pb-6 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Interaktives Live-Terminal</span>
                </div>
                <div className="flex items-baseline gap-3">
                  <h3 className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
                    {selectedCrypto === 'BTC' ? '$' : selectedCrypto === 'ETH' ? '$' : selectedCrypto === 'SOL' ? '$' : '$'}{simulatedPrice.toLocaleString('de-DE', { minimumFractionDigits: selectedCrypto === 'NEXUS' ? 2 : 0 })}
                  </h3>
                  <span className="text-sm font-extrabold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                    {currentChart.change} ({timeframe})
                  </span>
                </div>
              </div>

              {/* Asset Selection Buttons */}
              <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar">
                {(['NEXUS', 'BTC', 'ETH', 'SOL'] as const).map((crypto) => (
                  <button
                    key={crypto}
                    onClick={() => setSelectedCrypto(crypto)}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all tracking-wider whitespace-nowrap ${
                      selectedCrypto === crypto ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {crypto}
                  </button>
                ))}
              </div>

              {/* Timeframe Selection */}
              <div className="flex items-center gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar">
                {(['1H', '24H', '7D', '30D', 'ALL'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                      timeframe === tf ? 'bg-slate-800 text-white font-extrabold' : 'text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated SVG Line Chart */}
            <div className="w-full h-48 sm:h-64 relative flex items-center justify-center overflow-hidden bg-slate-950/60 rounded-2xl border border-slate-800/80 p-4 shadow-inner">
              <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:30px_30px] pointer-events-none" />

              <svg className="w-full h-full overflow-visible transition-all duration-500" viewBox="0 0 300 150" preserveAspectRatio="none">
                <defs>
                  <linearGradient id={`grad-${selectedCrypto}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={currentChart.color} stopOpacity="0.4" />
                    <stop offset="100%" stopColor={currentChart.color} stopOpacity="0.0" />
                  </linearGradient>
                  <filter id={`glow-${selectedCrypto}`} x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Area Fill */}
                <path
                  d={`${currentChart.points} L 300 150 L 0 150 Z`}
                  fill={`url(#grad-${selectedCrypto})`}
                  className="transition-all duration-500"
                />

                {/* Line */}
                <path
                  d={currentChart.points}
                  fill="none"
                  stroke={currentChart.color}
                  strokeWidth="3"
                  filter={`url(#glow-${selectedCrypto})`}
                  className="transition-all duration-500 animate-pulse"
                />

                {/* Simulated Data Points */}
                <circle cx="120" cy="70" r="4" fill={currentChart.color} className="animate-ping" />
                <circle cx="240" cy="40" r="4" fill={currentChart.color} className="animate-ping" />
                <circle cx="300" cy="20" r="6" fill="#fff" stroke={currentChart.color} strokeWidth="3" className="shadow-lg" />
              </svg>

              <div className="absolute bottom-3 left-4 text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                *Simulierte Live-Daten über Nexus Oracle AI
              </div>
            </div>

          </div>
        </div>

        {/* Live Platform Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 max-w-6xl mx-auto">
          
          <div className="glass-panel-premium p-6 rounded-3xl relative overflow-hidden group hover:border-cyan-500/50 transition-all">
            <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl group-hover:bg-cyan-500/20 transition-all" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">NEXUS Preis</span>
              <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                <TrendingUp className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">$2.48</span>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">+18.4%</span>
            </div>
            <p className="text-xs text-slate-400 mt-2">All-Time High Kursentwicklung</p>
          </div>

          <div className="glass-panel-premium p-6 rounded-3xl relative overflow-hidden group hover:border-purple-500/50 transition-all">
            <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-xl group-hover:bg-purple-500/20 transition-all" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">Total Staked</span>
              <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">$42.8M</span>
              <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/20">APY bis 240%</span>
            </div>
            <p className="text-xs text-slate-400 mt-2">In Liquiditätspools gesichert</p>
          </div>

          <div className="glass-panel-premium p-6 rounded-3xl relative overflow-hidden group hover:border-amber-500/50 transition-all">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl group-hover:bg-amber-500/20 transition-all" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">Aktive Staker</span>
              <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <Users className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">184.2K</span>
              <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">Live</span>
            </div>
            <p className="text-xs text-slate-400 mt-2">Investoren weltweit aktiv</p>
          </div>

          <div className="glass-panel-premium p-6 rounded-3xl relative overflow-hidden group hover:border-rose-500/50 transition-all">
            <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/10 rounded-full blur-xl group-hover:bg-rose-500/20 transition-all" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">Ausgeschüttet</span>
              <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20">
                <Award className="w-5 h-5 text-rose-400" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">$14.2M</span>
              <span className="text-xs font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20">Rewards</span>
            </div>
            <p className="text-xs text-slate-400 mt-2">An unsere Staker & Spieler</p>
          </div>

        </div>

      </div>

      {/* --- 24/7 CONTACT US MODAL --- */}
      {showContactModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="glass-panel-premium w-full max-w-2xl p-6 sm:p-8 rounded-3xl border-2 border-cyan-400 relative overflow-hidden shadow-2xl shadow-cyan-500/20 max-h-[85vh] flex flex-col">
            <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white shadow-lg">
                  <PhoneCall className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk']">24/7 Live Support & Kontakt</h3>
                  <p className="text-xs text-slate-400">Maximale Transparenz und direkte Ansprechpartner für dein Kapital.</p>
                </div>
              </div>
              <button onClick={() => setShowContactModal(false)} className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center font-bold text-lg transition-all">✕</button>
            </div>

            <div className="overflow-y-auto space-y-6 pr-2 flex-grow text-xs sm:text-sm text-slate-300 leading-relaxed no-scrollbar">
              
              {/* Option 1: AI Chatbot */}
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-inner">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 flex-shrink-0">
                    <HelpCircle className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-base">Direkte KI Hilfe (Unten rechts)</h4>
                    <p className="text-xs text-slate-400">Nutze unser schwebendes KI-Terminal für sofortige Antworten zu deiner User-ID.</p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-full font-bold text-[10px] uppercase tracking-wider">24/7 Aktiv</span>
              </div>

              {/* Option 2: Telegram VIP */}
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-inner">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400 flex-shrink-0">
                    <Send className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-base">VIP Telegram Concierge</h4>
                    <p className="text-xs text-slate-400">Direkter Chat mit unseren Senior Account Managern: <span className="text-cyan-400 font-bold">@Nexus_VIP_Support</span></p>
                  </div>
                </div>
                <a href="https://t.me/Nexus_VIP_Support" target="_blank" rel="noreferrer" className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow transition-all whitespace-nowrap">Chat öffnen</a>
              </div>

              {/* Option 3: Phone */}
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-inner">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 flex-shrink-0">
                    <PhoneCall className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-base">Telefonischer Whale Desk</h4>
                    <p className="text-xs text-slate-400">Exklusiver Telefonsupport für Investments ab $50.000: <span className="text-emerald-400 font-bold">+49 89 142 8842 0</span></p>
                  </div>
                </div>
                <a href="tel:+498914288420" className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition-all whitespace-nowrap">Anrufen</a>
              </div>

              {/* Option 4: Email */}
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-inner">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 flex-shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-base">E-Mail Support Desk</h4>
                    <p className="text-xs text-slate-400">Allgemeine Anfragen & KYC Dokumente: <span className="text-purple-400 font-bold">support@nexus-coin-arena.io</span></p>
                  </div>
                </div>
                <a href="mailto:support@nexus-coin-arena.io" className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow transition-all whitespace-nowrap">E-Mail schreiben</a>
              </div>

              {/* Option 5: Audits */}
              <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-inner">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 flex-shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-base">Smart Contract & BaFin Audits</h4>
                    <p className="text-xs text-slate-400">Lade unsere verifizierten Sicherheits- und Compliance-Berichte herunter.</p>
                  </div>
                </div>
                <button onClick={() => alert('Prüfberichte (PDF) werden generiert und heruntergeladen...')} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-all whitespace-nowrap">Download PDF</button>
              </div>

            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-center">
              <button onClick={() => setShowContactModal(false)} className="px-8 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-sm rounded-2xl shadow transition-all">
                Fenster schließen
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
