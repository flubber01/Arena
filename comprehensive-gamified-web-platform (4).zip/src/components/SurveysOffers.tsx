import React, { useState } from 'react';
import { UserState } from '../types';
import { SURVEY_OFFERS } from '../data/mockData';
import { FileText, CheckCircle2, Clock, Gift, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface SurveysOffersProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const SurveysOffers: React.FC<SurveysOffersProps> = ({ user, setUser, addToast }) => {
  const [rngBonusClaimed, setRngBonusClaimed] = useState<boolean>(false);

  const handleStartSurvey = (surveyId: string, rewardCoins: number, rewardUsd: number, title: string) => {
    if (user.completedSurveys.includes(surveyId)) {
      addToast('error', 'Bereits absolviert', 'Du hast diese Umfrage bereits abgeschlossen!');
      return;
    }

    confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });

    setUser(prev => {
      const newCoins = prev.coins + rewardCoins;
      const newXp = prev.xp + 250;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let currentXp = newXp;
      while (currentXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        currentXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `📋 Umfrage-Prämie: ${title}`,
        amount: rewardCoins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: currentXp,
        level: newLevel,
        nextLevelXp,
        completedSurveys: [...prev.completedSurveys, surveyId],
        transactions: [newTx, ...prev.transactions]
      };
    });

    addToast('success', 'Umfrage Abgeschlossen!', `Du hast +${rewardCoins.toLocaleString()} Coins ($${rewardUsd.toFixed(2)}) erhalten.`);
  };

  const handleRngBonusDrop = () => {
    if (rngBonusClaimed) {
      addToast('error', 'Drop bereits geclaimt', 'Der heutige RNG 1-Tages-Bonus wurde bereits abgeholt. Komm morgen wieder!');
      return;
    }

    const possibleDrops = [
      { coins: 15000, xp: 500, label: '15.000 Coins & 500 XP' },
      { coins: 35000, xp: 1200, label: '35.000 Coins & 1.200 XP' },
      { coins: 50000, xp: 2500, label: '50.000 Coins & 2.500 XP (Epic Drop)' },
      { coins: 5000, xp: 200, label: '5.000 Coins & 200 XP' }
    ];
    const drop = possibleDrops[Math.floor(Math.random() * possibleDrops.length)];

    confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });

    setUser(prev => {
      const newCoins = prev.coins + drop.coins;
      const newXp = prev.xp + drop.xp;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let currentXp = newXp;
      while (currentXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        currentXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `🎁 RNG 1-Tages-Bonus Drop`,
        amount: drop.coins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: currentXp,
        level: newLevel,
        nextLevelXp,
        transactions: [newTx, ...prev.transactions]
      };
    });

    setRngBonusClaimed(true);
    addToast('drop', '🎁 RNG Bonus Drop!', `Glückwunsch! Du hast ${drop.label} erhalten.`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-blue-500 via-indigo-600 to-purple-600 text-white shadow-lg shadow-blue-500/20">
            <FileText className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Offerwall & Drittanbieter-Umfragen
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Verdiene zusätzliche Coins und echtes USD-Guthaben durch verifizierte Partner-Umfragen. Nutze außerdem den täglichen RNG-Bonus-Drop!
            </p>
          </div>
        </div>

        {/* RNG Drop Button */}
        <button
          onClick={handleRngBonusDrop}
          disabled={rngBonusClaimed}
          className={`flex items-center gap-2.5 px-6 py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] ${
            rngBonusClaimed 
              ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-amber-500/30 animate-bounce'
          }`}
        >
          <Gift className="w-5 h-5 fill-slate-950" />
          <span>{rngBonusClaimed ? 'RNG Bonus geclaimt ✓' : '🎁 Heutigen RNG Bonus Drop abholen'}</span>
        </button>
      </div>

      <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl mb-12 flex items-center gap-3 text-xs text-slate-300 shadow-inner">
        <AlertCircle className="w-5 h-5 text-cyan-400 flex-shrink-0" />
        <span>Die Vergütung erfolgt sofort nach Abschluss. Alle Umfragen werden von externen Marktforschungsinstituten bereitgestellt und unterliegen strengen Datenschutzrichtlinien.</span>
      </div>

      {/* Surveys Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
        {SURVEY_OFFERS.map((survey) => {
          const isCompleted = user.completedSurveys.includes(survey.id) || survey.completed;

          return (
            <div
              key={survey.id}
              className={`p-6 sm:p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all border ${
                isCompleted 
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                  : 'bg-slate-900/80 border-slate-800 hover:border-cyan-500/50 shadow-lg hover:scale-[1.02]'
              }`}
            >
              {isCompleted && (
                <div className="absolute top-0 right-0 px-4 py-1.5 rounded-bl-2xl bg-emerald-500/20 border-l border-b border-emerald-500/40 text-emerald-400 text-xs font-extrabold uppercase tracking-wider">
                  Absolviert ✓
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2.5 py-0.5 rounded-full font-extrabold uppercase tracking-wider">
                    {survey.provider}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-yellow-400 font-bold">
                    <span>★</span>
                    <span>{survey.rating.toFixed(1)}</span>
                  </div>
                </div>

                <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-3">{survey.title}</h3>

                <div className="flex items-center gap-4 text-xs text-slate-400 mb-6">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <span>Dauer: ca. {survey.timeMin} Min.</span>
                  </div>
                </div>

                {/* Rewards Box */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 mb-6 flex items-center justify-between shadow-inner">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-0.5">Coin Prämie</span>
                    <span className="font-extrabold text-white font-['Space_Grotesk'] text-base">+{survey.rewardCoins.toLocaleString()} <span className="text-xs text-cyan-400">NEX</span></span>
                  </div>
                  <div className="text-right border-l border-slate-800 pl-4">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-0.5">USD Gegenwert</span>
                    <span className="font-extrabold text-emerald-400 font-['Space_Grotesk'] text-base">${survey.rewardUsd.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {isCompleted ? (
                  <button disabled className="w-full py-4 rounded-2xl bg-slate-800 text-slate-500 font-bold text-xs border border-slate-700 cursor-not-allowed">
                    Prämie bereits erhalten
                  </button>
                ) : (
                  <button
                    onClick={() => handleStartSurvey(survey.id, survey.rewardCoins, survey.rewardUsd, survey.title)}
                    className="w-full py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-cyan-500/25 flex items-center justify-center gap-2 animate-pulse"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Umfrage jetzt starten & Prämie sichern</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
