import React, { useState } from 'react';
import { UserState } from '../types';
import { LEAGUES } from '../data/mockData';
import { MousePointer, Zap, TrendingUp, Award, Sparkles, ChevronRight, ShieldCheck, Flame, BatteryCharging, Users, Key, CheckCircle2, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CoinClickerProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  onOpenShare: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
}

const SQUADS = [
  { id: 'ton', name: 'TON Syndicate', bonus: '+10% Coins', members: '142.5K' },
  { id: 'sol', name: 'Solana Surfers', bonus: '+10% Coins', members: '98.2K' },
  { id: 'hamster', name: 'Hamster Kombat Army', bonus: '+10% Coins', members: '210.4K' },
  { id: 'blum', name: 'Blum Legends', bonus: '+10% Coins', members: '75.1K' }
];

const MINING_CARDS = [
  { id: 'card1', name: 'AI Trading Bot', profit: 5000, cost: 25000, icon: '🤖', desc: 'Handelt automatisch auf dezentralen Börsen.' },
  { id: 'card2', name: 'Liquidity Farm', profit: 25000, cost: 100000, icon: '🌾', desc: 'Stellt Liquidität für NEXUS/USDT Paare bereit.' },
  { id: 'card3', name: 'Web3 Marketing', profit: 100000, cost: 500000, icon: '📣', desc: 'Virale Telegram & Twitter Kampagnen.' },
  { id: 'card4', name: 'Oracle Node', profit: 500000, cost: 2500000, icon: '🔮', desc: 'Sichert Hochfrequenz-Daten für Smart Contracts.' }
];

export const CoinClicker: React.FC<CoinClickerProps> = ({ user, setUser, onOpenShare, addToast }) => {
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [cipherInput, setCipherInput] = useState<string>('');

  const currentLeagueInfo = LEAGUES.find(l => l.name === user.league) || LEAGUES[0];

  const isTurboActive = user.turboEndTime ? Date.now() < user.turboEndTime : false;
  const squadBonusMult = user.activeSquad ? 1.1 : 1.0;

  const baseClickValue = 10 + (user.level * 25) + (user.clickMultiplierUpgrade * 50);
  const totalClickValue = Math.floor(baseClickValue * currentLeagueInfo.coinMultiplier * (isTurboActive ? 5 : 1) * squadBonusMult);
  const xpPerClick = 15 + Math.floor(user.level / 2);
  const autoClickerCoinsPerSec = user.autoClickerCount * Math.floor(totalClickValue / 4);

  const handleCoinClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Energy check
    if (!isTurboActive && user.energy <= 0) {
      addToast('error', '⚡ Keine Energie mehr!', 'Warte einen Moment auf die automatische Regeneration oder nutze einen Free Refill!');
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newId = Date.now() + Math.random();
    setFloatingTexts(prev => [...prev, { id: newId, x, y, text: `+${totalClickValue}` }]);

    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(item => item.id !== newId));
    }, 1000);

    setUser(prev => {
      let newCoins = prev.coins + totalClickValue;
      let newXp = prev.xp + xpPerClick;
      let newEnergy = isTurboActive ? prev.energy : Math.max(0, prev.energy - 1);
      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let levelUpped = false;

      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
        levelUpped = true;
      }

      if (levelUpped) {
        setTimeout(() => {
          confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });
        }, 100);
      }

      return {
        ...prev,
        coins: newCoins,
        xp: newXp,
        energy: newEnergy,
        level: newLevel,
        nextLevelXp
      };
    });
  };

  const upgradeCost = 500 + (user.clickMultiplierUpgrade * 1250);
  const buyClickUpgrade = () => {
    if (user.coins < upgradeCost) {
      addToast('error', 'Nicht genug Coins', 'Du benötigst mehr Coins für dieses Klicker-Upgrade!');
      return;
    }
    const newTx = {
      id: `TX-${Date.now()}`,
      type: 'spend' as const,
      title: '⚡ Klick-Booster Upgrade',
      amount: upgradeCost,
      currency: 'NEX',
      timestamp: new Date().toISOString()
    };
    setUser(prev => ({
      ...prev,
      coins: prev.coins - upgradeCost,
      clickMultiplierUpgrade: prev.clickMultiplierUpgrade + 1,
      transactions: [newTx, ...prev.transactions]
    }));
    addToast('success', 'Upgrade gekauft!', 'Deine Klick-Kraft wurde erfolgreich um +50 erhöht.');
  };

  const autoCost = 2000 + (user.autoClickerCount * 4500);
  const buyAutoClicker = () => {
    if (user.coins < autoCost) {
      addToast('error', 'Nicht genug Coins', 'Du benötigst mehr Coins für diesen Auto-Klicker Bot!');
      return;
    }
    const newTx = {
      id: `TX-${Date.now()}`,
      type: 'spend' as const,
      title: '🤖 Auto-Klicker Bot Kauf',
      amount: autoCost,
      currency: 'NEX',
      timestamp: new Date().toISOString()
    };
    setUser(prev => ({
      ...prev,
      coins: prev.coins - autoCost,
      autoClickerCount: prev.autoClickerCount + 1,
      transactions: [newTx, ...prev.transactions]
    }));
    addToast('success', 'Auto-Klicker gekauft!', 'Ein neuer Bot klickt ab sofort im Hintergrund für dich.');
  };

  // --- DAILY FREE BOOSTS ---
  const handleFullEnergyRefill = () => {
    if (user.fullEnergyRefillsLeft <= 0) {
      addToast('error', 'Keine Refills mehr', 'Du hast alle täglichen Free Energy Refills aufgebraucht!');
      return;
    }
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    setUser(prev => ({
      ...prev,
      energy: prev.maxEnergy,
      fullEnergyRefillsLeft: prev.fullEnergyRefillsLeft - 1
    }));
    addToast('success', '⚡ Energie voll aufgeladen!', 'Deine Ausdauer ist wieder auf 100%.');
  };

  const handleTurboBoost = () => {
    if (user.turboBoostsLeft <= 0) {
      addToast('error', 'Keine Turbos mehr', 'Du hast alle täglichen Turbo Boosts aufgebraucht!');
      return;
    }
    confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
    setUser(prev => ({
      ...prev,
      turboEndTime: Date.now() + 20000, // 20 seconds
      turboBoostsLeft: prev.turboBoostsLeft - 1
    }));
    addToast('drop', '🔥 TURBO X5 AKTIV!', 'Für 20 Sekunden erhältst du 5x Klick-Ertrag ohne Energieverbrauch!');
  };

  // --- SQUAD SELECTION ---
  const handleSelectSquad = (squadName: string) => {
    if (user.activeSquad === squadName) return;
    confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
    setUser(prev => ({ ...prev, activeSquad: squadName }));
    addToast('success', 'Squad beigetreten!', `Du bist jetzt Teil von ${squadName} (+10% Klick-Bonus).`);
  };

  // --- BUY MINING CARD ---
  const handleBuyMiningCard = (card: typeof MINING_CARDS[0]) => {
    if (user.coins < card.cost) {
      addToast('error', 'Nicht genug Coins', `Du benötigst ${card.cost.toLocaleString()} Coins für diese Karte!`);
      return;
    }
    confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
    const newTx = {
      id: `TX-${Date.now()}`,
      type: 'spend' as const,
      title: `🃏 Mining Karte: ${card.name}`,
      amount: card.cost,
      currency: 'NEX',
      timestamp: new Date().toISOString()
    };
    setUser(prev => ({
      ...prev,
      coins: prev.coins - card.cost,
      profitPerHour: prev.profitPerHour + card.profit,
      transactions: [newTx, ...prev.transactions]
    }));
    addToast('success', 'Mining Karte gekauft!', `Dein passives Einkommen stieg um +${card.profit.toLocaleString()} Coins/h.`);
  };

  // --- DAILY CIPHER ---
  const handleCipherSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (user.dailyCipherClaimed) {
      addToast('error', 'Bereits gelöst', 'Du hast das heutige Daily Morse Cipher bereits gelöst!');
      return;
    }
    if (cipherInput.trim().toUpperCase() !== 'NEXUS') {
      addToast('error', 'Falscher Code', 'Das eingegebene Morse-Wort ist nicht korrekt.');
      return;
    }
    confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });
    const newTx = {
      id: `TX-${Date.now()}`,
      type: 'earn' as const,
      title: '🔐 Daily Morse Cipher gelöst',
      amount: 1000000,
      currency: 'NEX',
      timestamp: new Date().toISOString()
    };
    setUser(prev => ({
      ...prev,
      coins: prev.coins + 1000000,
      xp: prev.xp + 5000,
      dailyCipherClaimed: true,
      transactions: [newTx, ...prev.transactions]
    }));
    addToast('drop', '🔐 Daily Cipher Gelöst!', 'Du hast +1.000.000 Coins & +5.000 XP erhalten.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 text-white shadow-lg shadow-cyan-500/20">
            <MousePointer className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Nexus Coin Klicker & Mining Hub
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Klicke auf den Nexus Coin, kaufe passive Mining-Karten (Profit per Hour) und nutze tägliche Free Boosts wie in den Top 50 Krypto-Apps!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Profit Per Hour Display */}
          <div className="bg-slate-900/80 border border-emerald-500/40 p-4 rounded-2xl shadow-inner flex items-center gap-3">
            <Clock className="w-6 h-6 text-emerald-400 animate-spin-slow" />
            <div>
              <span className="text-[11px] text-slate-400 block font-semibold uppercase tracking-wider">Passiver Profit (Offline)</span>
              <span className="text-lg font-extrabold text-emerald-400 font-['Space_Grotesk']">
                +{user.profitPerHour.toLocaleString()} <span className="text-xs text-slate-400">Coins/h</span>
              </span>
            </div>
          </div>

          <button
            onClick={onOpenShare}
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold px-6 py-4 rounded-2xl shadow-xl shadow-cyan-500/20 transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] text-sm whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4" />
            <span>Klick-Erfolg teilen (+500 Coins)</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16 items-start">
        
        {/* Left Column: Interactive Clicker Area */}
        <div className="lg:col-span-7 glass-panel-premium p-8 sm:p-12 rounded-3xl border border-cyan-500/30 relative overflow-hidden shadow-2xl shadow-cyan-500/10 flex flex-col items-center justify-center min-h-[580px]">
          <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Current Stats Display inside Clicker */}
          <div className="w-full flex flex-wrap items-center justify-between gap-4 mb-8 bg-slate-950/80 p-4 rounded-2xl border border-slate-800 shadow-inner z-10 text-center sm:text-left">
            <div>
              <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">Ertrag pro Klick</span>
              <span className="text-2xl font-black text-white font-['Space_Grotesk']">
                +{totalClickValue.toLocaleString()} <span className="text-xs text-cyan-400 font-bold">NEX</span>
              </span>
            </div>

            <div className="px-4 border-y sm:border-y-0 sm:border-x border-slate-800 py-2 sm:py-0">
              <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">Auto-Klicker</span>
              <span className="text-xl font-bold text-emerald-400 font-['Space_Grotesk']">
                +{autoClickerCoinsPerSec.toLocaleString()} <span className="text-[10px]">/s</span>
              </span>
            </div>

            <div>
              <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">XP pro Klick</span>
              <span className="text-xl font-bold text-purple-400 font-['Space_Grotesk']">
                +{xpPerClick} XP
              </span>
            </div>
          </div>

          {/* Turbo Badge if active */}
          {isTurboActive && (
            <div className="mb-6 px-6 py-2 rounded-full bg-gradient-to-r from-rose-500 via-red-500 to-amber-500 text-slate-950 font-black text-sm uppercase tracking-widest animate-bounce shadow-lg shadow-rose-500/30 flex items-center gap-2 z-10">
              <Flame className="w-5 h-5 fill-slate-950" />
              <span>🔥 TURBO X5 AKTIV (Kein Energieverbrauch)</span>
            </div>
          )}

          {/* Interactive Coin Button */}
          <div 
            onClick={handleCoinClick}
            className="relative w-64 sm:w-80 h-64 sm:h-80 rounded-full bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 p-4 shadow-2xl shadow-cyan-500/40 cursor-pointer transform active:scale-95 hover:scale-105 transition-transform duration-100 select-none z-10 group"
          >
            <div className="w-full h-full rounded-full bg-gradient-to-b from-slate-900 to-[#0b0f19] border-4 border-cyan-400 flex flex-col items-center justify-center shadow-inner relative overflow-hidden">
              <div className="absolute inset-0 bg-cyan-500/10 group-hover:bg-cyan-500/20 transition-colors pointer-events-none" />
              
              <Zap className="w-24 sm:w-32 h-24 sm:h-32 text-cyan-400 filter drop-shadow-[0_0_20px_rgba(6,182,212,0.6)] group-hover:rotate-12 transition-transform duration-300" />
              
              <span className="text-2xl font-black text-white font-['Space_Grotesk'] tracking-widest mt-2">
                NEXUS
              </span>
              <span className="text-xs font-bold text-cyan-400 tracking-widest uppercase">
                Klicker Arena
              </span>
            </div>

            {/* Floating Click Numbers */}
            {floatingTexts.map(item => (
              <span
                key={item.id}
                className="absolute text-2xl sm:text-3xl font-black text-cyan-300 font-['Space_Grotesk'] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] pointer-events-none animate-float"
                style={{
                  left: item.x,
                  top: item.y,
                  transform: 'translate(-50%, -100%)',
                  animationDuration: '1s'
                }}
              >
                {item.text}
              </span>
            ))}
          </div>

          {/* Energy Bar Display */}
          <div className="w-full mt-10 z-10 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between text-xs font-bold mb-2">
              <div className="flex items-center gap-1.5 text-amber-400">
                <BatteryCharging className="w-4 h-4 animate-pulse" />
                <span>Energie (Ausdauer)</span>
              </div>
              <span className="text-amber-400 font-mono">{user.energy} / {user.maxEnergy}</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-700 shadow-inner">
              <div 
                className="bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${(user.energy / user.maxEnergy) * 100}%` }}
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-2 text-center">
              Regeneriert automatisch +5 Energie pro Sekunde.
            </p>
          </div>

          {/* Level Progress Bar below coin */}
          <div className="w-full mt-4 z-10 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between text-xs font-bold mb-2">
              <div className="flex items-center gap-2">
                <span className="text-purple-400 bg-purple-500/20 px-2 py-0.5 rounded border border-purple-500/30">
                  Level {user.level} / 1200
                </span>
                <span className="text-slate-400">({user.league} Liga)</span>
              </div>
              <span className="text-cyan-400">{user.xp.toLocaleString()} / {user.nextLevelXp.toLocaleString()} XP</span>
            </div>

            <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-700 shadow-inner">
              <div 
                className="bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (user.xp / user.nextLevelXp) * 100)}%` }}
              />
            </div>
          </div>

        </div>

        {/* Right Column: Upgrades, Boosts, Squads & Mining Cards */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* --- DAILY FREE BOOSTS --- */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span>Tägliche Free Boosts</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                onClick={handleFullEnergyRefill}
                disabled={user.fullEnergyRefillsLeft <= 0}
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/50 flex flex-col items-center justify-center gap-2 group transition-all disabled:opacity-50"
              >
                <BatteryCharging className="w-6 h-6 text-amber-400 group-hover:scale-110 transition-transform" />
                <span className="font-extrabold text-white font-['Space_Grotesk'] text-sm">Full Energy Refill</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">{user.fullEnergyRefillsLeft}/3 Übrig</span>
              </button>

              <button
                onClick={handleTurboBoost}
                disabled={user.turboBoostsLeft <= 0}
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-rose-500/50 flex flex-col items-center justify-center gap-2 group transition-all disabled:opacity-50"
              >
                <Flame className="w-6 h-6 text-rose-400 group-hover:scale-110 transition-transform" />
                <span className="font-extrabold text-white font-['Space_Grotesk'] text-sm">Turbo Multi-Tap</span>
                <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded-full font-bold">{user.turboBoostsLeft}/3 Übrig</span>
              </button>
            </div>
          </div>

          {/* --- SQUADS SELECTION --- */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-400" />
                <span>Krypto Squad / Clan</span>
              </div>
              {user.activeSquad && <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">Aktiv: {user.activeSquad}</span>}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">Tritt einem Top-Clan bei, um einen permanenten <span className="text-cyan-400 font-bold">+10% Klick-Bonus</span> zu erhalten.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SQUADS.map(s => (
                <button
                  key={s.id}
                  onClick={() => handleSelectSquad(s.name)}
                  className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                    user.activeSquad === s.name 
                      ? 'bg-blue-600/20 border-blue-500 text-white shadow-lg shadow-blue-500/10' 
                      : 'bg-slate-950/80 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <span className="font-extrabold font-['Space_Grotesk'] text-sm text-white block">{s.name}</span>
                  <div className="flex items-center justify-between mt-2 text-[10px] text-slate-400">
                    <span>👥 {s.members}</span>
                    <span className="text-cyan-400 font-bold">{s.bonus}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* --- DAILY MORSE CIPHER --- */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4 bg-gradient-to-r from-purple-950/20 via-slate-900 to-slate-900">
            <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <Key className="w-5 h-5 text-purple-400" />
              <span>Daily Morse Cipher</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">Löse das heutige geheime Morse-Code Wort <span className="text-purple-400 font-bold">"NEXUS"</span> für +1.000.000 Coins!</p>
            
            <form onSubmit={handleCipherSubmit} className="flex items-center gap-2">
              <input 
                type="text"
                value={cipherInput}
                onChange={(e) => setCipherInput(e.target.value)}
                placeholder="Geheimes Wort eingeben..."
                disabled={user.dailyCipherClaimed}
                className="flex-grow bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-xl px-4 py-3 text-xs sm:text-sm text-white uppercase tracking-widest outline-none transition-all shadow-inner disabled:opacity-50"
              />
              <button 
                type="submit"
                disabled={user.dailyCipherClaimed || !cipherInput.trim()}
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow transition-all whitespace-nowrap flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{user.dailyCipherClaimed ? 'Gelöst ✓' : 'Lösen'}</span>
              </button>
            </form>
          </div>

          {/* --- PASSIVE MINING CARDS UPGRADES --- */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <span>Passive Mining Karten (Profit/h)</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">Investiere in Infrastruktur, um auch offline kontinuierlich Coins zu generieren.</p>
            <div className="space-y-3">
              {MINING_CARDS.map(card => (
                <div key={card.id} className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 flex items-center justify-between gap-4 shadow-inner">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shadow">{card.icon}</span>
                    <div>
                      <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-sm sm:text-base">{card.name}</h4>
                      <p className="text-[11px] text-slate-400">{card.desc}</p>
                      <span className="text-xs text-emerald-400 font-bold block mt-0.5">+{card.profit.toLocaleString()} Coins/h</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleBuyMiningCard(card)}
                    className="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-xs rounded-xl shadow transition-all whitespace-nowrap flex items-center gap-1"
                  >
                    <span>{card.cost.toLocaleString()} NEX</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Upgrades Panel (Click Multiplier & Auto Clicker) */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400" />
              <span>Klicker & Bot Upgrades</span>
            </h3>

            {/* Upgrade 1: Klick Multiplikator */}
            <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-inner">
              <div>
                <span className="text-xs font-bold text-purple-400 uppercase tracking-wider block">Klick-Booster</span>
                <h4 className="text-base font-extrabold text-white font-['Space_Grotesk']">Klick-Kraft +50</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Erhöht den Basiswert jedes Klicks um 50 Coins.</p>
                <span className="text-[11px] text-slate-500 block mt-1">Aktuell gekauft: {user.clickMultiplierUpgrade}x</span>
              </div>

              <button
                onClick={buyClickUpgrade}
                className="w-full sm:w-auto px-5 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1 whitespace-nowrap"
              >
                <span>{upgradeCost.toLocaleString()} Coins</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Upgrade 2: Auto Clicker */}
            <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-inner">
              <div>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">Automatisierung</span>
                <h4 className="text-base font-extrabold text-white font-['Space_Grotesk']">Auto-Klick Bot</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Klickt automatisch 1x pro Sekunde im Hintergrund.</p>
                <span className="text-[11px] text-slate-500 block mt-1">Aktive Bots: {user.autoClickerCount}</span>
              </div>

              <button
                onClick={buyAutoClicker}
                className="w-full sm:w-auto px-5 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1 whitespace-nowrap"
              >
                <span>{autoCost.toLocaleString()} Coins</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Level 1200 Explanation Card */}
          <div className="glass-panel-gold p-6 rounded-3xl border border-yellow-500/30 space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl pointer-events-none" />

            <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-400" />
              <span>Das Level 1200 System</span>
            </h4>

            <p className="text-xs text-slate-300 leading-relaxed">
              Unser Level-System skaliert bis zum ultimativen <span className="text-yellow-400 font-bold">Level 1200</span>. Mit jedem Level-Up steigt dein Klick-Profit und deine Staking-Macht drastisch an.
            </p>

            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between text-[11px] p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
                <span className="text-slate-300 font-semibold">Level 1 - 99 (Einsteiger)</span>
                <span className="text-slate-400 font-bold">Basis-Klick bis ~2.500 Coins</span>
              </div>
              <div className="flex items-center justify-between text-[11px] p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
                <span className="text-slate-300 font-semibold">Level 100 - 499 (Elite)</span>
                <span className="text-cyan-400 font-bold">Basis-Klick bis ~12.500 Coins</span>
              </div>
              <div className="flex items-center justify-between text-[11px] p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
                <span className="text-slate-300 font-semibold">Level 500 - 999 (Master)</span>
                <span className="text-purple-400 font-bold">Basis-Klick bis ~25.000 Coins</span>
              </div>
              <div className="flex items-center justify-between text-[11px] p-2.5 bg-slate-950/60 rounded-xl border border-yellow-500/30">
                <span className="text-yellow-400 font-extrabold">Level 1000 - 1200 (Apex God)</span>
                <span className="text-yellow-400 font-extrabold">Basis-Klick 30.000+ Coins</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 mt-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <span>Tipp: Kombiniere Auto-Klicker und hohe Liga-Stufen (z.B. Apex 3x Multiplikator), um in Rekordzeit Level 1200 zu erreichen!</span>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
