import React, { useState } from 'react';
import { UserState } from '../types';
import { SHARE_TEMPLATES } from '../data/mockData';
import { Share2, CheckCircle2, Copy, Send, MessageCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ShareModalProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  isOpen: boolean;
  onClose: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ user, setUser, isOpen, onClose, addToast }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [customText, setCustomText] = useState<string>(SHARE_TEMPLATES[0].text);

  if (!isOpen) return null;

  const handleShare = (index: number, text: string, platform: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    setUser(prev => {
      const newCoins = prev.coins + 500;
      let newXp = prev.xp + 50;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `🔗 Viral Share Bonus (${platform})`,
        amount: 500,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: newXp,
        level: newLevel,
        nextLevelXp,
        transactions: [newTx, ...prev.transactions]
      };
    });

    addToast('success', 'Erfolg geteilt!', `Du hast +500 Coins & +50 XP für das Teilen auf ${platform} erhalten.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      
      <div className="glass-panel-premium w-full max-w-2xl p-6 sm:p-8 rounded-3xl border-2 border-cyan-400 relative overflow-hidden shadow-2xl shadow-cyan-500/20">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20">
              <Share2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk']">
                Erfolge Teilen & Coins sichern
              </h3>
              <p className="text-xs text-slate-400">
                Teile deinen Status mit Freunden und erhalte für jeden Share sofort <span className="text-cyan-400 font-bold">+500 Coins</span>!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center font-bold text-lg transition-all"
          >
            ✕
          </button>
        </div>

        {/* Custom Text Area */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Dein persönlicher Einladungs- & Erfolgstext:
          </label>
          <textarea
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            rows={4}
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-2xl p-4 text-sm text-slate-200 outline-none transition-all resize-none shadow-inner leading-relaxed"
          />
        </div>

        {/* Share Buttons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          {SHARE_TEMPLATES.map((tpl, idx) => {
            const isCopied = copiedIndex === idx;

            return (
              <button
                key={tpl.platform}
                onClick={() => handleShare(idx, customText, tpl.platform)}
                className={`p-4 rounded-2xl flex items-center justify-between gap-3 text-white font-extrabold transition-all transform hover:-translate-y-0.5 shadow-lg ${tpl.color}`}
              >
                <div className="flex items-center gap-3">
                  {tpl.platform.includes('Twitter') && <Share2 className="w-5 h-5 text-white" />}
                  {tpl.platform.includes('Telegram') && <Send className="w-5 h-5 fill-white" />}
                  {tpl.platform.includes('WhatsApp') && <MessageCircle className="w-5 h-5 fill-white" />}
                  {tpl.platform.includes('Link') && <Copy className="w-5 h-5" />}
                  <span className="font-['Space_Grotesk'] text-sm sm:text-base">{tpl.platform}</span>
                </div>

                {isCopied ? (
                  <span className="flex items-center gap-1 text-xs bg-black/30 px-2.5 py-1 rounded-full border border-white/20">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Kopiert</span>
                  </span>
                ) : (
                  <span className="text-xs bg-black/20 px-2.5 py-1 rounded-full border border-white/20 hover:bg-black/40 transition-colors">
                    +500 Coins
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <span>Dein persönlicher Einladungslink:</span>
          <span className="text-cyan-400 font-bold select-all bg-slate-900 px-3 py-1 rounded-xl border border-slate-800">
            https://nexus-coin-arena.io/join?ref={user.name}
          </span>
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={onClose}
            className="px-8 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-sm rounded-xl transition-all"
          >
            Fenster schließen
          </button>
        </div>

      </div>

    </div>
  );
};
