import React from 'react';
import { ToastMessage } from '../types';
import { CheckCircle2, AlertCircle, Info, Sparkles, X } from 'lucide-react';

interface ToastContainerProps {
  toasts: ToastMessage[];
  removeToast: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, removeToast }) => {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full pointer-events-none px-4 sm:px-0">
      {toasts.map((toast) => {
        let bgStyle = 'bg-slate-900/95 border-slate-700 text-white';
        let Icon = Info;
        let iconColor = 'text-blue-400';

        if (toast.type === 'success') {
          bgStyle = 'bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950 border-emerald-500/50 text-white shadow-lg shadow-emerald-500/10';
          Icon = CheckCircle2;
          iconColor = 'text-emerald-400 animate-bounce';
        } else if (toast.type === 'error') {
          bgStyle = 'bg-gradient-to-r from-slate-900 via-slate-900 to-rose-950 border-rose-500/50 text-white shadow-lg shadow-rose-500/10';
          Icon = AlertCircle;
          iconColor = 'text-rose-400 animate-pulse';
        } else if (toast.type === 'drop') {
          bgStyle = 'bg-gradient-to-r from-purple-950 via-slate-900 to-amber-950 border-amber-500/50 text-white shadow-xl shadow-amber-500/20';
          Icon = Sparkles;
          iconColor = 'text-amber-400 animate-spin-slow';
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-4 rounded-2xl border backdrop-blur-xl flex items-start gap-3 transition-all animate-fade-in shadow-2xl ${bgStyle}`}
          >
            <Icon className={`w-6 h-6 flex-shrink-0 mt-0.5 ${iconColor}`} />
            
            <div className="flex-grow pr-2">
              <h5 className="text-sm font-extrabold font-['Space_Grotesk'] tracking-tight mb-0.5">
                {toast.title}
              </h5>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                {toast.message}
              </p>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-500 hover:text-white p-1 rounded-lg transition-colors flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
