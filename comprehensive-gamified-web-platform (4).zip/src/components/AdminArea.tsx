import React, { useState } from 'react';
import { UserState } from '../types';
import { Lock, ShieldCheck, Clock, Wallet, Share2, Save, CheckCircle2, AlertTriangle, Key } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AdminAreaProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const AdminArea: React.FC<AdminAreaProps> = ({ user, setUser, addToast }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');

  const [form, setForm] = useState(user.adminSettings);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim().toUpperCase() === 'ADMIN8842') {
      setIsAuthenticated(true);
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
      addToast('success', 'Admin Login Erfolgreich', 'Willkommen im dezentralen Nexus Kontrollzentrum.');
    } else {
      addToast('error', 'Zugriff verweigert', 'Falsche Admin-PIN eingegeben.');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setUser(prev => ({
      ...prev,
      adminSettings: form
    }));
    confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });
    addToast('success', 'Änderungen gespeichert!', 'Alle Timer, Adressen und Werbe-Einstellungen wurden live im Smart Contract aktualisiert.');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center animate-fade-in">
        <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border-2 border-rose-500/50 shadow-2xl shadow-rose-500/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mx-auto mb-6 shadow-lg animate-pulse">
            <Lock className="w-8 h-8" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-2">
            Nexus Admin Kontrollzentrum
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mb-8 leading-relaxed">
            Dieser Bereich ist für das Plattform-Management reserviert. Bitte gib deine verifizierte Master-PIN ein. <br />
            <span className="text-cyan-400 font-bold">(Tipp: PIN lautet ADMIN8842)</span>
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Key className="w-5 h-5 text-rose-400" />
              </div>
              <input 
                type="password"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Admin PIN eingeben..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-rose-500 rounded-2xl py-4 pl-12 pr-4 text-center text-lg font-black text-white tracking-widest outline-none transition-all shadow-inner"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-gradient-to-r from-rose-600 via-red-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-rose-500/25 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-5 h-5" />
              <span>Kontrollzentrum entsperren</span>
            </button>
          </form>

        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12 animate-fade-in">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-800 pb-8">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-rose-500 via-red-600 to-purple-600 text-white shadow-lg shadow-rose-500/20">
            <ShieldCheck className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Plattform-Konfiguration (Admin)
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Passe Live-Timer, Krypto-Einzahlungsadressen, Werbe-Intervalle und Community-Links in Echtzeit an.
            </p>
          </div>
        </div>

        <button 
          onClick={handleSave}
          className="px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-sm sm:text-base rounded-2xl shadow-xl shadow-emerald-500/20 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 whitespace-nowrap"
        >
          <Save className="w-5 h-5 fill-slate-950" />
          <span>Änderungen live speichern</span>
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-12">
        
        {/* --- SECTION 1: COUNTDOWN TIMER STEUERUNG --- */}
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <Clock className="w-6 h-6 text-cyan-400" />
            <div>
              <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk']">1. Börsen-Launch Countdown & Uhrzeit</h3>
              <p className="text-xs text-slate-400">Passe den verbleibenden Countdown für den offiziellen Coin Launch an.</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Tage</label>
              <input 
                type="number"
                min="0"
                value={form.countdownDays}
                onChange={(e) => setForm({ ...form, countdownDays: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-lg font-extrabold text-white outline-none transition-all shadow-inner text-center"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Stunden</label>
              <input 
                type="number"
                min="0" max="23"
                value={form.countdownHours}
                onChange={(e) => setForm({ ...form, countdownHours: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-lg font-extrabold text-white outline-none transition-all shadow-inner text-center"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Minuten</label>
              <input 
                type="number"
                min="0" max="59"
                value={form.countdownMinutes}
                onChange={(e) => setForm({ ...form, countdownMinutes: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-lg font-extrabold text-white outline-none transition-all shadow-inner text-center"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Sekunden</label>
              <input 
                type="number"
                min="0" max="59"
                value={form.countdownSeconds}
                onChange={(e) => setForm({ ...form, countdownSeconds: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-lg font-extrabold text-white outline-none transition-all shadow-inner text-center"
              />
            </div>
          </div>
        </div>

        {/* --- SECTION 2: PAY ADRESSEN VERWALTUNG --- */}
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <Wallet className="w-6 h-6 text-amber-400" />
            <div>
              <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk']">2. Krypto Payout- & Einzahlungsadressen</h3>
              <p className="text-xs text-slate-400">Hinterlege deine offiziellen Wallet-Adressen, auf welche die Nutzer beim Staking einzahlen sollen.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Bitcoin (BTC) Pay-Adresse</label>
              <input 
                type="text"
                value={form.payAddressBtc}
                onChange={(e) => setForm({ ...form, payAddressBtc: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-xl p-4 text-sm font-mono text-amber-300 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Ethereum (ETH) Pay-Adresse</label>
              <input 
                type="text"
                value={form.payAddressEth}
                onChange={(e) => setForm({ ...form, payAddressEth: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-400 rounded-xl p-4 text-sm font-mono text-indigo-300 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Solana (SOL) Pay-Adresse</label>
              <input 
                type="text"
                value={form.payAddressSol}
                onChange={(e) => setForm({ ...form, payAddressSol: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-sm font-mono text-purple-300 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Tether (USDT) Pay-Adresse</label>
              <input 
                type="text"
                value={form.payAddressUsdt}
                onChange={(e) => setForm({ ...form, payAddressUsdt: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 rounded-xl p-4 text-sm font-mono text-emerald-300 outline-none transition-all shadow-inner"
              />
            </div>
          </div>
        </div>

        {/* --- SECTION 3: WERBESYSTEM (ADSENSE) STEUERUNG --- */}
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-slate-800 space-y-6 shadow-xl bg-gradient-to-r from-blue-950/20 via-slate-900 to-slate-900">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <Clock className="w-6 h-6 text-emerald-400" />
            <div>
              <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk']">3. Werbe-Intervall & AdSense Einstellungen</h3>
              <p className="text-xs text-slate-300">Konfiguriere das Intervall (z.B. alle 8 Minuten) und die Dauer der Werbeeinblendung (mindestens 30 bis 40 Sekunden).</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Werbe-Intervall (Minuten)</label>
              <input 
                type="number"
                min="1" max="60"
                value={form.adIntervalMinutes}
                onChange={(e) => setForm({ ...form, adIntervalMinutes: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 rounded-xl p-4 text-lg font-extrabold text-white outline-none transition-all shadow-inner text-center"
              />
              <span className="text-[11px] text-slate-400 block mt-1">Standard: Alle 8 Minuten</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Werbe-Dauer (Sekunden)</label>
              <input 
                type="number"
                min="10" max="120"
                value={form.adDurationSeconds}
                onChange={(e) => setForm({ ...form, adDurationSeconds: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 rounded-xl p-4 text-lg font-extrabold text-white outline-none transition-all shadow-inner text-center"
              />
              <span className="text-[11px] text-slate-400 block mt-1">Standard: 35 Sekunden</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">AdSense Client / Partner URL</label>
              <input 
                type="text"
                value={form.adClientUrl}
                onChange={(e) => setForm({ ...form, adClientUrl: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 rounded-xl p-4 text-xs font-mono text-slate-300 outline-none transition-all shadow-inner"
              />
              <span className="text-[11px] text-slate-400 block mt-1">Verknüpfte Werbe-ID</span>
            </div>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 flex items-center gap-3 text-xs text-slate-300">
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
            <span>Die Plattform bleibt werbefrei, unterbricht die Nutzer jedoch exakt alle {form.adIntervalMinutes} Minuten mit dem konfigurierten Werbe-Overlay für {form.adDurationSeconds} Sekunden.</span>
          </div>
        </div>

        {/* --- SECTION 4: SOCIAL MEDIA & COMMUNITY LINKS --- */}
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <Share2 className="w-6 h-6 text-purple-400" />
            <div>
              <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk']">4. Social Media & Community Links</h3>
              <p className="text-xs text-slate-400">Ändere die URLs für deine YouTube, Telegram, Discord, Reddit, X und Facebook Kanäle im Footer und Trust Hub.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">YouTube URL</label>
              <input 
                type="text"
                value={form.socialYoutube}
                onChange={(e) => setForm({ ...form, socialYoutube: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-xs text-slate-200 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Telegram URL</label>
              <input 
                type="text"
                value={form.socialTelegram}
                onChange={(e) => setForm({ ...form, socialTelegram: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-xs text-slate-200 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Discord URL</label>
              <input 
                type="text"
                value={form.socialDiscord}
                onChange={(e) => setForm({ ...form, socialDiscord: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-xs text-slate-200 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Reddit URL</label>
              <input 
                type="text"
                value={form.socialReddit}
                onChange={(e) => setForm({ ...form, socialReddit: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-xs text-slate-200 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">X (Twitter) URL</label>
              <input 
                type="text"
                value={form.socialX}
                onChange={(e) => setForm({ ...form, socialX: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-xs text-slate-200 outline-none transition-all shadow-inner"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Facebook URL</label>
              <input 
                type="text"
                value={form.socialFacebook}
                onChange={(e) => setForm({ ...form, socialFacebook: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-400 rounded-xl p-4 text-xs text-slate-200 outline-none transition-all shadow-inner"
              />
            </div>
          </div>
        </div>

        <div className="text-center pt-6">
          <button 
            type="submit"
            className="px-10 py-5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-base rounded-2xl shadow-2xl shadow-emerald-500/20 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2 mx-auto"
          >
            <CheckCircle2 className="w-6 h-6 fill-slate-950" />
            <span>Alle Einstellungen im Smart Contract sichern</span>
          </button>
        </div>

      </form>

    </div>
  );
};
