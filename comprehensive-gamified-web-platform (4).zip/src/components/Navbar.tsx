import React from 'react';
import { UserState, ActiveTab } from '../types';
import { Coins, Trophy, Zap, Gift, Gamepad2, TrendingUp, Rocket, Handshake, Share2, MousePointer, Target, History, FileText, Package, Award, BarChart3, User } from 'lucide-react';

interface NavbarProps {
  user: UserState;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenShare: () => void;
  onQuickDeposit: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeTab,
  setActiveTab,
  onOpenShare,
  onQuickDeposit
}) => {
  return (
    <header className="sticky top-0 z-50 glass-panel border-b border-slate-800/80 bg-[#0b0f19]/90 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 p-[2px] shadow-lg shadow-cyan-500/20 group">
              <div className="flex items-center justify-center w-full h-full bg-[#0b0f19] rounded-[10px] group-hover:bg-transparent transition-all duration-300">
                <Zap className="w-6 h-6 text-cyan-400 group-hover:text-white transition-colors" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-2xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-500 font-['Space_Grotesk']">
                  NEXUS
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-semibold tracking-wider uppercase">
                  Arena
                </span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-wider uppercase font-medium">Crypto Gamification & Staking</p>
            </div>
          </div>

          {/* Navigation Tabs (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar max-w-[65%]">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => setActiveTab('clicker')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'clicker'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <MousePointer className="w-3.5 h-3.5 text-cyan-400" />
              <span>Klicker</span>
            </button>

            <button
              onClick={() => setActiveTab('invest')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'invest'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Staking</span>
            </button>

            <button
              onClick={() => setActiveTab('surveys')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'surveys'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>Offerwall</span>
            </button>

            <button
              onClick={() => setActiveTab('chests')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'chests'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Package className="w-3.5 h-3.5 text-yellow-400" />
              <span>Truhen</span>
            </button>

            <button
              onClick={() => setActiveTab('nfts')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'nfts'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-purple-400" />
              <span>NFTs</span>
            </button>

            <button
              onClick={() => setActiveTab('league')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'league'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Trophy className="w-3.5 h-3.5 text-yellow-400" />
              <span>Liga</span>
            </button>

            <button
              onClick={() => setActiveTab('wheel')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'wheel'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Gift className="w-3.5 h-3.5 text-rose-400" />
              <span>Glücksrad</span>
              {user.spinsLeft > 0 && (
                <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-bold animate-pulse">
                  {user.spinsLeft}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('minigames')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'minigames'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5 text-purple-400" />
              <span>Spiele</span>
            </button>

            <button
              onClick={() => setActiveTab('quests')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'quests'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-purple-400" />
              <span>Quests</span>
            </button>

            <button
              onClick={() => setActiveTab('freelaunch')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'freelaunch'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Rocket className="w-3.5 h-3.5 text-emerald-400" />
              <span>FreeLaunch</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'history'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <History className="w-3.5 h-3.5 text-blue-400" />
              <span>Logbuch</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'analytics'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Analysen</span>
            </button>

            <button
              onClick={() => setActiveTab('member')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'member'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <User className="w-3.5 h-3.5 text-cyan-400" />
              <span>Mitgliederbereich</span>
            </button>

            <button
              onClick={() => setActiveTab('partners')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap ${
                activeTab === 'partners'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Handshake className="w-3.5 h-3.5 text-blue-400" />
              <span>Partner</span>
            </button>
          </nav>

          {/* User Stats & Quick Actions */}
          <div className="flex items-center gap-3">
            {/* Coins Balance */}
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-700/60 px-3.5 py-2 rounded-2xl shadow-inner">
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-yellow-500 to-amber-300 flex items-center justify-center shadow-md shadow-amber-500/20 animate-pulse">
                <Coins className="w-4 h-4 text-slate-950 font-extrabold" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider leading-none">Guthaben</span>
                <span className="text-base font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
                  {user.coins.toLocaleString('de-DE')} <span className="text-cyan-400 text-xs font-bold">NEX</span>
                </span>
              </div>
            </div>

            {/* Level Badge */}
            <div 
              onClick={() => setActiveTab('clicker')} 
              className="hidden sm:flex items-center gap-2.5 bg-gradient-to-r from-purple-950/60 to-slate-900/80 border border-purple-500/30 px-3.5 py-2 rounded-2xl cursor-pointer hover:border-purple-500/60 transition-all"
              title="Klicke für Klicker & Level Details"
            >
              <div className="w-7 h-7 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 font-bold text-xs shadow-sm">
                LVL
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 leading-none mb-0.5">
                  <span className="text-xs font-bold text-slate-200">Level {user.level} / 1200</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 font-semibold">
                    {user.league}
                  </span>
                </div>
                {/* XP Bar */}
                <div className="w-20 bg-slate-800 rounded-full h-1.5 overflow-hidden border border-slate-700">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-cyan-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${(user.xp / user.nextLevelXp) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Quick Deposit Button */}
            <button
              onClick={onQuickDeposit}
              className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-extrabold px-4 py-2.5 rounded-2xl shadow-lg shadow-amber-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-sm"
            >
              <Zap className="w-4 h-4 fill-slate-950" />
              <span className="hidden md:inline font-['Space_Grotesk']">Investieren</span>
            </button>

            {/* Share Button */}
            <button
              onClick={onOpenShare}
              className="flex items-center justify-center w-11 h-11 rounded-2xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-all shadow-md group"
              title="Erfolg teilen & 500 Coins erhalten!"
            >
              <Share2 className="w-5 h-5 group-hover:scale-110 transition-transform text-cyan-400" />
            </button>

          </div>

        </div>

        {/* Mobile Navigation Bar */}
        <div className="flex lg:hidden items-center justify-between py-2 border-t border-slate-800/60 overflow-x-auto gap-2 no-scrollbar">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'dashboard' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('clicker')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'clicker' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <MousePointer className="w-3.5 h-3.5 text-cyan-400" />
            <span>Klicker</span>
          </button>

          <button
            onClick={() => setActiveTab('invest')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'invest' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Staking</span>
          </button>

          <button
            onClick={() => setActiveTab('surveys')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'surveys' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>Offerwall</span>
          </button>

          <button
            onClick={() => setActiveTab('chests')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'chests' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Package className="w-3.5 h-3.5 text-yellow-400" />
            <span>Truhen</span>
          </button>

          <button
            onClick={() => setActiveTab('nfts')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'nfts' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-purple-400" />
            <span>NFTs</span>
          </button>

          <button
            onClick={() => setActiveTab('league')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'league' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span>Liga</span>
          </button>

          <button
            onClick={() => setActiveTab('wheel')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'wheel' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Gift className="w-3.5 h-3.5 text-rose-400" />
            <span>Glücksrad</span>
            {user.spinsLeft > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-bold">
                {user.spinsLeft}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('minigames')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'minigames' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5 text-purple-400" />
            <span>Spiele</span>
          </button>

          <button
            onClick={() => setActiveTab('quests')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'quests' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Target className="w-3.5 h-3.5 text-purple-400" />
            <span>Quests</span>
          </button>

          <button
            onClick={() => setActiveTab('freelaunch')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'freelaunch' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Rocket className="w-3.5 h-3.5 text-emerald-400" />
            <span>FreeLaunch</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'history' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <History className="w-3.5 h-3.5 text-blue-400" />
            <span>Logbuch</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'analytics' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Analysen</span>
          </button>

          <button
            onClick={() => setActiveTab('member')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'member' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <User className="w-3.5 h-3.5 text-cyan-400" />
            <span>Mitglieder</span>
          </button>

          <button
            onClick={() => setActiveTab('partners')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === 'partners' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800/50'
            }`}
          >
            <Handshake className="w-3.5 h-3.5 text-blue-400" />
            <span>Partner</span>
          </button>
        </div>

      </div>
    </header>
  );
};
