import React, { useState } from 'react';
import { UserState } from '../types';
import { Gift, Award, RotateCw, AlertCircle, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface WheelOfFortuneProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  onOpenShare: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

const WHEEL_PRIZES = [
  { id: 1, label: '5.000 Coins', type: 'coins', value: 5000, color: 'bg-gradient-to-r from-amber-500 to-yellow-400', text: 'text-slate-950 font-extrabold' },
  { id: 2, label: '2x Multiplikator', type: 'multiplier', value: 2, color: 'bg-gradient-to-r from-cyan-500 to-blue-600', text: 'text-white font-extrabold' },
  { id: 3, label: '10.000 Coins', type: 'coins', value: 10000, color: 'bg-gradient-to-r from-purple-600 to-pink-500', text: 'text-white font-extrabold' },
  { id: 4, label: '5 Freispiele', type: 'spins', value: 5, color: 'bg-gradient-to-r from-emerald-500 to-teal-400', text: 'text-slate-950 font-extrabold' },
  { id: 5, label: '1.000 Coins', type: 'coins', value: 1000, color: 'bg-gradient-to-r from-slate-700 to-slate-600', text: 'text-white font-bold' },
  { id: 6, label: 'VIP Mystery Box', type: 'mystery', value: 25000, color: 'bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600', text: 'text-slate-950 font-extrabold' },
  { id: 7, label: '20.000 Mega Coins', type: 'coins', value: 20000, color: 'bg-gradient-to-r from-rose-600 to-red-500', text: 'text-white font-extrabold' },
  { id: 8, label: '+500 XP Boost', type: 'xp', value: 500, color: 'bg-gradient-to-r from-blue-600 to-indigo-600', text: 'text-white font-extrabold' },
];

export const WheelOfFortune: React.FC<WheelOfFortuneProps> = ({ user, setUser, onOpenShare, addToast }) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<typeof WHEEL_PRIZES[0] | null>(null);

  const spinWheel = () => {
    if (isSpinning) return;
    
    // Check if user has spins or coins
    if (user.spinsLeft <= 0 && user.coins < 500) {
      addToast('error', 'Nicht genug Guthaben', 'Du benötigst mindestens 500 Coins für einen Dreh am Glücksrad.');
      return;
    }

    setIsSpinning(true);
    setWonPrize(null);

    // Deduct spin or coins & log
    setUser(prev => {
      if (prev.spinsLeft > 0) {
        return { ...prev, spinsLeft: prev.spinsLeft - 1 };
      } else {
        const newTx = {
          id: `TX-${Date.now()}`,
          type: 'spend' as const,
          title: '🎡 Glücksrad Dreh (Kauf)',
          amount: 500,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        };
        return { 
          ...prev, 
          coins: prev.coins - 500,
          transactions: [newTx, ...prev.transactions]
        };
      }
    });

    // Random prize calculation
    const randomIndex = Math.floor(Math.random() * WHEEL_PRIZES.length);
    const selectedPrize = WHEEL_PRIZES[randomIndex];

    // Calculate rotation angle (each slice is 45 degrees)
    const sliceAngle = 360 / WHEEL_PRIZES.length;
    const targetAngle = 360 - (randomIndex * sliceAngle) - (sliceAngle / 2); // Center of slice
    const totalRotation = rotation + 1800 + targetAngle + (Math.random() * 20 - 10);

    setRotation(totalRotation);

    // Wait for animation to finish (4 seconds)
    setTimeout(() => {
      setIsSpinning(false);
      setWonPrize(selectedPrize);

      // Trigger Confetti
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });

      // Apply prize to user state & log
      setUser(prev => {
        let newCoins = prev.coins;
        let newXp = prev.xp;
        let newSpins = prev.spinsLeft;
        let earnAmount = 0;
        let titleStr = `🎡 Glücksrad Gewinn: ${selectedPrize.label}`;

        if (selectedPrize.type === 'coins') {
          newCoins += selectedPrize.value;
          earnAmount = selectedPrize.value;
        } else if (selectedPrize.type === 'multiplier') {
          newCoins += 5000;
          earnAmount = 5000;
        } else if (selectedPrize.type === 'spins') {
          newSpins += selectedPrize.value;
        } else if (selectedPrize.type === 'mystery') {
          newCoins += 25000;
          newXp += 1000;
          earnAmount = 25000;
        } else if (selectedPrize.type === 'xp') {
          newXp += selectedPrize.value;
        }

        // Check level up
        let newLevel = prev.level;
        let nextLevelXp = prev.nextLevelXp;
        while (newXp >= nextLevelXp && newLevel < 1200) {
          newLevel += 1;
          newXp -= nextLevelXp;
          nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
        }

        const newTx = earnAmount > 0 ? [{
          id: `TX-${Date.now()}`,
          type: 'earn' as const,
          title: titleStr,
          amount: earnAmount,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        }] : [];

        return {
          ...prev,
          coins: newCoins,
          xp: newXp,
          level: newLevel,
          nextLevelXp,
          spinsLeft: newSpins,
          transactions: [...newTx, ...prev.transactions]
        };
      });

      addToast('drop', '🎡 Glücksrad Gewinn!', `Du hast ${selectedPrize.label} gewonnen!`);

    }, 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Title */}
      <div className="flex items-center gap-4 mb-12">
        <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-rose-50 to-purple-600 text-white shadow-lg shadow-rose-500/20">
          <Gift className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
            Das Nexus Glücksrad
          </h2>
          <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
            Drehe am Rad der Giganten und gewinne Mega-Coin-Pakete, Freispiele, Multiplikatoren und exklusive VIP Mystery Truhen.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Wheel Display & Animation */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center relative">
          
          {/* Outer glowing frame */}
          <div className="absolute w-[340px] sm:w-[440px] h-[340px] sm:h-[440px] rounded-full bg-gradient-to-tr from-rose-500 via-purple-600 to-cyan-500 p-3 shadow-2xl shadow-rose-500/30 animate-pulse-glow">
            <div className="w-full h-full rounded-full bg-[#0b0f19]" />
          </div>

          {/* Pointer / Flapper */}
          <div className="absolute top-0 z-30 -mt-4 w-0 h-0 border-l-[20px] border-l-transparent border-r-[20px] border-r-transparent border-t-[35px] border-t-yellow-400 filter drop-shadow-[0_4px_8px_rgba(250,204,21,0.5)]" />

          {/* Actual Rotating Wheel */}
          <div 
            className="w-[300px] sm:w-[400px] h-[300px] sm:h-[400px] rounded-full relative overflow-hidden border-4 border-slate-800 shadow-inner transition-transform duration-4000 ease-[cubic-bezier(0.15,0.85,0.15,1)] z-20"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            {/* We create 8 slices using CSS conic-gradient or absolute positioned segments */}
            {WHEEL_PRIZES.map((prize, index) => {
              const angle = (360 / WHEEL_PRIZES.length) * index;
              return (
                <div
                  key={prize.id}
                  className={`absolute top-0 left-0 w-full h-full flex items-start justify-center pt-8 origin-center ${prize.color} ${prize.text}`}
                  style={{
                    transform: `rotate(${angle}deg)`,
                    clipPath: 'polygon(50% 50%, 0% 0%, 100% 0%)'
                  }}
                >
                  <span className="text-xs sm:text-sm font-black uppercase tracking-wider transform -rotate-90 mt-12 block font-['Space_Grotesk'] drop-shadow">
                    {prize.label}
                  </span>
                </div>
              );
            })}

            {/* Center Cap */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-gradient-to-tr from-slate-900 to-slate-800 border-4 border-yellow-400 flex items-center justify-center shadow-xl z-30">
              <Award className="w-8 h-8 text-yellow-400 animate-pulse" />
            </div>
          </div>

          {/* Spin Button */}
          <div className="mt-12 z-20">
            <button
              onClick={spinWheel}
              disabled={isSpinning}
              className={`px-10 py-5 rounded-3xl font-extrabold text-lg shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] flex items-center gap-3 ${
                isSpinning
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed scale-95'
                  : user.spinsLeft > 0
                  ? 'bg-gradient-to-r from-rose-500 via-purple-600 to-cyan-500 hover:from-rose-400 hover:to-cyan-400 text-white shadow-rose-500/30 animate-bounce'
                  : 'bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-slate-950 shadow-amber-500/30'
              }`}
            >
              <RotateCw className={`w-6 h-6 ${isSpinning ? 'animate-spin' : ''}`} />
              <span>
                {isSpinning 
                  ? 'Rad dreht sich...' 
                  : user.spinsLeft > 0 
                  ? `JETZT DREHEN (${user.spinsLeft} Freispiele)` 
                  : 'Drehen für 500 Coins'}
              </span>
            </button>
          </div>

        </div>

        {/* Info & Won Prize Modal Panel */}
        <div className="lg:col-span-5 space-y-6">
          
          {wonPrize && (
            <div className="glass-panel-premium p-8 rounded-3xl border-2 border-yellow-400 bg-gradient-to-b from-yellow-500/20 via-slate-900 to-slate-900 animate-fade-in shadow-2xl shadow-yellow-500/20 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/20 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center gap-3 mb-4">
                <Sparkles className="w-8 h-8 text-yellow-400 animate-spin-slow" />
                <span className="text-sm font-extrabold text-yellow-400 uppercase tracking-widest">Hauptgewinn erzielt!</span>
              </div>

              <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
                {wonPrize.label}
              </h3>
              <p className="text-sm text-slate-300 mb-6 leading-relaxed">
                Dein Gewinn wurde deinem Nexus-Konto direkt gutgeschrieben. Teile diesen epischen Erfolg mit deiner Community und erhalte weitere <span className="text-cyan-400 font-bold">+500 Bonus Coins</span>!
              </p>

              <div className="flex flex-wrap items-center gap-4">
                <button
                  onClick={onOpenShare}
                  className="px-6 py-3.5 bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-cyan-500/25 transition-all transform hover:-translate-y-0.5"
                >
                  Erfolg Teilen (+500 Coins)
                </button>
                <button
                  onClick={spinWheel}
                  disabled={isSpinning}
                  className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-2xl border border-slate-700 transition-all"
                >
                  Nochmal drehen
                </button>
              </div>
            </div>
          )}

          {/* Rules & Odds Card */}
          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-6">
            <h4 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <Award className="w-5 h-5 text-rose-400" />
              <span>Spielregeln & Gewinnchancen</span>
            </h4>

            <p className="text-sm text-slate-300 leading-relaxed">
              Jeder Dreh am Glücksrad ist fair und basiert auf dem geprüften Nexus RNG-Algorithmus. Es gibt keine Nieten – jeder Dreh gewinnt garantiert!
            </p>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs sm:text-sm p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-slate-300 font-semibold">Coins & Multiplikatoren</span>
                <span className="text-emerald-400 font-bold">62.5% Chance</span>
              </div>
              <div className="flex items-center justify-between text-xs sm:text-sm p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-slate-300 font-semibold">Freispiele & XP Boosts</span>
                <span className="text-cyan-400 font-bold">25.0% Chance</span>
              </div>
              <div className="flex items-center justify-between text-xs sm:text-sm p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-slate-300 font-semibold">VIP Mystery Box ($25k Value)</span>
                <span className="text-amber-400 font-extrabold">12.5% Chance</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-400">
              <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
              <span>Tipp: Schließe Staking-Pakete ab, um regelmäßig bis zu +100 Freispiele als Prämie zu erhalten!</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
