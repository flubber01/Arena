import React from 'react';
import { PARTNER_LOGOS } from '../data/mockData';
import { ShieldCheck } from 'lucide-react';

export const PartnerTicker: React.FC = () => {
  return (
    <div className="border-t border-b border-slate-800/80 bg-[#0b0f19]/95 py-10 relative overflow-hidden pointer-events-none select-none shadow-2xl">
      
      {/* Gradients for smooth fade on left/right edges */}
      <div className="absolute top-0 left-0 bottom-0 w-24 sm:w-40 bg-gradient-to-r from-[#0b0f19] to-transparent z-10 pointer-events-none" />
      <div className="absolute top-0 right-0 bottom-0 w-24 sm:w-40 bg-gradient-to-l from-[#0b0f19] to-transparent z-10 pointer-events-none" />

      {/* Header Info Tag */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 text-center relative z-20">
        <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-extrabold uppercase tracking-widest shadow-lg shadow-cyan-500/10">
          <ShieldCheck className="w-4 h-4 text-cyan-400" />
          <span>Verifizierte Liquiditätspartner, Börsen & Institutionelle Anbindungen</span>
        </div>
      </div>

      {/* Marquee Container (Slowmo Left to Right) */}
      <div className="flex overflow-hidden">
        <div className="animate-marquee-ltr-slow flex items-center gap-12 sm:gap-16 py-2">
          
          {/* Render list twice for smooth infinite loop */}
          {PARTNER_LOGOS.map((partner, idx) => (
            <div key={`logo-1-${idx}`} className="flex items-center gap-3.5 flex-shrink-0 opacity-80 hover:opacity-100 transition-all duration-300 transform hover:scale-105">
              {partner.isText ? (
                <div className="px-4 py-2 rounded-xl bg-slate-900/90 border border-slate-700/80 shadow-inner flex items-center justify-center">
                  <span className={`font-extrabold text-lg tracking-wider ${
                    partner.name.includes('Sparkasse') ? 'text-red-500 font-sans' :
                    partner.name.includes('Nasdaq') ? 'text-blue-400 font-mono tracking-widest' :
                    partner.name.includes('BlackRock') ? 'text-slate-100 font-serif tracking-tighter' :
                    'text-white font-["Space_Grotesk"]'
                  }`}>
                    {partner.textLogo}
                  </span>
                </div>
              ) : (
                <img 
                  src={partner.logo} 
                  alt={partner.name} 
                  className="h-8 sm:h-11 w-auto object-contain filter drop-shadow-[0_2px_8px_rgba(255,255,255,0.15)]" 
                />
              )}
              <div className="flex flex-col">
                <span className="text-sm font-extrabold text-white font-['Space_Grotesk'] tracking-tight leading-tight">{partner.name}</span>
                <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">{partner.type}</span>
              </div>
            </div>
          ))}

          {PARTNER_LOGOS.map((partner, idx) => (
            <div key={`logo-2-${idx}`} className="flex items-center gap-3.5 flex-shrink-0 opacity-80 hover:opacity-100 transition-all duration-300 transform hover:scale-105">
              {partner.isText ? (
                <div className="px-4 py-2 rounded-xl bg-slate-900/90 border border-slate-700/80 shadow-inner flex items-center justify-center">
                  <span className={`font-extrabold text-lg tracking-wider ${
                    partner.name.includes('Sparkasse') ? 'text-red-500 font-sans' :
                    partner.name.includes('Nasdaq') ? 'text-blue-400 font-mono tracking-widest' :
                    partner.name.includes('BlackRock') ? 'text-slate-100 font-serif tracking-tighter' :
                    'text-white font-["Space_Grotesk"]'
                  }`}>
                    {partner.textLogo}
                  </span>
                </div>
              ) : (
                <img 
                  src={partner.logo} 
                  alt={partner.name} 
                  className="h-8 sm:h-11 w-auto object-contain filter drop-shadow-[0_2px_8px_rgba(255,255,255,0.15)]" 
                />
              )}
              <div className="flex flex-col">
                <span className="text-sm font-extrabold text-white font-['Space_Grotesk'] tracking-tight leading-tight">{partner.name}</span>
                <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">{partner.type}</span>
              </div>
            </div>
          ))}

        </div>
      </div>

    </div>
  );
};
