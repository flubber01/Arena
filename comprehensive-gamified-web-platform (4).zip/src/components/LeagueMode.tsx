import React, { useState } from 'react';
import { UserState } from '../types';
import { LEAGUES, INITIAL_LEADERBOARD } from '../data/mockData';
import { Trophy, TrendingUp, ShieldCheck, Award } from 'lucide-react';

interface LeagueModeProps {
  user: UserState;
  onQuickDeposit: () => void;
}

export const LeagueMode: React.FC<LeagueModeProps> = ({ user, onQuickDeposit }) => {
  const [activeLeagueTab, setActiveLeagueTab] = useState<string>('all');

  // Insert current user into leaderboard for realistic simulation
  const currentUserLeaderboardEntry = {
    id: 'current-user',
    rank: 11, // simulated rank
    name: user.name,
    avatar: user.avatar,
    coins: user.coins,
    invested: user.investedAmount,
    level: user.level,
    league: user.league,
    isCurrentUser: true
  };

  const combinedLeaderboard = [...INITIAL_LEADERBOARD, currentUserLeaderboardEntry].sort((a, b) => b.coins - a.coins);
  // Re-assign ranks
  combinedLeaderboard.forEach((item, index) => {
    item.rank = index + 1;
  });

  const filteredLeaderboard = activeLeagueTab === 'all' 
    ? combinedLeaderboard 
    : combinedLeaderboard.filter(item => item.league === activeLeagueTab);

  const currentLeagueInfo = LEAGUES.find(l => l.name === user.league) || LEAGUES[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-yellow-500 to-amber-600 text-slate-950 shadow-lg shadow-yellow-500/20">
            <Trophy className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Nexus Liga & Level System
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Erreiche höhere Stufen durch Aktivität und Staking-Investments. Jedes Level-Up und jeder Liga-Aufstieg steigern deine prozentuale Ausschüttung und deine Coin-Gewinne!
            </p>
          </div>
        </div>

        <button
          onClick={onQuickDeposit}
          className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-xl shadow-cyan-500/20 transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] text-sm"
        >
          <TrendingUp className="w-4 h-4" />
          <span>Investment erhöhen & Aufsteigen</span>
        </button>
      </div>

      {/* User Current Standing Info Card */}
      <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl mb-12 relative overflow-hidden border border-cyan-500/30 shadow-2xl shadow-cyan-500/10">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-center">
          
          <div className="flex items-center gap-5 lg:border-r border-slate-800 lg:pr-8">
            <img src={user.avatar} alt={user.name} className="w-20 h-20 rounded-2xl border-2 border-cyan-400 shadow-lg object-cover" />
            <div>
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Dein Status</span>
              <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] mt-0.5">{user.name}</h3>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-xs px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/30 font-bold">
                  Level {user.level}
                </span>
                <span className="text-xs px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
                  {user.league} Liga
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Aktueller ROI Boost</span>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-white font-['Space_Grotesk']">+{currentLeagueInfo.roiBonus}%</span>
              <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">Aktiv</span>
            </div>
            <p className="text-xs text-slate-400">Zusätzliche Rendite auf alle Staking-Pakete</p>
          </div>

          <div className="space-y-2">
            <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Coin Multiplikator</span>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-white font-['Space_Grotesk']">{currentLeagueInfo.coinMultiplier}x</span>
              <span className="text-xs text-cyan-400 font-bold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">Aktiv</span>
            </div>
            <p className="text-xs text-slate-400">Erhöht alle Gewinne in den Minispielen</p>
          </div>

          <div className="space-y-2 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-400">Fortschritt bis Level {user.level + 1}</span>
              <span className="text-cyan-400 font-bold">{user.xp} / {user.nextLevelXp} XP</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden border border-slate-700">
              <div 
                className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${(user.xp / user.nextLevelXp) * 100}%` }}
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Investiere oder spiele Minispiele, um schneller aufzusteigen!
            </p>
          </div>

        </div>

      </div>

      {/* League Tiers Grid */}
      <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] mb-6 flex items-center gap-2">
        <ShieldCheck className="w-6 h-6 text-cyan-400" />
        <span>Die 6 Elite-Stufen im Detail</span>
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
        {LEAGUES.map((league) => {
          const isUserCurrent = user.league === league.name;
          return (
            <div 
              key={league.name}
              className={`p-6 sm:p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all group ${
                isUserCurrent 
                  ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-cyan-400 shadow-2xl shadow-cyan-500/20' 
                  : 'bg-slate-900/80 border border-slate-800 hover:border-slate-700 shadow-xl'
              }`}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-white/5 to-transparent rounded-full pointer-events-none" />

              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-3xl">{league.badgeUrl}</span>
                    <h4 className="text-2xl font-extrabold text-white font-['Space_Grotesk']">{league.name}</h4>
                  </div>
                  {isUserCurrent && (
                    <span className="text-xs font-extrabold bg-cyan-500 text-slate-950 px-3 py-1 rounded-full shadow-md animate-pulse">
                      Deine Liga
                    </span>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed min-h-[40px]">
                  {league.description}
                </p>

                {/* Benefits List */}
                <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80 mb-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400 font-medium">ROI Ausschüttung:</span>
                    <span className="font-extrabold text-emerald-400 font-['Space_Grotesk'] text-base">+{league.roiBonus}% Boost</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400 font-medium">Minispiel Multiplikator:</span>
                    <span className="font-extrabold text-cyan-400 font-['Space_Grotesk'] text-base">{league.coinMultiplier}x</span>
                  </div>
                </div>
              </div>

              {/* Requirements */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <div>
                  <span className="block font-medium">Mindest-Investment:</span>
                  <span className="font-bold text-white">${league.minInvestment.toLocaleString()}</span>
                </div>
                <div className="text-right">
                  <span className="block font-medium">Benötigtes Level:</span>
                  <span className="font-bold text-white">Level {league.minLevel}</span>
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* Leaderboard Section */}
      <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] mb-1 flex items-center gap-2">
              <Award className="w-6 h-6 text-yellow-400" />
              <span>Globale Krypto Bestenliste</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Die erfolgreichsten Investoren und Spieler im Nexus-Ökosystem.
            </p>
          </div>

          {/* League Filter Tabs */}
          <div className="flex items-center gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveLeagueTab('all')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                activeLeagueTab === 'all' ? 'bg-cyan-500 text-slate-950 font-extrabold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Alle Ligen
            </button>
            {LEAGUES.map(l => (
              <button
                key={l.name}
                onClick={() => setActiveLeagueTab(l.name)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeLeagueTab === l.name ? 'bg-cyan-500 text-slate-950 font-extrabold' : 'text-slate-400 hover:text-white'
                }`}
              >
                {l.name}
              </button>
            ))}
          </div>
        </div>

        {/* Leaderboard Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-4 px-4">Rang</th>
                <th className="py-4 px-4">Investor / Spieler</th>
                <th className="py-4 px-4">Liga</th>
                <th className="py-4 px-4">Level</th>
                <th className="py-4 px-4">Investiert</th>
                <th className="py-4 px-4 text-right">Coins Guthaben</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-sm">
              {filteredLeaderboard.map((row) => {
                const isCurrent = row.isCurrentUser;
                const leagueObj = LEAGUES.find(l => l.name === row.league) || LEAGUES[0];

                return (
                  <tr 
                    key={row.id}
                    className={`transition-colors hover:bg-slate-800/40 ${
                      isCurrent ? 'bg-cyan-500/10 font-semibold border-l-4 border-cyan-400' : ''
                    }`}
                  >
                    <td className="py-4 px-4 font-['Space_Grotesk'] font-bold">
                      <div className="flex items-center gap-1">
                        {row.rank === 1 && <span className="text-yellow-400">🥇</span>}
                        {row.rank === 2 && <span className="text-slate-300">🥈</span>}
                        {row.rank === 3 && <span className="text-amber-500">🥉</span>}
                        {row.rank > 3 && <span className="text-slate-400">#{row.rank}</span>}
                      </div>
                    </td>

                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img src={row.avatar} alt={row.name} className="w-10 h-10 rounded-xl object-cover border border-slate-700 shadow" />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className={`font-bold ${isCurrent ? 'text-cyan-400' : 'text-white'}`}>{row.name}</span>
                            {isCurrent && <span className="text-[10px] bg-cyan-500 text-slate-950 px-1.5 py-0.2 rounded font-extrabold">DU</span>}
                          </div>
                          <span className="text-[11px] text-slate-400">ID: {row.id === 'current-user' ? 'NEX-8842' : `NEX-${row.id}092`}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-4">
                      <div className="flex items-center gap-1.5">
                        <span>{leagueObj.badgeUrl}</span>
                        <span className="font-bold text-slate-200">{row.league}</span>
                      </div>
                    </td>

                    <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-purple-400">
                      LVL {row.level}
                    </td>

                    <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-emerald-400">
                      ${row.invested.toLocaleString()}
                    </td>

                    <td className="py-4 px-4 text-right font-['Space_Grotesk'] font-extrabold text-white text-base">
                      {row.coins.toLocaleString()} <span className="text-xs text-cyan-400 font-bold">NEX</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
};
