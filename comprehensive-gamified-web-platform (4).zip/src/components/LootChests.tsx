import React from 'react';
import { UserState, LootChest } from '../types';
import { LOOT_CHESTS } from '../data/mockData';
import { Package, Lock, Gift, Sparkles, Award } from 'lucide-react';
import confetti from 'canvas-confetti';

interface LootChestsProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const LootChests: React.FC<LootChestsProps> = ({ user, setUser, addToast }) => {
  const handleOpenChest = (chest: LootChest) => {
    if (user.openedChests.includes(chest.id)) {
      addToast('error', 'Bereits geöffnet', 'Du hast diese Truhe bereits geöffnet!');
      return;
    }

    if (user.investedAmount < chest.minInvest) {
      addToast('error', 'Truhe gesperrt', `Du benötigst ein Gesamt-Investment von mindestens $${chest.minInvest.toLocaleString()}, um diese Truhe zu öffnen!`);
      return;
    }

    confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });

    // Calculate simulated rewards based on chest tier
    let coinReward = 2500;
    let xpReward = 50;
    let spinsReward = 1;

    if (chest.tier === 'Silver') { coinReward = 12500; xpReward = 300; spinsReward = 5; }
    else if (chest.tier === 'Gold') { coinReward = 50000; xpReward = 1200; spinsReward = 15; }
    else if (chest.tier === 'Diamond') { coinReward = 250000; xpReward = 5000; spinsReward = 50; }
    else if (chest.tier === 'Apex') { coinReward = 1000000; xpReward = 25000; spinsReward = 100; }

    setUser(prev => {
      const newCoins = prev.coins + coinReward;
      const newXp = prev.xp + xpReward;
      const newSpins = prev.spinsLeft + spinsReward;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let currentXp = newXp;
      while (currentXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        currentXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `🎁 Truhen-Loot: ${chest.name}`,
        amount: coinReward,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: currentXp,
        level: newLevel,
        nextLevelXp,
        spinsLeft: newSpins,
        openedChests: [...prev.openedChests, chest.id],
        transactions: [newTx, ...prev.transactions]
      };
    });

    addToast('drop', '🎁 Truhe geöffnet!', `Du hast +${coinReward.toLocaleString()} Coins, +${xpReward} XP & +${spinsReward} Freispiele erhalten.`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-yellow-500 via-amber-500 to-yellow-600 text-slate-950 shadow-lg shadow-yellow-500/20">
            <Package className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Gestaffeltes Loot-Truhen System
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Je mehr du in die Nexus Arena investierst, desto mächtiger ist deine garantierte Beute. Schalte epische Coin-Mengen, Freispiele und NFT-Pässe frei!
            </p>
          </div>
        </div>

        {/* Current Invest Tag */}
        <div className="flex items-center gap-3 bg-slate-900/80 border border-yellow-500/30 p-4 rounded-2xl shadow-inner">
          <Award className="w-6 h-6 text-yellow-400 flex-shrink-0 animate-pulse" />
          <div>
            <span className="text-[11px] text-slate-400 block font-semibold uppercase tracking-wider">Dein Gesamt-Investment</span>
            <span className="text-base font-extrabold text-white font-['Space_Grotesk']">
              ${user.investedAmount.toLocaleString()} USD
            </span>
          </div>
        </div>
      </div>

      {/* Chests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {LOOT_CHESTS.map((chest) => {
          const isOpened = user.openedChests.includes(chest.id);
          const isUnlocked = user.investedAmount >= chest.minInvest;

          return (
            <div
              key={chest.id}
              className={`p-6 sm:p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all border shadow-2xl ${
                isOpened 
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                  : isUnlocked
                  ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-yellow-500/50 hover:border-yellow-400 shadow-yellow-500/10 hover:scale-[1.02]'
                  : 'bg-slate-900/80 border-slate-800 opacity-80'
              }`}
            >
              {isOpened && (
                <div className="absolute top-0 right-0 px-4 py-1.5 rounded-bl-2xl bg-emerald-500/20 border-l border-b border-emerald-500/40 text-emerald-400 text-xs font-extrabold uppercase tracking-wider">
                  Geöffnet ✓
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl">{chest.icon}</span>
                    <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk']">{chest.name}</h3>
                  </div>
                  {!isUnlocked && (
                    <span className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-400">
                      <Lock className="w-4 h-4" />
                    </span>
                  )}
                </div>

                {/* Min Invest Requirement */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 mb-6 flex items-center justify-between shadow-inner">
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Benötigtes Investment</span>
                  <span className={`font-extrabold font-['Space_Grotesk'] text-sm sm:text-base ${isUnlocked ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${chest.minInvest.toLocaleString()} USD {isUnlocked ? '✓' : `(Fehlt $${(chest.minInvest - user.investedAmount).toLocaleString()})`}
                  </span>
                </div>

                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">Garantierter Loot:</span>
                <ul className="space-y-2 mb-8 text-xs sm:text-sm text-slate-300 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
                  {chest.guaranteedLoot.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2.5">
                      <Sparkles className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                      <span className="font-semibold text-slate-200">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div>
                {isOpened ? (
                  <button disabled className="w-full py-4 rounded-2xl bg-slate-800 text-slate-500 font-bold text-xs border border-slate-700 cursor-not-allowed">
                    Truhe bereits geöffnet
                  </button>
                ) : isUnlocked ? (
                  <button
                    onClick={() => handleOpenChest(chest)}
                    className="w-full py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] bg-gradient-to-r from-yellow-500 via-amber-500 to-yellow-600 hover:from-yellow-400 hover:to-amber-500 text-slate-950 shadow-yellow-500/30 flex items-center justify-center gap-2 animate-pulse"
                  >
                    <Gift className="w-4 h-4 fill-slate-950" />
                    <span>Truhe jetzt öffnen & Loot sichern</span>
                  </button>
                ) : (
                  <button disabled className="w-full py-4 rounded-2xl bg-slate-800 text-slate-500 font-bold text-xs border border-slate-700 cursor-not-allowed flex items-center justify-center gap-2">
                    <Lock className="w-4 h-4" />
                    <span>Gesperrt (Mehr investieren)</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
