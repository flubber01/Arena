import React, { useState } from 'react';
import { UserState, InvestmentPackage, PaymentMethod, CryptoStakingPool } from '../types';
import { INVESTMENT_PACKAGES, LEAGUES, TOP_10_CRYPTO_POOLS } from '../data/mockData';
import { Zap, ShieldCheck, CheckCircle2, ArrowRight, Wallet, CreditCard, DollarSign, Clock, AlertCircle, Lock, Info } from 'lucide-react';
import confetti from 'canvas-confetti';

interface InvestmentStakingProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  onOpenShare: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const InvestmentStaking: React.FC<InvestmentStakingProps> = ({ user, setUser, onOpenShare, addToast }) => {
  const [selectedPkg, setSelectedPkg] = useState<InvestmentPackage | null>(null);
  const [selectedCryptoPool, setSelectedCryptoPool] = useState<CryptoStakingPool | null>(null);
  const [investAmount, setInvestAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('crypto');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const currentLeagueInfo = LEAGUES.find(l => l.name === user.league) || LEAGUES[0];
  const roiBonus = currentLeagueInfo.roiBonus;
  // Gestakete NFTs gewähren zusätzlichen kumulativen ROI-Boost
  const nftRoiBoost = user.nfts ? user.nfts.filter(n => n.staked).reduce((sum, n) => sum + n.roiBoost, 0) : 0;
  const totalExtraRoi = roiBonus + nftRoiBoost;

  const handleSelectPackage = (pkg: InvestmentPackage) => {
    setSelectedPkg(pkg);
    setSelectedCryptoPool(null);
    setInvestAmount(pkg.minAmount);
    setSuccessMessage(null);
  };

  const handleSelectCryptoPool = (pool: CryptoStakingPool) => {
    setSelectedCryptoPool(pool);
    setSelectedPkg(null);
    setInvestAmount(pool.minAmount);
    setSuccessMessage(null);
  };

  const handleConfirmInvestment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPkg && !selectedCryptoPool) return;

    const min = selectedPkg ? selectedPkg.minAmount : selectedCryptoPool!.minAmount;
    const max = selectedPkg ? selectedPkg.maxAmount : selectedCryptoPool!.maxAmount;
    const baseRoi = selectedPkg ? selectedPkg.baseRoi : selectedCryptoPool!.roi;
    const nameStr = selectedPkg ? selectedPkg.name : selectedCryptoPool!.name;
    const coinStr = selectedPkg ? 'USD' : selectedCryptoPool!.coin;
    const duration = selectedPkg ? selectedPkg.durationDays : selectedCryptoPool!.durationDays;
    const isLocked = selectedCryptoPool ? true : false; // Crypto pools are locked until coin launch

    if (investAmount < min || investAmount > max) {
      addToast('error', 'Ungültiger Betrag', `Bitte wähle einen Betrag zwischen $${min.toLocaleString()} und $${max.toLocaleString()}`);
      return;
    }

    const totalRoiPercent = baseRoi + totalExtraRoi;
    const expectedReturn = Math.floor(investAmount * (totalRoiPercent / 100));

    const newInvestment = {
      id: `INV-${Date.now()}`,
      tierName: nameStr,
      coin: coinStr,
      amount: investAmount,
      roiPercentage: totalRoiPercent,
      expectedReturn,
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + duration * 24 * 60 * 60 * 1000).toISOString(),
      claimed: false,
      isPreLaunchLocked: isLocked
    };

    confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });

    setUser(prev => {
      const newInvested = prev.investedAmount + investAmount;
      const newCoins = prev.coins + Math.floor(investAmount * 10);
      const newSpins = prev.spinsLeft + (investAmount >= 10000 ? 100 : investAmount >= 2500 ? 30 : investAmount >= 500 ? 15 : 5);
      let newXp = prev.xp + Math.floor(investAmount * 2);

      let newLeague = prev.league;
      for (let i = LEAGUES.length - 1; i >= 0; i--) {
        if (newInvested >= LEAGUES[i].minInvestment) {
          newLeague = LEAGUES[i].name;
          break;
        }
      }

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'stake' as const,
        title: `⚡ Staking: ${nameStr} (${coinStr})`,
        amount: investAmount,
        currency: coinStr,
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        investedAmount: newInvested,
        league: newLeague,
        xp: newXp,
        level: newLevel,
        nextLevelXp,
        spinsLeft: newSpins,
        activeInvestments: [newInvestment, ...prev.activeInvestments],
        transactions: [newTx, ...prev.transactions]
      };
    });

    const lockNotice = isLocked ? ' (Gesperrt bis zum offiziellen NEXUS Coin Launch)' : '';
    const msg = `🚀 INVESTMENT ERFOLGREICH! Du hast $${investAmount.toLocaleString()} in den ${nameStr} investiert. Erwartete Rückzahlung: $${expectedReturn.toLocaleString()} (${totalRoiPercent}% ROI)${lockNotice}.`;
    setSuccessMessage(msg);
    addToast('success', 'Staking Aktiviert!', `Du hast $${investAmount.toLocaleString()} erfolgreich angelegt.`);
    setSelectedPkg(null);
    setSelectedCryptoPool(null);
  };

  const handleClaimMatured = (invId: string) => {
    const inv = user.activeInvestments.find(i => i.id === invId);
    if (!inv || inv.claimed) return;

    // Alle Auszahlungen sind bis zum offiziellen Börsen-Launch gesperrt
    addToast('error', 'Auszahlung gesperrt', `Alle Auszahlungen sind bis zum offiziellen NEXUS Coin Börsen-Launch im Smart Contract gesperrt ("stuck"). Deine Erträge sind fest für User-ID: NEX-${user.id} gesichert.`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-500 text-slate-950 shadow-lg shadow-amber-500/20">
            <Zap className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Multi-Coin Staking & Gestaffelter ROI
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Stake USD-Pakete oder die <span className="text-amber-400 font-bold">Top 10 Krypto-Coins</span> mit bis zu 240% Rendite. Gestakete Krypto-Pools sind bis zum Token Launch gesichert.
            </p>
          </div>
        </div>

        {/* Current League & NFT Boost Info */}
        <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-900/80 border border-amber-500/30 p-4 rounded-2xl shadow-inner">
          <div className="flex items-center gap-3 border-b sm:border-b-0 sm:border-r border-slate-800 pb-3 sm:pb-0 sm:pr-4">
            <ShieldCheck className="w-6 h-6 text-amber-400 flex-shrink-0 animate-pulse" />
            <div>
              <span className="text-[11px] text-slate-400 block font-semibold uppercase tracking-wider">Liga-Vorteil</span>
              <span className="text-sm font-extrabold text-white font-['Space_Grotesk']">+{roiBonus}% ROI</span>
            </div>
          </div>
          <div className="flex items-center gap-3 pt-1 sm:pt-0">
            <Zap className="w-6 h-6 text-purple-400 flex-shrink-0 animate-pulse" />
            <div>
              <span className="text-[11px] text-slate-400 block font-semibold uppercase tracking-wider">NFT Boosts</span>
              <span className="text-sm font-extrabold text-purple-400 font-['Space_Grotesk']">+{nftRoiBoost}% ROI</span>
            </div>
          </div>
        </div>
      </div>

      {/* Success Message Alert */}
      {successMessage && (
        <div className="mb-12 p-6 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-900 border-2 border-emerald-500/50 flex flex-col sm:flex-row items-center justify-between gap-6 animate-fade-in shadow-2xl">
          <div className="flex items-center gap-4">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 flex-shrink-0 animate-bounce" />
            <div>
              <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk'] mb-1">Staking-Vertrag aktiviert!</h4>
              <p className="text-sm text-slate-300">{successMessage}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onOpenShare} className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-extrabold text-sm rounded-xl shadow-lg hover:scale-105 transition-all whitespace-nowrap">
              Erfolg teilen (+500 Coins)
            </button>
            <button onClick={() => setSuccessMessage(null)} className="text-slate-400 hover:text-white px-3 py-2 text-sm font-bold">✕</button>
          </div>
        </div>
      )}

      {/* --- SECTION 1: TOP 10 CRYPTO STAKING POOLS --- */}
      <div className="mb-16 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
            <Lock className="w-6 h-6 text-amber-400" />
            <span>Top 10 Krypto Staking (20% bis 70% ROI)</span>
          </h3>
          <span className="text-xs bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1 rounded-full font-bold uppercase tracking-wider">
            Pre-Launch Locked
          </span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl flex items-center gap-3 text-xs text-slate-300 shadow-inner">
          <Info className="w-5 h-5 text-cyan-400 flex-shrink-0" />
          <span>Wichtiger Hinweis: Kapital in den Krypto-Pools bleibt bis zum offiziellen NEXUS Coin Launch im Smart Contract gesperrt ("stuck"). Die Auszahlung wird exklusiv für deine User-ID (NEX-{user.id}) freigeschaltet.</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {TOP_10_CRYPTO_POOLS.map((pool) => {
            const totalRoi = pool.roi + totalExtraRoi;
            const isSelected = selectedCryptoPool?.id === pool.id;

            return (
              <div 
                key={pool.id} 
                className={`p-6 rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all border shadow-xl ${
                  isSelected
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-cyan-400 shadow-cyan-500/20 scale-105 z-10'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:scale-[1.02]'
                }`}
              >
                {pool.popular && (
                  <span className="absolute top-0 right-0 px-3 py-1 rounded-bl-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider">
                    Hot
                  </span>
                )}

                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <img src={pool.icon} alt={pool.coin} className="w-10 h-10 object-contain filter drop-shadow" />
                    <div>
                      <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk'] leading-tight">{pool.coin}</h4>
                      <span className="text-[10px] text-slate-400 font-semibold">{pool.name}</span>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800/80 mb-6 shadow-inner">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold mb-0.5">Rendite (ROI)</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-extrabold text-emerald-400 font-['Space_Grotesk']">{totalRoi.toFixed(1)}%</span>
                      {totalExtraRoi > 0 && <span className="text-[10px] text-amber-400 font-bold">inkl. +{totalExtraRoi}% Boost</span>}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1 pt-1 border-t border-slate-800">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span>Sperre: bis Coin Launch</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleSelectCryptoPool(pool)}
                  className={`w-full py-3.5 rounded-2xl font-extrabold text-xs shadow-xl transition-all font-['Space_Grotesk'] flex items-center justify-center gap-1.5 ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 text-white shadow-cyan-500/25 animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                  }`}
                >
                  <span>{isSelected ? 'Ausgewählt' : `Ab $${pool.minAmount} staken`}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

              </div>
            );
          })}
        </div>
      </div>

      {/* --- SECTION 2: USD INVESTMENT PACKAGES --- */}
      <div className="mb-16 space-y-6">
        <div className="border-b border-slate-800 pb-4">
          <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
            <Zap className="w-6 h-6 text-cyan-400" />
            <span>USD Staking Pools (Flexible Sperrfristen)</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {INVESTMENT_PACKAGES.map((pkg) => {
            const totalRoi = pkg.baseRoi + totalExtraRoi;
            const isSelected = selectedPkg?.id === pkg.id;

            return (
              <div
                key={pkg.id}
                className={`rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all group ${
                  isSelected
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-cyan-400 shadow-2xl shadow-cyan-500/20 scale-105 z-10'
                    : pkg.popular
                    ? 'bg-slate-900/90 border-2 border-purple-500/50 shadow-xl'
                    : 'bg-slate-900/60 border border-slate-800 hover:border-slate-700 shadow-lg'
                }`}
              >
                {pkg.badge && (
                  <span className={`absolute top-0 right-0 px-4 py-1.5 rounded-bl-2xl text-xs font-extrabold uppercase tracking-wider shadow-md ${
                    pkg.badge === 'Maximum ROI' ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950'
                  }`}>
                    {pkg.badge}
                  </span>
                )}

                <div className="p-6 sm:p-8">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">{pkg.subtitle}</span>
                  <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] mb-4">{pkg.name}</h3>

                  {/* ROI Display */}
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80 mb-6">
                    <span className="text-[11px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">Gesamtausschüttung (ROI)</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-extrabold text-white font-['Space_Grotesk']">{totalRoi}%</span>
                      {totalExtraRoi > 0 && (
                        <span className="text-xs text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                          inkl. +{totalExtraRoi}% Boost
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-2 pt-2 border-t border-slate-800">
                      <Clock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Sperrfrist: {pkg.durationDays} Tage</span>
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed min-h-[48px]">
                    {pkg.description}
                  </p>

                  <ul className="space-y-3 mb-8 text-xs sm:text-sm text-slate-300">
                    {pkg.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-6 pt-0">
                  <button
                    onClick={() => handleSelectPackage(pkg)}
                    className={`w-full py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] flex items-center justify-center gap-2 ${
                      isSelected
                        ? 'bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 text-white shadow-cyan-500/25 animate-pulse'
                        : pkg.popular
                        ? 'bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white shadow-purple-500/20'
                        : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                    }`}
                  >
                    <span>{isSelected ? 'Ausgewählt' : `Ab $${pkg.minAmount.toLocaleString()} investieren`}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* --- SIMULATED CHECKOUT MODAL / FORM --- */}
      {(selectedPkg || selectedCryptoPool) && (
        <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border-2 border-cyan-400 mb-16 relative overflow-hidden animate-fade-in shadow-2xl shadow-cyan-500/10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-3xl mx-auto">
            <div className="flex items-center justify-between mb-8 pb-6 border-b border-slate-800">
              <div>
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest block mb-1">Simulierter Bezahlvorgang</span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
                  Investment abschließen: {selectedPkg ? selectedPkg.name : selectedCryptoPool!.name}
                </h3>
              </div>
              <button
                onClick={() => { setSelectedPkg(null); setSelectedCryptoPool(null); }}
                className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center font-bold text-lg transition-all"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmInvestment} className="space-y-8">
              
              {/* Amount Selection */}
              <div>
                <label className="block text-sm font-bold text-slate-300 mb-3">
                  1. Wähle deinen Investitionsbetrag (Min: ${selectedPkg ? selectedPkg.minAmount : selectedCryptoPool!.minAmount} | Max: ${selectedPkg ? selectedPkg.maxAmount : selectedCryptoPool!.maxAmount}):
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <DollarSign className="w-6 h-6 text-cyan-400" />
                  </div>
                  <input
                    type="number"
                    min={selectedPkg ? selectedPkg.minAmount : selectedCryptoPool!.minAmount}
                    max={selectedPkg ? selectedPkg.maxAmount : selectedCryptoPool!.maxAmount}
                    value={investAmount}
                    onChange={(e) => setInvestAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border-2 border-slate-800 focus:border-cyan-400 rounded-2xl py-4 pl-12 pr-6 text-xl font-extrabold text-white font-['Space_Grotesk'] outline-none transition-all shadow-inner"
                    required
                  />
                </div>
              </div>

              {/* Payment Method Selection */}
              <div>
                <label className="block text-sm font-bold text-slate-300 mb-3">
                  2. Bezahloption auswählen:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {[
                    { id: 'crypto', label: 'Krypto (BTC/ETH)', icon: Wallet, color: 'border-purple-500/50' },
                    { id: 'creditcard', label: 'Kreditkarte', icon: CreditCard, color: 'border-blue-500/50' },
                    { id: 'paypal', label: 'PayPal', icon: DollarSign, color: 'border-cyan-500/50' },
                    { id: 'applepay', label: 'Apple Pay', icon: Zap, color: 'border-slate-500/50' },
                    { id: 'klarna', label: 'Klarna Sofort', icon: ShieldCheck, color: 'border-pink-500/50' },
                  ].map((method) => {
                    const Icon = method.icon;
                    const isSelected = paymentMethod === method.id;
                    return (
                      <button
                        type="button"
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id as PaymentMethod)}
                        className={`p-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all border ${
                          isSelected
                            ? `bg-slate-900 border-2 ${method.color} shadow-lg shadow-cyan-500/10 scale-105`
                            : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
                        }`}
                      >
                        <Icon className={`w-6 h-6 ${isSelected ? 'text-cyan-400 animate-bounce' : 'text-slate-400'}`} />
                        <span className="text-xs font-extrabold font-['Space_Grotesk'] text-center">{method.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Summary & Submit */}
              <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4 shadow-inner">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 font-medium">Investitionsbetrag:</span>
                  <span className="font-extrabold text-white font-['Space_Grotesk'] text-base">${investAmount.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 font-medium">Gesamter ROI ({selectedPkg ? selectedPkg.baseRoi : selectedCryptoPool!.roi}% + {totalExtraRoi}% Boost):</span>
                  <span className="font-extrabold text-emerald-400 font-['Space_Grotesk'] text-base">{selectedPkg ? selectedPkg.baseRoi + totalExtraRoi : selectedCryptoPool!.roi + totalExtraRoi}%</span>
                </div>
                <div className="flex items-center justify-between text-sm pt-4 border-t border-slate-800/80">
                  <span className="text-slate-300 font-bold">Erwartete Rückzahlung:</span>
                  <span className="font-black text-cyan-400 font-['Space_Grotesk'] text-2xl">
                    ${Math.floor(investAmount * (((selectedPkg ? selectedPkg.baseRoi : selectedCryptoPool!.roi) + totalExtraRoi) / 100)).toLocaleString()}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-5 rounded-2xl font-extrabold text-lg shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-cyan-500/25 flex items-center justify-center gap-2 animate-pulse"
              >
                <Zap className="w-5 h-5 fill-white" />
                <span>Zahlungspflichtig Investieren (${investAmount.toLocaleString()})</span>
              </button>

            </form>
          </div>

        </div>
      )}

      {/* --- SECTION 3: ACTIVE INVESTMENTS OVERVIEW --- */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800">
        <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] mb-6 flex items-center gap-2">
          <Clock className="w-6 h-6 text-cyan-400" />
          <span>Deine aktiven Staking-Verträge</span>
        </h3>

        {user.activeInvestments.length === 0 ? (
          <div className="text-center py-12 bg-slate-950/60 rounded-2xl border border-slate-800/80">
            <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 text-sm font-medium">Du hast aktuell keine aktiven Staking-Verträge.</p>
            <p className="text-xs text-slate-500 mt-1">Wähle oben ein Paket aus, um deine Krypto-Erträge zu maximieren!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-4 px-4">Vertrags-ID</th>
                  <th className="py-4 px-4">Paket / Pool</th>
                  <th className="py-4 px-4">Asset</th>
                  <th className="py-4 px-4">Investiert</th>
                  <th className="py-4 px-4">ROI %</th>
                  <th className="py-4 px-4">Erwarteter Ertrag</th>
                  <th className="py-4 px-4">Ablaufdatum</th>
                  <th className="py-4 px-4 text-right">Status / Auszahlung</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-sm">
                {user.activeInvestments.map((inv) => {
                  return (
                    <tr key={inv.id} className="transition-colors hover:bg-slate-800/40">
                      <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-slate-300">{inv.id}</td>
                      <td className="py-4 px-4 font-extrabold text-white">{inv.tierName}</td>
                      <td className="py-4 px-4 font-bold text-cyan-400">{inv.coin}</td>
                      <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-slate-200">${inv.amount.toLocaleString()}</td>
                      <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-emerald-400">{inv.roiPercentage}%</td>
                      <td className="py-4 px-4 font-['Space_Grotesk'] font-extrabold text-cyan-400">${inv.expectedReturn.toLocaleString()}</td>
                      <td className="py-4 px-4 text-slate-400 text-xs">{new Date(inv.endDate).toLocaleDateString('de-DE')}</td>
                      <td className="py-4 px-4 text-right">
                        {inv.claimed ? (
                          <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-500 font-bold text-xs border border-slate-700">Ausgezahlt</span>
                        ) : (
                          <button
                            onClick={() => handleClaimMatured(inv.id)}
                            className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1 ml-auto"
                          >
                            <Lock className="w-3 h-3" />
                            <span>Gesperrt (Börsen-Launch)</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
