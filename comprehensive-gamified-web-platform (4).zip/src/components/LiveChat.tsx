import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, UserState } from '../types';
import { MessageSquare, Send, X, Minus } from 'lucide-react';

interface LiveChatProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  { id: '1', sender: 'Nexus AI Bot', avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80', text: 'Willkommen in der Nexus Arena! Schließe Quests ab oder drehe das Glücksrad, um Level 1200 zu erreichen.', timestamp: '10:42', isBot: true, badge: 'MOD' },
  { id: '2', sender: 'Vitalik_B', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80', text: 'Hab gerade 50k im Krypto Crash mit 4.2x Multiplikator ausgezahlt. Wahnsinn!', timestamp: '10:44', badge: 'VIP' },
  { id: '3', sender: 'MoonShot_Trader', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&auto=format&fit=crop&q=80', text: 'Staking im Whale Apex Fund läuft extrem gut. +240% ROI ist unschlagbar.', timestamp: '10:45', badge: 'PRO' },
];

const BOT_RESPONSES = [
  { trigger: ['hallo', 'hey', 'hi', 'moin', 'servus'], text: 'Hallo Titan! Hast du schon deinen FreeLaunch Airdrop von 5.000 Coins geclaimt?' },
  { trigger: ['quest', 'aufgabe', 'bounty'], text: 'Schau im Quests-Tab vorbei. Dort gibt es täglich neue Aufgaben für massig XP & Coins!' },
  { trigger: ['level', '1200', 'aufsteigen'], text: 'Um Level 1200 zu erreichen, kaufe Auto-Klicker und investiere in Staking-Pakete. Der Zinseszins pusht dein XP-Konto!' },
  { trigger: ['staking', 'invest', 'roi', 'whale'], text: 'Der Whale Fund bietet +240% ROI. In Kombination mit dem Diamond oder Apex Liga-Boost holst du das Maximum heraus.' },
  { trigger: ['hilfe', 'support', 'problem', 'bug'], text: 'Unser KI-Support ist 24/7 aktiv. Bei Auszahlungsproblemen wende dich an deinen persönlichen VIP Account Manager.' },
  { trigger: ['scam', 'fake', 'echt'], text: 'Nexus Arena ist ein hochsicheres, dezentrales Gamification-Ökosystem, abgesichert durch geprüfte Smart Contracts.' },
  { trigger: ['coin', 'geld', 'pleite', 'klicker'], text: 'Nutze den Coin Klicker! Jedes Level-Up bringt dir permanent +25 Basis-Coins mehr pro Klick.' },
];

const RANDOM_CHATTERS = [
  { name: 'Satoshi_Nakamoto', avatar: 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=100&auto=format&fit=crop&q=80', badge: 'APEX', text: 'HODL ist die Devise. Staking sichert die Zukunft.' },
  { name: 'DiamondHands', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&auto=format&fit=crop&q=80', badge: 'PRO', text: 'Slot Machine hat mir gerade 3 Diamanten gegeben! Mega Jackpot!' },
  { name: 'SolanaSurfer', avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=100&auto=format&fit=crop&q=80', badge: 'VIP', text: 'Die Krypto Rakete macht süchtig. Bin bei 5.2x rausgegangen!' },
  { name: 'HODL_Queen', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80', badge: 'GOLD', text: 'Vergesst nicht eure täglichen Login-Boni abzuholen. Tag 7 Truhe ist der Wahnsinn.' },
];

export const LiveChat: React.FC<LiveChatProps> = ({ user, setUser, addToast }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputText, setInputText] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && !isMinimized) {
      scrollToBottom();
    }
  }, [messages, isOpen, isMinimized]);

  // Random community chat simulation
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() < 0.35) { // 35% chance every 15s
        const chatter = RANDOM_CHATTERS[Math.floor(Math.random() * RANDOM_CHATTERS.length)];
        const timeStr = new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
        
        const newMessage: ChatMessage = {
          id: `chat-${Date.now()}`,
          sender: chatter.name,
          avatar: chatter.avatar,
          text: chatter.text,
          timestamp: timeStr,
          badge: chatter.badge
        };

        setMessages(prev => [...prev.slice(-30), newMessage]); // Keep last 30 messages
      }
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const timeStr = new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: user.name,
      avatar: user.avatar,
      text: inputText.trim(),
      timestamp: timeStr,
      isCurrentUser: true,
      badge: user.league
    };

    setMessages(prev => [...prev, userMsg]);
    const lowerInput = inputText.toLowerCase();
    setInputText('');

    // Check Bot Response or Tip
    setTimeout(() => {
      let responseText = 'Das ist ein interessanter Punkt! Bleib aktiv in der Arena und maximiere deine Staking-Erträge.';
      
      // Find matching trigger
      for (const bot of BOT_RESPONSES) {
        if (bot.trigger.some(t => lowerInput.includes(t))) {
          responseText = bot.text;
          break;
        }
      }

      // 20% chance bot gives a small coin tip for chatting
      const giveTip = Math.random() < 0.25;
      if (giveTip) {
        const tipAmount = 500 + Math.floor(Math.random() * 1000);
        responseText += ` 🎁 Hier ist ein kleiner Community-Tip von +${tipAmount} Coins für deine Aktivität!`;

        setUser(prev => ({
          ...prev,
          coins: prev.coins + tipAmount,
          xp: prev.xp + 50,
          transactions: [
            {
              id: `TX-${Date.now()}`,
              type: 'earn',
              title: 'Community Chat Tip',
              amount: tipAmount,
              currency: 'NEX',
              timestamp: new Date().toISOString()
            },
            ...prev.transactions
          ]
        }));

        addToast('drop', 'Community Tip erhalten!', `Nexus AI Bot hat dir +${tipAmount} Coins geschenkt.`);
      }

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'Nexus AI Bot',
        avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80',
        text: responseText,
        timestamp: new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }),
        isBot: true,
        badge: 'MOD'
      };

      setMessages(prev => [...prev, botMsg]);
    }, 1000);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => { setIsOpen(true); setIsMinimized(false); }}
        className="fixed bottom-6 left-6 z-40 flex items-center gap-3 bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white px-5 py-3.5 rounded-full shadow-2xl shadow-cyan-500/30 transition-all transform hover:scale-105 group font-['Space_Grotesk'] font-extrabold text-sm"
      >
        <MessageSquare className="w-5 h-5 animate-bounce" />
        <span>Live Community Chat</span>
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping ml-1" />
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 left-6 z-40 bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl shadow-cyan-500/20 w-80 sm:w-96 overflow-hidden transition-all duration-300 flex flex-col ${
      isMinimized ? 'h-16' : 'h-[500px]'
    }`}>
      
      {/* Chat Header */}
      <div 
        onClick={() => setIsMinimized(!isMinimized)}
        className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 p-4 border-b border-slate-700/80 flex items-center justify-between cursor-pointer select-none"
      >
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
              <MessageSquare className="w-4 h-4" />
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-slate-900" />
          </div>
          <div>
            <h4 className="text-sm font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-1.5 leading-none mb-0.5">
              <span>Nexus Community</span>
              <span className="text-[10px] bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-1.5 py-0.2 rounded font-bold">LIVE</span>
            </h4>
            <p className="text-[10px] text-slate-400">1.482 Titanen online</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button 
            onClick={(e) => { e.stopPropagation(); setIsMinimized(!isMinimized); }}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); setIsOpen(false); }}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Chat Messages Body */}
      {!isMinimized && (
        <>
          <div className="flex-grow p-4 overflow-y-auto space-y-4 no-scrollbar bg-slate-950/60">
            {messages.map((msg) => {
              const isMe = msg.isCurrentUser;
              return (
                <div key={msg.id} className={`flex items-start gap-2.5 animate-fade-in ${isMe ? 'flex-row-reverse' : ''}`}>
                  <img src={msg.avatar} alt={msg.sender} className="w-8 h-8 rounded-xl object-cover flex-shrink-0 border border-slate-700 shadow" />
                  
                  <div className={`flex flex-col max-w-[75%] ${isMe ? 'items-end' : 'items-start'}`}>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[11px] font-bold text-slate-400">{msg.sender}</span>
                      {msg.badge && (
                        <span className={`text-[9px] px-1.5 py-0.2 rounded font-extrabold ${
                          msg.badge === 'MOD' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                          msg.badge === 'APEX' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                          msg.badge === 'VIP' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                          'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                        }`}>
                          {msg.badge}
                        </span>
                      )}
                      <span className="text-[9px] text-slate-500 ml-1">{msg.timestamp}</span>
                    </div>

                    <div className={`p-3 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-md ${
                      isMe 
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-tr-none' 
                        : msg.isBot
                        ? 'bg-slate-800 border border-slate-700 text-slate-100 rounded-tl-none'
                        : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input Form */}
          <form onSubmit={handleSendMessage} className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Schreibe der Community..."
              className="flex-grow bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white outline-none transition-all shadow-inner"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 disabled:pointer-events-none text-white rounded-xl shadow transition-all flex-shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </>
      )}

    </div>
  );
};
