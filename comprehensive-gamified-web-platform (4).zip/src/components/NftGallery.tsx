import React from 'react';
import { UserState } from '../types';
import { INITIAL_NFTS } from '../data/mockData';
import { ShieldCheck, Award, Zap, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface NftGalleryProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const NftGallery: React.FC<NftGalleryProps> = ({ user, setUser, addToast }) => {
  const nfts = user.nfts?.length > 0 ? user.nfts : INITIAL_NFTS;

  const handleToggleStake = (nftId: string) => {
    const nft = nfts.find(n => n.id === nftId);
    if (!nft) return;

    const willStake = !nft.staked;

    if (willStake) {
      confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });
      addToast('success', 'NFT Gestaked!', `Dein ${nft.name} gewährt dir ab sofort +${nft.roiBoost}% ROI-Boost.`);
    } else {
      addToast('info', 'NFT Unstaked', `Dein ${nft.name} wurde aus dem Staking-Pool entfernt.`);
    }

    setUser(prev => {
      const updatedNfts = (prev.nfts?.length > 0 ? prev.nfts : INITIAL_NFTS).map(item => 
        item.id === nftId ? { ...item, staked: willStake } : item
      );

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'stake' as const,
        title: `🖼️ NFT ${willStake ? 'Staking' : 'Unstaking'}: ${nft.name}`,
        amount: nft.valueUsd,
        currency: 'USD',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        nfts: updatedNfts,
        transactions: [newTx, ...prev.transactions]
      };
    });
  };

  const totalRoiBoost = nfts.filter(n => n.staked).reduce((sum, n) => sum + n.roiBoost, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-rose-500 text-white shadow-lg shadow-purple-500/20">
            <Award className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Nexus NFT Pässe & Staking Boosts
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Binde deine NFTs direkt in das Ökosystem ein. Gestakete NFTs gewähren dir permanente, kumulative ROI-Boosts auf alle Krypto-Staking-Pools!
            </p>
          </div>
        </div>

        {/* Total Boost Display */}
        <div className="flex items-center gap-3 bg-slate-900/80 border border-purple-500/30 p-4 rounded-2xl shadow-inner">
          <Zap className="w-6 h-6 text-purple-400 flex-shrink-0 animate-pulse" />
          <div>
            <span className="text-[11px] text-slate-400 block font-semibold uppercase tracking-wider">Aktiver NFT ROI-Boost</span>
            <span className="text-xl font-extrabold text-white font-['Space_Grotesk']">
              +{totalRoiBoost}% Gesamt-Boost
            </span>
          </div>
        </div>
      </div>

      {/* NFTs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        {nfts.map((nft) => {
          let rarityColor = 'text-slate-400 border-slate-500/30';
          let badgeBg = 'bg-slate-500/20 text-slate-300';

          if (nft.rarity === 'Legendary') { rarityColor = 'text-amber-400 border-amber-500/50'; badgeBg = 'bg-amber-500/20 text-amber-300'; }
          else if (nft.rarity === 'Mythic') { rarityColor = 'text-rose-400 border-rose-500/50'; badgeBg = 'bg-rose-500/20 text-rose-300'; }
          else if (nft.rarity === 'Epic') { rarityColor = 'text-purple-400 border-purple-500/50'; badgeBg = 'bg-purple-500/20 text-purple-300'; }
          else if (nft.rarity === 'Rare') { rarityColor = 'text-blue-400 border-blue-500/50'; badgeBg = 'bg-blue-500/20 text-blue-300'; }

          return (
            <div 
              key={nft.id}
              className={`rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all border shadow-xl ${
                nft.staked 
                  ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-purple-950 border-purple-500/50 shadow-purple-500/10 hover:scale-[1.02]' 
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 opacity-80 hover:opacity-100'
              }`}
            >
              {/* NFT Image */}
              <div className="relative w-full h-64 overflow-hidden bg-slate-950">
                <img src={nft.image} alt={nft.name} className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" />
                <span className={`absolute top-4 right-4 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider border backdrop-blur-md ${badgeBg} ${rarityColor}`}>
                  {nft.rarity}
                </span>

                {nft.staked && (
                  <div className="absolute inset-0 bg-purple-950/40 backdrop-blur-[2px] flex items-center justify-center">
                    <div className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-slate-950/90 border border-purple-500/50 text-purple-400 font-extrabold text-xs shadow-2xl animate-pulse">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Aktiv im Staking</span>
                    </div>
                  </div>
                )}
              </div>

              {/* NFT Info */}
              <div className="p-6">
                <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-3">{nft.name}</h3>

                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 mb-6 flex items-center justify-between shadow-inner">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-0.5">ROI Boost</span>
                    <span className="font-extrabold text-emerald-400 font-['Space_Grotesk'] text-base">+{nft.roiBoost}%</span>
                  </div>
                  <div className="text-right border-l border-slate-800 pl-4">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-0.5">Schätzwert</span>
                    <span className="font-extrabold text-white font-['Space_Grotesk'] text-base">${nft.valueUsd.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => handleToggleStake(nft.id)}
                  className={`w-full py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] flex items-center justify-center gap-2 ${
                    nft.staked
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                      : 'bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 hover:from-purple-400 hover:to-rose-400 text-white shadow-purple-500/25 animate-pulse'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{nft.staked ? 'NFT Unstaken' : 'NFT Staken (+Boost sichern)'}</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
