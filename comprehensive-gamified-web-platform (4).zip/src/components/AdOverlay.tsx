import React, { useState, useEffect } from 'react';
import { UserState } from '../types';
import { Play, ExternalLink, ShieldCheck, X } from 'lucide-react';

interface AdOverlayProps {
  user: UserState;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

const AD_BANNERS = [
  { title: 'KuCoin Premium Trading', desc: 'Sichere dir bis zu $500 Willkommensbonus auf KuCoin! Handle Altcoins mit den niedrigsten Gebühren.', img: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=600&auto=format&fit=crop&q=80', url: 'https://kucoin.com' },
  { title: 'Google Cloud DSS Security', desc: 'Modernste Cloud-Sicherheit für dezentrale Applikationen. Schütze deine Smart Contracts vor DDoS.', img: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?w=600&auto=format&fit=crop&q=80', url: 'https://cloud.google.com' },
  { title: 'Norton SafeWeb Antivirus', desc: 'Echtzeit-Schutz für Krypto-Wallets und Web3-Transaktionen. Jetzt 30 Tage kostenlos testen!', img: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&auto=format&fit=crop&q=80', url: 'https://norton.com' }
];

export const AdOverlay: React.FC<AdOverlayProps> = ({ user, addToast }) => {
  const [isActive, setIsActive] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [currentAd, setCurrentAd] = useState(AD_BANNERS[0]);

  const adIntervalMs = (user.adminSettings?.adIntervalMinutes || 8) * 60 * 1000;
  const adDurationSec = user.adminSettings?.adDurationSeconds || 35;

  // Trigger Ad overlay periodically
  useEffect(() => {
    const timer = setInterval(() => {
      // Pick random ad
      const randomAd = AD_BANNERS[Math.floor(Math.random() * AD_BANNERS.length)];
      setCurrentAd(randomAd);
      setTimeLeft(adDurationSec);
      setIsActive(true);
      addToast('info', 'Werbeeinblendung', `Diese kurze Werbeunterbrechung unterstützt unsere kostenlosen Staking-Pools.`);
    }, adIntervalMs);

    return () => clearInterval(timer);
  }, [adIntervalMs, adDurationSec, addToast]);

  // Countdown timer when active
  useEffect(() => {
    if (!isActive) return;

    if (timeLeft <= 0) {
      setIsActive(false);
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl animate-fade-in">
      <div className="glass-panel-premium w-full max-w-2xl p-6 sm:p-10 rounded-3xl border-2 border-emerald-500/50 shadow-2xl shadow-emerald-500/20 relative overflow-hidden flex flex-col items-center text-center">
        
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Info Bar */}
        <div className="w-full flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-[10px] font-extrabold uppercase tracking-widest animate-pulse">
              Google AdSense Partner
            </span>
            <span className="text-xs text-slate-400 font-bold">Client: ca-pub-8842</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-bold">Werbung schließt in:</span>
            <span className="text-sm font-black bg-slate-900 border border-slate-700 px-3 py-1 rounded-xl text-emerald-400 font-mono animate-pulse">
              {timeLeft}s
            </span>
            {timeLeft <= 0 && (
              <button onClick={() => setIsActive(false)} className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Ad Content */}
        <div className="w-full relative rounded-2xl overflow-hidden border border-slate-700/80 shadow-2xl mb-6 bg-slate-950 group">
          <img src={currentAd.img} alt={currentAd.title} className="w-full h-64 sm:h-80 object-cover group-hover:scale-105 transition-transform duration-700" />
          
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex flex-col justify-end p-6 text-left">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
              <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">Verifizierter Werbepartner</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
              {currentAd.title}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-lg font-medium mb-4">
              {currentAd.desc}
            </p>
            <a 
              href={currentAd.url} 
              target="_blank" 
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg transition-all w-fit"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Angebot jetzt öffnen</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Bottom Notice */}
        <p className="text-[11px] text-slate-400 leading-relaxed max-w-md mx-auto">
          *Diese Werbeeinblendung erscheint exakt alle {user.adminSettings?.adIntervalMinutes || 8} Minuten für {user.adminSettings?.adDurationSeconds || 35} Sekunden. Die generierten Einnahmen fließen zu 60% in unseren Staking-Ausschüttungspool zurück!
        </p>

        {timeLeft > 0 ? (
          <div className="mt-6 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-bold text-amber-400 animate-pulse">
            Bitte warte {timeLeft} Sekunden, um zur Nexus Arena zurückzukehren...
          </div>
        ) : (
          <button
            onClick={() => setIsActive(false)}
            className="mt-6 px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-sm rounded-2xl shadow-xl transition-all"
          >
            Werbung schließen & zur Arena zurückkehren
          </button>
        )}

      </div>
    </div>
  );
};
