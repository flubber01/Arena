import React, { useState } from 'react';
import { UserState } from '../types';
import { User, ShieldCheck, Upload, Gift, Key, CheckCircle2, Copy, Users, Clock, CreditCard, Wallet, DollarSign, AlertTriangle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface MemberAreaProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

const AVATARS = [
  { id: 'av1', name: 'Cyberpunk Titan', url: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80' },
  { id: 'av2', name: 'Neon Trader', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80' },
  { id: 'av3', name: 'Golden Whale', url: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80' },
  { id: 'av4', name: 'Diamond Empress', url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80' },
  { id: 'av5', name: 'Apex God', url: 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=150&auto=format&fit=crop&q=80' },
  { id: 'av6', name: 'Solana Surfer', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80' }
];

const PAYMENT_METHODS_INFO = [
  { id: 'crypto', name: 'Krypto (BTC, ETH, SOL, USDT)', icon: Wallet, fee: '0.0%', time: 'Sofort (1 Bestätigung)', limit: '$50 - $500,000', color: 'border-purple-500/50' },
  { id: 'creditcard', name: 'Kreditkarte (Visa, Mastercard)', icon: CreditCard, fee: '0.0%', time: 'Sofort', limit: '$50 - $25,000', color: 'border-blue-500/50' },
  { id: 'paypal', name: 'PayPal Premium', icon: DollarSign, fee: '0.0%', time: 'Sofort', limit: '$50 - $10,000', color: 'border-cyan-500/50' },
  { id: 'applepay', name: 'Apple Pay / Google Pay', icon: CreditCard, fee: '0.0%', time: 'Sofort', limit: '$50 - $15,000', color: 'border-slate-500/50' },
  { id: 'klarna', name: 'Klarna Sofortüberweisung', icon: ShieldCheck, fee: '0.0%', time: 'Sofort', limit: '$50 - $5,000', color: 'border-pink-500/50' }
];

export const MemberArea: React.FC<MemberAreaProps> = ({ user, setUser, addToast }) => {
  const [promoCode, setPromoCode] = useState<string>('');
  const [kycForm, setKycForm] = useState({
    fullName: user.fullName || '',
    address: user.address || '',
    walletAddress: user.connectedWallet || '',
    idFileName: user.idDocument ? 'ausweis_dokument.pdf' : ''
  });
  const [refCount] = useState<number>(3);
  const [refClaimed, setRefClaimed] = useState<boolean>(false);

  // --- AVATAR WECHSLER ---
  const handleSelectAvatar = (url: string) => {
    setUser(prev => ({ ...prev, avatar: url }));
    addToast('success', 'Avatar aktualisiert!', 'Dein Profilbild wurde erfolgreich geändert.');
  };

  // --- PROMO CODE EINLÖSEN ---
  const handleClaimPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const code = promoCode.trim().toUpperCase();
    if (!code) return;

    if (user.claimedPromoCodes?.includes(code)) {
      addToast('error', 'Code bereits verwendet', `Der Promo Code "${code}" wurde bereits eingelöst.`);
      return;
    }

    let rewardCoins = 0;
    let rewardXp = 0;
    let label = '';

    if (code === 'NEXUS2026') { rewardCoins = 25000; rewardXp = 1000; label = '25.000 Coins & 1.000 XP'; }
    else if (code === 'TITAN500') { rewardCoins = 50000; rewardXp = 5000; label = '50.000 Coins & 5.000 XP'; }
    else if (code === 'CRYPTOVIP') { rewardCoins = 100000; rewardXp = 2000; label = '100.000 Coins'; }
    else if (code === 'AIRDROP10K') { rewardCoins = 10000; rewardXp = 500; label = '10.000 Coins & 500 XP'; }
    else {
      addToast('error', 'Ungültiger Code', `Der Promo Code "${code}" existiert nicht.`);
      return;
    }

    confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });

    setUser(prev => {
      const newCoins = prev.coins + rewardCoins;
      const newXp = prev.xp + rewardXp;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      let currentXp = newXp;
      while (currentXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        currentXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: `🎁 Promo Code: ${code}`,
        amount: rewardCoins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: currentXp,
        level: newLevel,
        nextLevelXp,
        claimedPromoCodes: [...(prev.claimedPromoCodes || []), code],
        transactions: [newTx, ...prev.transactions]
      };
    });

    addToast('success', 'Promo Code Eingelöst!', `Glückwunsch! Du hast ${label} erhalten.`);
    setPromoCode('');
  };

  // --- KYC / AML VERIFIZIERUNG ---
  const handleKycSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!kycForm.fullName || !kycForm.address || !kycForm.walletAddress || !kycForm.idFileName) {
      addToast('error', 'Unvollständige Daten', 'Bitte fülle alle Felder aus und lade dein Ausweisdokument hoch!');
      return;
    }

    confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });

    setUser(prev => ({
      ...prev,
      kycStatus: 'pending',
      fullName: kycForm.fullName,
      address: kycForm.address,
      connectedWallet: kycForm.walletAddress,
      idDocument: kycForm.idFileName
    }));

    addToast('success', 'Dokumente übermittelt!', 'Deine Daten werden von unserem Compliance-Support geprüft. Nach erfolgreichem Abgleich mit dem Ausweis werden Blockchain-Auszahlungen freigeschaltet.');
  };

  const handleSimulateUpload = () => {
    setKycForm(prev => ({ ...prev, idFileName: 'ausweis_vorder_rueckseite.pdf' }));
    addToast('info', 'Ausweis hochgeladen', 'Ausweisdokument erfolgreich simuliert angehängt.');
  };

  // --- REFERRAL / WERBER FUNKTION ---
  const handleCopyRef = () => {
    navigator.clipboard.writeText(`https://nexus-coin-arena.io/join?ref=${user.name}`);
    addToast('success', 'Ref-Link kopiert!', 'Dein persönlicher Einladungslink befindet sich in der Zwischenablage.');
  };

  const handleClaimRefBonus = () => {
    if (refClaimed) return;
    confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });
    setUser(prev => ({
      ...prev,
      coins: prev.coins + 150000,
      xp: prev.xp + 5000
    }));
    setRefClaimed(true);
    addToast('drop', '👥 Werber-Bonus geclaimt!', 'Du hast +150.000 Coins & +5.000 XP für deine 3 aktiven Freunde erhalten!');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-800 pb-8">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 text-white shadow-lg shadow-cyan-500/20">
            <User className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Mitgliederbereich & Payout-Verifizierung
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Verwalte dein Profil, lade deine KYC-Dokumente für Blockchain-Auszahlungen hoch, nutze die Werber-Funktion und verfolge deine Zahlungshistorie.
            </p>
          </div>
        </div>

        {/* KYC Status Badge */}
        <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-800 p-4 rounded-2xl shadow-inner">
          <ShieldCheck className={`w-6 h-6 flex-shrink-0 ${
            user.kycStatus === 'verified' ? 'text-emerald-400 animate-pulse' :
            user.kycStatus === 'pending' ? 'text-amber-400 animate-spin-slow' :
            'text-rose-400'
          }`} />
          <div>
            <span className="text-[11px] text-slate-400 block font-semibold uppercase tracking-wider">Auszahlungs-Status</span>
            <span className={`text-sm font-extrabold font-['Space_Grotesk'] ${
              user.kycStatus === 'verified' ? 'text-emerald-400' : 
              user.kycStatus === 'pending' ? 'text-amber-400' : 
              'text-rose-400'
            }`}>
              {user.kycStatus === 'verified' ? 'Verifiziert (Auszahlung Aktiv)' :
               user.kycStatus === 'pending' ? 'Prüfung durch Support läuft' :
               'Nicht verifiziert (Gesperrt)'}
            </span>
          </div>
        </div>
      </div>

      {/* --- SECTION 1: KYC / AML VERIFIZIERUNG & AUSWEIS UPLOAD --- */}
      <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border-2 border-cyan-500/50 relative overflow-hidden shadow-2xl shadow-cyan-500/10">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl mx-auto space-y-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-6 h-6 text-cyan-400 animate-pulse" />
              <span className="text-xs font-extrabold text-cyan-400 uppercase tracking-widest">Sicherheit & Anti-Betrugs-Schutz</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
              Identitätsprüfung für Blockchain-Auszahlungen
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <AlertTriangle className="w-5 h-5 text-amber-400 inline mr-2 flex-shrink-0" />
              Wichtiger Hinweis: Um Betrug, Geldwäsche und Mehrfachkonten auszuschließen, müssen deine hinterlegten Daten exakt mit deinem offiziellen Ausweisdokument übereinstimmen. Ohne verifizierten KYC-Abgleich durch unseren Support werden keine Auszahlungen über die Blockchain freigegeben.
            </p>
          </div>

          <form onSubmit={handleKycSubmit} className="space-y-6 relative z-10">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Vollständiger Name (Wie auf dem Ausweis) *
                </label>
                <input 
                  type="text"
                  value={kycForm.fullName}
                  onChange={(e) => setKycForm({ ...kycForm, fullName: e.target.value })}
                  placeholder="z.B. Max Mustermann"
                  disabled={user.kycStatus === 'pending' || user.kycStatus === 'verified'}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-sm text-white outline-none transition-all shadow-inner disabled:opacity-50"
                  required
                />
              </div>

              {/* Wallet Address */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Krypto Wallet Adresse (Payout Destination) *
                </label>
                <input 
                  type="text"
                  value={kycForm.walletAddress}
                  onChange={(e) => setKycForm({ ...kycForm, walletAddress: e.target.value })}
                  placeholder="0x71C... oder Payout Adresse"
                  disabled={user.kycStatus === 'pending' || user.kycStatus === 'verified'}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-sm text-white outline-none transition-all shadow-inner disabled:opacity-50"
                  required
                />
              </div>

            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Meldeadresse (Straße, PLZ, Ort, Land) *
              </label>
              <textarea 
                value={kycForm.address}
                onChange={(e) => setKycForm({ ...kycForm, address: e.target.value })}
                placeholder="Musterstraße 1, 12345 Musterstadt, Deutschland"
                rows={3}
                disabled={user.kycStatus === 'pending' || user.kycStatus === 'verified'}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-xl p-4 text-sm text-white outline-none transition-all shadow-inner resize-none disabled:opacity-50"
                required
              />
            </div>

            {/* Document Upload Simulation */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Ausweisdokument hochladen (Vorder- & Rückseite oder Reisepass) *
              </label>
              
              <div className="border-2 border-dashed border-slate-700 hover:border-cyan-500/50 rounded-2xl p-6 bg-slate-950/60 flex flex-col sm:flex-row items-center justify-between gap-4 transition-all">
                <div className="flex items-center gap-4 text-left">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-cyan-400">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="font-extrabold text-white text-sm block">
                      {kycForm.idFileName ? kycForm.idFileName : 'Kein Dokument ausgewählt'}
                    </span>
                    <span className="text-xs text-slate-400 block mt-0.5">Format: PDF, JPG oder PNG (Max. 10 MB)</span>
                  </div>
                </div>

                {user.kycStatus === 'unverified' && (
                  <button
                    type="button"
                    onClick={handleSimulateUpload}
                    className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-all whitespace-nowrap"
                  >
                    Ausweis auswählen (Simulation)
                  </button>
                )}
              </div>
            </div>

            {/* Submit Button */}
            {user.kycStatus === 'unverified' ? (
              <button
                type="submit"
                className="w-full py-5 rounded-2xl font-extrabold text-base shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-cyan-500/25 flex items-center justify-center gap-2 animate-pulse"
              >
                <ShieldCheck className="w-5 h-5" />
                <span>KYC-Daten verbindlich zur Prüfung übermitteln</span>
              </button>
            ) : (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center text-sm font-bold text-amber-400">
                Deine Daten wurden erfolgreich übermittelt und befinden sich in der manuellen Prüfung durch unser Support-Team.
              </div>
            )}

          </form>
        </div>

      </div>

      {/* --- SECTION 2: AVATAR WECHSLER & PROMO CODE --- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Avatar Wechsler */}
        <div className="lg:col-span-7 glass-panel p-8 rounded-3xl border border-slate-800 space-y-6">
          <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
            <User className="w-6 h-6 text-cyan-400" />
            <span>Profilbild (Avatar) auswählen</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">Wähle deinen repräsentativen Krypto-Avatar für die Bestenliste und den Live Community Chat.</p>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {AVATARS.map(av => (
              <div 
                key={av.id}
                onClick={() => handleSelectAvatar(av.url)}
                className={`p-4 rounded-2xl border flex flex-col items-center gap-3 cursor-pointer transition-all transform hover:scale-105 ${
                  user.avatar === av.url 
                    ? 'bg-cyan-500/20 border-cyan-400 shadow-lg shadow-cyan-500/20' 
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 opacity-70 hover:opacity-100'
                }`}
              >
                <img src={av.url} alt={av.name} className="w-16 h-16 rounded-2xl object-cover border border-slate-700 shadow-md" />
                <span className="text-xs font-extrabold text-white font-['Space_Grotesk'] text-center">{av.name}</span>
                {user.avatar === av.url && <span className="text-[10px] bg-cyan-500 text-slate-950 px-2 py-0.5 rounded-full font-bold">Aktiv</span>}
              </div>
            ))}
          </div>
        </div>

        {/* Promo Code Einlösen */}
        <div className="lg:col-span-5 glass-panel p-8 rounded-3xl border border-purple-500/40 space-y-6 bg-gradient-to-r from-purple-950/20 via-slate-900 to-slate-900 relative overflow-hidden shadow-xl">
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-400 shadow-md">
              <Gift className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk']">Promo Code Einlösen</h3>
              <p className="text-xs text-slate-400">Gib deinen Gutschein für sofortige Coins & XP ein.</p>
            </div>
          </div>

          <form onSubmit={handleClaimPromo} className="space-y-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Key className="w-4 h-4 text-purple-400" />
              </div>
              <input 
                type="text" 
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                placeholder="z.B. NEXUS2026, TITAN500..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-2xl py-4 pl-11 pr-4 text-sm font-bold text-white uppercase tracking-wider outline-none transition-all shadow-inner"
              />
            </div>
            <button 
              type="submit"
              disabled={!promoCode.trim()}
              className="w-full py-4 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 hover:from-purple-400 hover:to-rose-400 disabled:opacity-50 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-purple-500/25 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Gutschein einlösen</span>
            </button>
          </form>

          <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400 space-y-2">
            <span className="font-bold text-slate-300 block">Aktive Community Codes:</span>
            <div className="flex flex-wrap gap-2">
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-purple-300">NEXUS2026</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-cyan-300">TITAN500</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-amber-300">CRYPTOVIP</span>
              <span className="bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 font-semibold text-emerald-300">AIRDROP10K</span>
            </div>
          </div>
        </div>

      </div>

      {/* --- SECTION 3: REFERRAL / WERBER FUNKTION --- */}
      <div className="glass-panel p-8 sm:p-12 rounded-3xl border border-slate-800 space-y-6 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-800 pb-6">
          <div>
            <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <Users className="w-6 h-6 text-blue-400" />
              <span>Freunde werben (Referral / Werber Funktion)</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Lade Freunde über deinen Einladungslink in die Arena ein. Für jeden aktiven Freund erhältst du mächtige Coin- und XP-Ausschüttungen!
            </p>
          </div>
          <div className="flex items-center gap-2 bg-slate-950 p-3 rounded-2xl border border-slate-800 shadow-inner">
            <Users className="w-5 h-5 text-cyan-400" />
            <span className="text-sm font-bold text-slate-300">Geworbene Freunde:</span>
            <span className="text-lg font-extrabold text-cyan-400 font-['Space_Grotesk']">{refCount} Aktiv</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center pt-2">
          <div className="md:col-span-7 space-y-4">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Dein persönlicher Einladungslink:</label>
            <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-2xl border border-slate-800 shadow-inner">
              <input 
                type="text" 
                readOnly 
                value={`https://nexus-coin-arena.io/join?ref=${user.name}`}
                className="flex-grow bg-transparent px-4 py-2 text-xs sm:text-sm text-cyan-400 font-mono font-bold outline-none select-all"
              />
              <button 
                onClick={handleCopyRef}
                className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 flex-shrink-0"
              >
                <Copy className="w-4 h-4" />
                <span>Kopieren</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              *Sobald sich ein Freund über deinen Link registriert und Level 5 erreicht, wird er automatisch deinem Werber-Konto gutgeschrieben.
            </p>
          </div>

          <div className="md:col-span-5 bg-slate-950/80 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between shadow-inner space-y-4">
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-1">Ausstehender Werber-Bonus</span>
              <h4 className="text-2xl font-extrabold text-white font-['Space_Grotesk']">+150.000 Coins & +5.000 XP</h4>
              <p className="text-xs text-slate-400 mt-1">Belohnung für deine 3 aktiven geworbenen Freunde.</p>
            </div>
            <button
              onClick={handleClaimRefBonus}
              disabled={refClaimed}
              className={`w-full py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] flex items-center justify-center gap-2 ${
                refClaimed
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-amber-500/20 animate-bounce'
              }`}
            >
              <Gift className="w-4 h-4 fill-slate-950" />
              <span>{refClaimed ? 'Bonus bereits geclaimt ✓' : 'Werber-Bonus jetzt abholen'}</span>
            </button>
          </div>
        </div>

      </div>

      {/* --- SECTION 4: ZAHLUNGSHISTORIE & PAYMENT METHODEN --- */}
      <div className="space-y-12">
        
        {/* Zahlungshistorie */}
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2 border-b border-slate-800 pb-4">
            <Clock className="w-6 h-6 text-cyan-400" />
            <span>Deine Einzahlungs- & Zahlungshistorie</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-4 px-4">Zahlungs-ID</th>
                  <th className="py-4 px-4">Methode</th>
                  <th className="py-4 px-4">Betrag</th>
                  <th className="py-4 px-4">Datum</th>
                  <th className="py-4 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-sm">
                {user.paymentHistory?.map((pay) => (
                  <tr key={pay.id} className="transition-colors hover:bg-slate-800/40">
                    <td className="py-4 px-4 font-['Space_Grotesk'] font-bold text-slate-300">{pay.id}</td>
                    <td className="py-4 px-4 font-bold text-white flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-cyan-400" />
                      <span>{pay.method}</span>
                    </td>
                    <td className="py-4 px-4 font-['Space_Grotesk'] font-extrabold text-emerald-400">${pay.amount.toLocaleString()} {pay.currency}</td>
                    <td className="py-4 px-4 text-slate-400 text-xs">{new Date(pay.date).toLocaleString('de-DE')}</td>
                    <td className="py-4 px-4 text-right">
                      <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/30">
                        {pay.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Unterstützte Zahlungsmethoden Übersicht */}
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div>
            <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2 mb-1">
              <CreditCard className="w-6 h-6 text-blue-400" />
              <span>Unterstützte Zahlungsmethoden & Konditionen</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Eine transparente Übersicht aller verifizierten Ein- und Auszahlungsoptionen in der Nexus Arena. Es fallen generell 0% Bearbeitungsgebühren an.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 pt-2">
            {PAYMENT_METHODS_INFO.map((m) => {
              const Icon = m.icon;
              return (
                <div key={m.id} className={`p-6 rounded-2xl bg-slate-950/80 border ${m.color} flex flex-col justify-between shadow-inner group hover:scale-105 transition-all`}>
                  <div>
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-white mb-4 group-hover:bg-cyan-500/20 group-hover:text-cyan-400 transition-colors shadow">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h4 className="font-extrabold text-white font-['Space_Grotesk'] text-base mb-3 leading-tight">{m.name}</h4>
                    
                    <div className="space-y-2 text-xs text-slate-400 border-t border-slate-800/80 pt-3">
                      <div className="flex justify-between"><span>Gebühr:</span> <span className="font-bold text-emerald-400">{m.fee}</span></div>
                      <div className="flex justify-between"><span>Dauer:</span> <span className="font-bold text-white">{m.time}</span></div>
                      <div className="flex justify-between"><span>Limit:</span> <span className="font-bold text-cyan-400">{m.limit}</span></div>
                    </div>
                  </div>
                  <div className="mt-6 pt-3 border-t border-slate-800 text-[10px] text-slate-500 text-center uppercase tracking-wider font-bold">
                    Verifiziert & Aktiv
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
