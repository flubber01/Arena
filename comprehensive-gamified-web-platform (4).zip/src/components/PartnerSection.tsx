import React, { useState } from 'react';
import { Handshake, Send, CheckCircle2, Building, Mail, FileText, Briefcase } from 'lucide-react';
import confetti from 'canvas-confetti';

export const PartnerSection: React.FC = () => {
  const [formState, setFormState] = useState({
    companyName: '',
    contactEmail: '',
    partnerType: 'Krypto-Börse',
    partnershipScope: 'Liquiditätspool & Staking-Integration',
    message: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Trigger premium Confetti
    confetti({
      particleCount: 150,
      spread: 100,
      origin: { y: 0.5 }
    });

    setIsSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-widest mb-4">
          <Handshake className="w-4 h-4" />
          <span>Offizielles Partner-Programm</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
          Werde Nexus Verbund-Partner
        </h2>
        <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
          Bist du ein Krypto-Hersteller, eine Börse, ein Liquiditätsanbieter oder ein reichweitenstarker Influencer? Bewirb dich jetzt für eine strategische Partnerschaft und erhalte exklusiven Zugang zu unserer Staking- und Gamification-Infrastruktur.
        </p>
      </div>

      <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border border-blue-500/30 max-w-4xl mx-auto relative overflow-hidden shadow-2xl shadow-blue-500/10">
        <div className="absolute top-0 left-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        {isSubmitted ? (
          <div className="text-center py-12 space-y-6 animate-fade-in">
            <div className="w-20 h-20 bg-gradient-to-tr from-emerald-500 to-teal-500 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20 animate-bounce">
              <CheckCircle2 className="w-10 h-10 text-slate-950 font-extrabold" />
            </div>

            <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk']">
              Bewerbung erfolgreich übermittelt!
            </h3>

            <p className="text-slate-300 max-w-xl mx-auto text-sm sm:text-base leading-relaxed">
              Vielen Dank für das Interesse an einer Verbund-Partnerschaft mit der Nexus Arena. Unser Partner-Management-Team wird deine Anfrage prüfen und sich innerhalb von 24 Stunden unter <span className="text-cyan-400 font-bold">{formState.contactEmail}</span> melden.
            </p>

            <button
              onClick={() => setIsSubmitted(false)}
              className="px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-2xl border border-slate-700 transition-all shadow"
            >
              Weitere Bewerbung absenden
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Company Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Building className="w-4 h-4 text-cyan-400" />
                  <span>Unternehmen / Projekt-Name *</span>
                </label>
                <input
                  type="text"
                  value={formState.companyName}
                  onChange={(e) => setFormState({ ...formState, companyName: e.target.value })}
                  placeholder="z.B. Nexus Labs / Krypto Corp"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-2xl p-4 text-sm text-white outline-none transition-all shadow-inner"
                  required
                />
              </div>

              {/* Contact Email */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-cyan-400" />
                  <span>Kontakt E-Mail Adresse *</span>
                </label>
                <input
                  type="email"
                  value={formState.contactEmail}
                  onChange={(e) => setFormState({ ...formState, contactEmail: e.target.value })}
                  placeholder="partner@company.com"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-2xl p-4 text-sm text-white outline-none transition-all shadow-inner"
                  required
                />
              </div>

              {/* Partner Type */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-cyan-400" />
                  <span>Art der Partnerschaft *</span>
                </label>
                <select
                  value={formState.partnerType}
                  onChange={(e) => setFormState({ ...formState, partnerType: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-2xl p-4 text-sm text-white outline-none transition-all shadow-inner"
                >
                  <option value="Krypto-Börse">Krypto-Börse (CEX/DEX)</option>
                  <option value="Hardware / Software Hersteller">Hardware / Software Hersteller</option>
                  <option value="Liquiditätsanbieter (LP)">Liquiditätsanbieter (LP)</option>
                  <option value="Influencer / Key Opinion Leader">Influencer / Key Opinion Leader</option>
                  <option value="Institutionelle Bank / Fintech">Institutionelle Bank / Fintech</option>
                </select>
              </div>

              {/* Scope */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span>Gewünschter Integrationsumfang *</span>
                </label>
                <select
                  value={formState.partnershipScope}
                  onChange={(e) => setFormState({ ...formState, partnershipScope: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-2xl p-4 text-sm text-white outline-none transition-all shadow-inner"
                >
                  <option value="Liquiditätspool & Staking-Integration">Liquiditätspool & Staking-Integration</option>
                  <option value="Minispiel-Sponsoring & Co-Branding">Minispiel-Sponsoring & Co-Branding</option>
                  <option value="API-Anbindung & Zahlungsabwicklung">API-Anbindung & Zahlungsabwicklung</option>
                  <option value="Marketing-Kooperation & Airdrops">Marketing-Kooperation & Airdrops</option>
                </select>
              </div>

            </div>

            {/* Message */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>Nachricht & Projektbeschreibung *</span>
              </label>
              <textarea
                value={formState.message}
                onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                rows={5}
                placeholder="Beschreibe kurz dein Projekt, deine Reichweite oder deine geplante Investitionssumme..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-400 rounded-2xl p-4 text-sm text-white outline-none transition-all shadow-inner resize-none"
                required
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-5 rounded-2xl font-extrabold text-lg shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white shadow-blue-500/25 flex items-center justify-center gap-2 animate-pulse"
            >
              <Send className="w-5 h-5" />
              <span>Partnerschafts-Bewerbung verbindlich absenden</span>
            </button>

            <p className="text-[11px] text-center text-slate-400">
              *Alle Daten werden verschlüsselt übertragen und unterliegen den strengen Nexus Datenschutzrichtlinien.
            </p>

          </form>
        )}
      </div>

    </div>
  );
};
