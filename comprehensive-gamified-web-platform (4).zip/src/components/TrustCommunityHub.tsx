import React from 'react';
import { Star, Award, ShieldCheck, ExternalLink, MessageSquare, Send, Share2, Video, Globe, CheckCircle2 } from 'lucide-react';

export const TrustCommunityHub: React.FC = () => {
  return (
    <div className="border-t border-slate-800/80 bg-gradient-to-b from-[#0b0f19] via-[#0d1322] to-[#0b0f19] py-16 relative overflow-hidden z-20 shadow-2xl">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-cyan-500/5 via-blue-500/5 to-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* --- PART 1: TRUST SCORES (GOOGLE PLAY TOP 10 APP & APP STORE) --- */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/40 text-amber-300 text-xs font-extrabold uppercase tracking-widest mb-4 shadow-lg shadow-amber-500/10">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400 animate-pulse" />
            <span>Offizieller Trust Score & Auszeichnungen</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Verifiziertes Vertrauen der Top 10 Krypto-Apps
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            Unsere Bewertungen und Sicherheitszertifikate spiegeln das exzellente Feedback von über 184.000 aktiven Arena-Mitgliedern wider. Transparenz und Sicherheit stehen bei uns an erster Stelle.
          </p>
        </div>

        {/* Trust Score Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          
          {/* Google Play */}
          <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl border-2 border-cyan-500/40 relative overflow-hidden shadow-xl hover:scale-[1.02] transition-transform group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-xl group-hover:bg-cyan-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black bg-cyan-500 text-slate-950 px-3 py-1 rounded-full uppercase tracking-wider shadow">
                Google Play
              </span>
              <Award className="w-6 h-6 text-cyan-400" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">4.9</span>
              <span className="text-sm font-bold text-slate-400">/ 5.0</span>
            </div>
            <div className="flex items-center gap-1 text-amber-400 mb-3">
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <span className="text-xs text-slate-300 font-bold ml-1">(148.2K Rezensionen)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-medium">
              Ausgezeichnet als <span className="text-cyan-400 font-bold">Top 10 Finanz- & Gamification App 2026</span> im Google Play Store.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Verifizierter Trust Score</span>
            </div>
          </div>

          {/* Apple App Store */}
          <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl border-2 border-blue-500/40 relative overflow-hidden shadow-xl hover:scale-[1.02] transition-transform group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-xl group-hover:bg-blue-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black bg-blue-500 text-slate-950 px-3 py-1 rounded-full uppercase tracking-wider shadow">
                App Store
              </span>
              <Award className="w-6 h-6 text-blue-400" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">4.8</span>
              <span className="text-sm font-bold text-slate-400">/ 5.0</span>
            </div>
            <div className="flex items-center gap-1 text-amber-400 mb-3">
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <span className="text-xs text-slate-300 font-bold ml-1">(98.4K Rezensionen)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-medium">
              Platz #1 in der Kategorie <span className="text-blue-400 font-bold">Krypto Staking & Arena-Minispiele</span> im Apple App Store.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Verifizierter Trust Score</span>
            </div>
          </div>

          {/* Trustpilot */}
          <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl border-2 border-emerald-500/40 relative overflow-hidden shadow-xl hover:scale-[1.02] transition-transform group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black bg-emerald-500 text-slate-950 px-3 py-1 rounded-full uppercase tracking-wider shadow">
                Trustpilot
              </span>
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">4.9</span>
              <span className="text-sm font-bold text-slate-400">/ 5.0</span>
            </div>
            <div className="flex items-center gap-1 text-emerald-400 mb-3">
              <Star className="w-4 h-4 fill-emerald-400" />
              <Star className="w-4 h-4 fill-emerald-400" />
              <Star className="w-4 h-4 fill-emerald-400" />
              <Star className="w-4 h-4 fill-emerald-400" />
              <Star className="w-4 h-4 fill-emerald-400" />
              <span className="text-xs text-slate-300 font-bold ml-1">Exzellent</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-medium">
              Überragender TrustScore durch verifizierte Krypto-Staker, Auszahlungen und 24/7 Support-Feedback.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>100% Verifizierte Anleger</span>
            </div>
          </div>

          {/* BaFin & SEC Compliance Badge */}
          <div className="glass-panel-premium p-6 sm:p-8 rounded-3xl border-2 border-purple-500/40 relative overflow-hidden shadow-xl hover:scale-[1.02] transition-transform group flex flex-col justify-between">
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-xl group-hover:bg-purple-500/20 transition-all pointer-events-none" />
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-black bg-purple-500 text-white px-3 py-1 rounded-full uppercase tracking-wider shadow">
                  Compliance
                </span>
                <ShieldCheck className="w-6 h-6 text-purple-400" />
              </div>
              <h4 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Smart Contract Audit</h4>
              <p className="text-xs text-slate-300 leading-relaxed font-medium mb-4">
                Geprüfte Liquiditätspools, BaFin & SEC konforme KYC/AML User-ID Anbindung und lückenlose On-Chain Transparenz.
              </p>
            </div>
            <div className="pt-3 border-t border-slate-800 flex items-center gap-1.5 text-[11px] text-cyan-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>CertiK & Hacken Audited</span>
            </div>
          </div>

        </div>

        {/* --- PART 2: 24/7 SOCIAL MEDIA & PROBLEM CLEAR-UP CHANNELS --- */}
        <div className="text-center max-w-3xl mx-auto mb-12 pt-8 border-t border-slate-800/80">
          <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-blue-500/20 border border-blue-500/40 text-blue-300 text-xs font-extrabold uppercase tracking-widest mb-4 shadow-lg shadow-blue-500/10">
            <MessageSquare className="w-4 h-4 text-blue-400 animate-bounce" />
            <span>24/7 Community & Support Server</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Wir klären jedes Problem sofort auf
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            Tritt unseren offiziellen Kanälen auf YouTube, Telegram, Discord, Reddit, X (Twitter) und Facebook bei. Unser Moderatoren-Team und die Community stehen dir rund um die Uhr zur Seite!
          </p>
        </div>

        {/* Social Channels Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          
          {/* YouTube */}
          <a 
            href="https://youtube.com" 
            target="_blank" 
            rel="noreferrer"
            className="glass-panel p-6 rounded-3xl border border-red-500/30 hover:border-red-500/60 transition-all group flex items-start gap-4 hover:scale-[1.02] shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-500 flex-shrink-0 group-hover:scale-110 transition-transform shadow">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk']">YouTube Kanal</h4>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-red-400 transition-colors" />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                Wöchentliche Staking-Tutorials, Live-Analysen zum Coin Launch und exklusive Entwickler-AMAs.
              </p>
              <span className="text-[10px] text-red-400 font-bold block mt-2">▶ 240K Abonnenten</span>
            </div>
          </a>

          {/* Telegram */}
          <a 
            href="https://t.me/Nexus_VIP_Support" 
            target="_blank" 
            rel="noreferrer"
            className="glass-panel p-6 rounded-3xl border border-blue-500/30 hover:border-blue-500/60 transition-all group flex items-start gap-4 hover:scale-[1.02] shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400 flex-shrink-0 group-hover:scale-110 transition-transform shadow">
              <Send className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk']">Telegram VIP Gruppe</h4>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-400 transition-colors" />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                24/7 VIP Concierge & Live Community Chat für sofortige Problemlösungen und Airdrop-Fragen.
              </p>
              <span className="text-[10px] text-blue-400 font-bold block mt-2">💬 @Nexus_VIP_Support</span>
            </div>
          </a>

          {/* Discord */}
          <a 
            href="https://discord.com" 
            target="_blank" 
            rel="noreferrer"
            className="glass-panel p-6 rounded-3xl border border-indigo-500/30 hover:border-indigo-500/60 transition-all group flex items-start gap-4 hover:scale-[1.02] shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 flex-shrink-0 group-hover:scale-110 transition-transform shadow">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk']">Discord Server</h4>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 transition-colors" />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                Offizieller Nexus Arena Discord mit Ticket-System, Sprachkanälen und direktem Support durch Moderatoren.
              </p>
              <span className="text-[10px] text-indigo-400 font-bold block mt-2">🎮 85K Online</span>
            </div>
          </a>

          {/* Reddit */}
          <a 
            href="https://reddit.com" 
            target="_blank" 
            rel="noreferrer"
            className="glass-panel p-6 rounded-3xl border border-amber-500/30 hover:border-amber-500/60 transition-all group flex items-start gap-4 hover:scale-[1.02] shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-500 flex-shrink-0 group-hover:scale-110 transition-transform shadow">
              <span className="text-2xl font-black text-amber-500">r/</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk']">Reddit Community</h4>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 transition-colors" />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                Tiefgehende Diskussionen, Alpha-Leaks, Feedback-Runden und transparente Problemlösung durch die Community.
              </p>
              <span className="text-[10px] text-amber-400 font-bold block mt-2">🔥 r/NexusCoinArena</span>
            </div>
          </a>

          {/* X (Twitter) */}
          <a 
            href="https://x.com" 
            target="_blank" 
            rel="noreferrer"
            className="glass-panel p-6 rounded-3xl border border-cyan-500/30 hover:border-cyan-500/60 transition-all group flex items-start gap-4 hover:scale-[1.02] shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 flex-shrink-0 group-hover:scale-110 transition-transform shadow">
              <Share2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk']">X (Twitter) Feed</h4>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors" />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                Echtzeit-News, Ankündigungen zu Airdrop-Bounties, Staking-Raten und direkte Updates von unserem CEO.
              </p>
              <span className="text-[10px] text-cyan-400 font-bold block mt-2">🐦 @NexusCoinArena</span>
            </div>
          </a>

          {/* Facebook */}
          <a 
            href="https://facebook.com" 
            target="_blank" 
            rel="noreferrer"
            className="glass-panel p-6 rounded-3xl border border-blue-600/30 hover:border-blue-600/60 transition-all group flex items-start gap-4 hover:scale-[1.02] shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-600/40 flex items-center justify-center text-blue-500 flex-shrink-0 group-hover:scale-110 transition-transform shadow">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <h4 className="text-lg font-extrabold text-white font-['Space_Grotesk']">Facebook Gruppe</h4>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-400 transition-colors" />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                Offizielle Facebook-Community für den Austausch von Staking-Erfahrungen, Event-Einladungen und Support.
              </p>
              <span className="text-[10px] text-blue-400 font-bold block mt-2">👥 Nexus Coin Official</span>
            </div>
          </a>

        </div>

      </div>
    </div>
  );
};
