import React, { useState } from 'react';
import { UserState } from '../types';
import { Target, CheckCircle2, Award, Sparkles, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';

interface QuestsProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const Quests: React.FC<QuestsProps> = ({ user, setUser, addToast }) => {
  const [activeTab, setActiveTab] = useState<'all' | 'daily' | 'bounty' | 'milestone'>('all');

  const handleClaimQuest = (questId: string) => {
    const quest = user.quests.find(q => q.id === questId);
    if (!quest || quest.completed) return;

    // Trigger premium Confetti
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 }
    });

    setUser(prev => {
      const updatedQuests = prev.quests.map(q => q.id === questId ? { ...q, completed: true } : q);
      const newCoins = prev.coins + quest.rewardCoins;
      let newXp = prev.xp + quest.rewardXp;
      
      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'claim' as const,
        title: `Quest Belohnung: ${quest.title}`,
        amount: quest.rewardCoins,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: newXp,
        level: newLevel,
        nextLevelXp,
        quests: updatedQuests,
        transactions: [newTx, ...prev.transactions]
      };
    });

    addToast('success', 'Quest Abgeschlossen!', `Du hast +${quest.rewardCoins.toLocaleString()} Coins & +${quest.rewardXp} XP erhalten.`);
  };

  const filteredQuests = activeTab === 'all' ? user.quests : user.quests.filter(q => q.category === activeTab);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-purple-500 via-indigo-600 to-cyan-500 text-white shadow-lg shadow-purple-500/20">
            <Target className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Nexus Quests & Airdrop Bounties
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Schließe tägliche Herausforderungen, Community-Bounties und Level-Meilensteine ab, um dein Guthaben massiv auszubauen.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar">
          {(['all', 'daily', 'bounty', 'milestone'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all uppercase tracking-wider whitespace-nowrap ${
                activeTab === tab ? 'bg-cyan-500 text-slate-950 font-extrabold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab === 'all' ? 'Alle Quests' : tab}
            </button>
          ))}
        </div>
      </div>

      {/* Quests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
        {filteredQuests.map((quest) => {
          const isReady = quest.progress !== undefined && quest.maxProgress !== undefined 
            ? quest.progress >= quest.maxProgress 
            : true;

          return (
            <div
              key={quest.id}
              className={`p-6 sm:p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between transition-all border ${
                quest.completed
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                  : isReady
                  ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-cyan-500/50 shadow-xl shadow-cyan-500/10 hover:border-cyan-400 scale-[1.02]'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 shadow-lg'
              }`}
            >
              {quest.completed && (
                <div className="absolute top-0 right-0 px-4 py-1.5 rounded-bl-2xl bg-emerald-500/20 border-l border-b border-emerald-500/40 text-emerald-400 text-xs font-extrabold uppercase tracking-wider">
                  Abgeschlossen ✓
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-extrabold uppercase tracking-wider border ${
                    quest.category === 'daily' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                    quest.category === 'bounty' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                    'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                  }`}>
                    {quest.category}
                  </span>
                  {quest.category === 'bounty' && <Sparkles className="w-4 h-4 text-purple-400 animate-spin-slow" />}
                </div>

                <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">{quest.title}</h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6 min-h-[40px]">
                  {quest.description}
                </p>

                {/* Progress Bar if applicable */}
                {quest.progress !== undefined && quest.maxProgress !== undefined && (
                  <div className="mb-6 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <div className="flex items-center justify-between text-xs mb-1 font-bold">
                      <span className="text-slate-400">Fortschritt:</span>
                      <span className="text-cyan-400">{quest.progress} / {quest.maxProgress}</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (quest.progress / quest.maxProgress) * 100)}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Reward Display */}
                <div className="flex items-center gap-4 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800/80 mb-6">
                  <div className="flex items-center gap-1.5">
                    <Gift className="w-4 h-4 text-amber-400" />
                    <span className="font-extrabold text-white font-['Space_Grotesk'] text-sm">+{quest.rewardCoins.toLocaleString()} <span className="text-[10px] text-cyan-400">NEX</span></span>
                  </div>
                  <div className="flex items-center gap-1.5 border-l border-slate-800 pl-4">
                    <Award className="w-4 h-4 text-purple-400" />
                    <span className="font-extrabold text-white font-['Space_Grotesk'] text-sm">+{quest.rewardXp} <span className="text-[10px] text-purple-400">XP</span></span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {quest.completed ? (
                  <button disabled className="w-full py-3.5 rounded-2xl bg-slate-800 text-slate-500 font-bold text-xs border border-slate-700 cursor-not-allowed">
                    Belohnung bereits abgeholt
                  </button>
                ) : isReady ? (
                  <button
                    onClick={() => handleClaimQuest(quest.id)}
                    className="w-full py-3.5 rounded-2xl font-extrabold text-sm shadow-xl transition-all font-['Space_Grotesk'] bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-cyan-500/25 flex items-center justify-center gap-2 animate-pulse"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Belohnung Claimen</span>
                  </button>
                ) : (
                  <button disabled className="w-full py-3.5 rounded-2xl bg-slate-800 text-slate-500 font-bold text-xs border border-slate-700 cursor-not-allowed flex items-center justify-center gap-2">
                    <span>Aufgabe noch nicht erfüllt</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
