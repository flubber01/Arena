import React, { useState, useEffect, useRef } from 'react';
import { UserState } from '../types';
import { LEAGUES } from '../data/mockData';
import { Gamepad2, Play, RefreshCw, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface MiniGamesProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  onOpenShare: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const MiniGames: React.FC<MiniGamesProps> = ({ user, setUser, onOpenShare, addToast }) => {
  const [activeGame, setActiveGame] = useState<'slots' | 'crash' | 'coinflip' | 'mystery'>('slots');
  const currentLeagueInfo = LEAGUES.find(l => l.name === user.league) || LEAGUES[0];
  const coinMultiplier = currentLeagueInfo.coinMultiplier;

  // --- SLOT MACHINE STATE ---
  const [slotBet, setSlotBet] = useState(100);
  const [reels, setReels] = useState(['₿', '💎', '🚀']);
  const [isSpinningSlots, setIsSpinningSlots] = useState(false);
  const [slotMessage, setSlotMessage] = useState<string | null>(null);

  const SLOT_SYMBOLS = ['₿', '💎', '🚀', '7️⃣', '🍒'];

  const playSlots = () => {
    if (isSpinningSlots) return;
    if (user.coins < slotBet) {
      addToast('error', 'Nicht genug Guthaben', 'Du benötigst mehr Coins für diesen Slot-Einsatz!');
      return;
    }

    setIsSpinningSlots(true);
    setSlotMessage(null);

    // Deduct bet & log transaction
    setUser(prev => ({
      ...prev,
      coins: prev.coins - slotBet,
      transactions: [
        {
          id: `TX-${Date.now()}`,
          type: 'spend',
          title: 'Slot Machine Einsatz',
          amount: slotBet,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        },
        ...prev.transactions
      ]
    }));

    // Simulate spinning
    let counter = 0;
    const interval = setInterval(() => {
      setReels([
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
      ]);
      counter++;
      if (counter > 15) {
        clearInterval(interval);
        setIsSpinningSlots(false);

        // Final determination
        const finalReels = [
          SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
          SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
          SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)],
        ];
        setReels(finalReels);

        // Check win
        const [r1, r2, r3] = finalReels;
        if (r1 === r2 && r2 === r3) {
          // Jackpot
          const baseWin = slotBet * 10;
          const totalWin = Math.floor(baseWin * coinMultiplier);
          
          setUser(prev => ({
            ...prev,
            coins: prev.coins + totalWin,
            xp: prev.xp + 200,
            transactions: [
              {
                id: `TX-${Date.now()}`,
                type: 'earn',
                title: `🎰 Slot Jackpot (${r1}${r2}${r3})`,
                amount: totalWin,
                currency: 'NEX',
                timestamp: new Date().toISOString()
              },
              ...prev.transactions
            ]
          }));

          setSlotMessage(`🎰 MEGA JACKPOT! 3x ${r1} bringt dir +${totalWin.toLocaleString()} Coins (inkl. ${coinMultiplier}x Liga-Bonus)!`);
          addToast('success', '🎰 MEGA JACKPOT!', `Du hast +${totalWin.toLocaleString()} Coins gewonnen!`);
          confetti({ particleCount: 150, spread: 100, origin: { y: 0.6 } });
        } else if (r1 === r2 || r2 === r3 || r1 === r3) {
          // Small win
          const baseWin = slotBet * 2;
          const totalWin = Math.floor(baseWin * coinMultiplier);
          
          setUser(prev => ({
            ...prev,
            coins: prev.coins + totalWin,
            xp: prev.xp + 50,
            transactions: [
              {
                id: `TX-${Date.now()}`,
                type: 'earn',
                title: '🎰 Slot Gewinn (2 Gleiche)',
                amount: totalWin,
                currency: 'NEX',
                timestamp: new Date().toISOString()
              },
              ...prev.transactions
            ]
          }));

          setSlotMessage(`🔥 2 gleiche Symbole! Du gewinnst +${totalWin.toLocaleString()} Coins!`);
          addToast('success', 'Slot Gewinn!', `Du hast +${totalWin.toLocaleString()} Coins gewonnen!`);
        } else {
          setSlotMessage('Leider kein Gewinn. Versuch es gleich nochmal!');
          addToast('info', 'Kein Gewinn', 'Die Walzen brachten leider keinen Treffer.');
        }
      }
    }, 100);
  };

  // --- CRASH GAME STATE ---
  const [crashBet, setCrashBet] = useState(200);
  const [multiplier, setMultiplier] = useState(1.00);
  const [isCrashActive, setIsCrashActive] = useState(false);
  const [hasCrashed, setHasCrashed] = useState(false);
  const [cashoutWon, setCashoutWon] = useState<number | null>(null);
  const crashIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startCrash = () => {
    if (isCrashActive || hasCrashed) return;
    if (user.coins < crashBet) {
      addToast('error', 'Nicht genug Guthaben', 'Du benötigst mehr Coins für diesen Raketen-Start!');
      return;
    }

    setIsCrashActive(true);
    setHasCrashed(false);
    setCashoutWon(null);
    setMultiplier(1.00);

    // Deduct bet & log
    setUser(prev => ({
      ...prev,
      coins: prev.coins - crashBet,
      transactions: [
        {
          id: `TX-${Date.now()}`,
          type: 'spend',
          title: '🚀 Krypto Crash Einsatz',
          amount: crashBet,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        },
        ...prev.transactions
      ]
    }));

    const crashPoint = Math.random() * 4 + 1.2; // Crash between 1.2x and 5.2x

    let currentMult = 1.00;
    crashIntervalRef.current = setInterval(() => {
      currentMult += 0.05;
      setMultiplier(parseFloat(currentMult.toFixed(2)));

      if (currentMult >= crashPoint) {
        if (crashIntervalRef.current) clearInterval(crashIntervalRef.current);
        setIsCrashActive(false);
        setHasCrashed(true);
        addToast('error', '💥 Crash!', `Die Rakete ist bei ${currentMult.toFixed(2)}x explodiert.`);
      }
    }, 150);
  };

  const handleCashout = () => {
    if (!isCrashActive || hasCrashed) return;
    if (crashIntervalRef.current) clearInterval(crashIntervalRef.current);

    setIsCrashActive(false);
    const baseWin = Math.floor(crashBet * multiplier);
    const totalWin = Math.floor(baseWin * coinMultiplier);

    setCashoutWon(totalWin);
    setUser(prev => ({
      ...prev,
      coins: prev.coins + totalWin,
      xp: prev.xp + 150,
      transactions: [
        {
          id: `TX-${Date.now()}`,
          type: 'earn',
          title: `🚀 Crash Cashout (${multiplier.toFixed(2)}x)`,
          amount: totalWin,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        },
        ...prev.transactions
      ]
    }));

    addToast('success', '🚀 Cashout Erfolgreich!', `Du hast +${totalWin.toLocaleString()} Coins gesichert!`);
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
  };

  useEffect(() => {
    return () => {
      if (crashIntervalRef.current) clearInterval(crashIntervalRef.current);
    };
  }, []);

  // --- COIN FLIP STATE ---
  const [flipBet, setFlipBet] = useState(250);
  const [choice, setChoice] = useState<'Kopf' | 'Zahl'>('Kopf');
  const [flipResult, setFlipResult] = useState<'Kopf' | 'Zahl' | null>(null);
  const [isFlipping, setIsFlipping] = useState(false);
  const [flipMessage, setFlipMessage] = useState<string | null>(null);

  const playCoinFlip = () => {
    if (isFlipping) return;
    if (user.coins < flipBet) {
      addToast('error', 'Nicht genug Guthaben', 'Du benötigst mehr Coins für diesen Münzwurf!');
      return;
    }

    setIsFlipping(true);
    setFlipResult(null);
    setFlipMessage(null);

    // Deduct bet & log
    setUser(prev => ({
      ...prev,
      coins: prev.coins - flipBet,
      transactions: [
        {
          id: `TX-${Date.now()}`,
          type: 'spend',
          title: '🪙 Coin Flip Einsatz',
          amount: flipBet,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        },
        ...prev.transactions
      ]
    }));

    setTimeout(() => {
      const outcome = Math.random() < 0.5 ? 'Kopf' : 'Zahl';
      setFlipResult(outcome);
      setIsFlipping(false);

      if (outcome === choice) {
        const baseWin = flipBet * 2;
        const totalWin = Math.floor(baseWin * coinMultiplier);
        
        setUser(prev => ({
          ...prev,
          coins: prev.coins + totalWin,
          xp: prev.xp + 100,
          transactions: [
            {
              id: `TX-${Date.now()}`,
              type: 'earn',
              title: `🪙 Coin Flip Gewinn (${outcome})`,
              amount: totalWin,
              currency: 'NEX',
              timestamp: new Date().toISOString()
            },
            ...prev.transactions
          ]
        }));

        setFlipMessage(`🎉 Gewonnen! Die Münze zeigt ${outcome}. Du erhältst +${totalWin.toLocaleString()} Coins!`);
        addToast('success', '🪙 Münzwurf gewonnen!', `Die Münze zeigte ${outcome}. +${totalWin.toLocaleString()} Coins!`);
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      } else {
        setFlipMessage(`❌ Verloren. Die Münze zeigt ${outcome}. Versuche es erneut!`);
        addToast('error', '❌ Verloren', `Die Münze zeigte leider ${outcome}.`);
      }
    }, 1500);
  };

  // --- MYSTERY BOX STATE ---
  const [mysteryBet, setMysteryBet] = useState(500);
  const [openedBox, setOpenedBox] = useState<number | null>(null);
  const [boxReward, setBoxReward] = useState<number | null>(null);

  const openBox = (boxIndex: number) => {
    if (openedBox !== null) return;
    if (user.coins < mysteryBet) {
      addToast('error', 'Nicht genug Guthaben', 'Du benötigst mehr Coins für diese Truhe!');
      return;
    }

    // Deduct bet & log
    setUser(prev => ({
      ...prev,
      coins: prev.coins - mysteryBet,
      transactions: [
        {
          id: `TX-${Date.now()}`,
          type: 'spend',
          title: `🎁 Mystery Truhe #${boxIndex} Kauf`,
          amount: mysteryBet,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        },
        ...prev.transactions
      ]
    }));

    // Multipliers possible: 0.5x, 1.5x, 3x, 5x, 10x
    const mults = [0.5, 1.5, 2.5, 5.0, 10.0];
    const chosenMult = mults[Math.floor(Math.random() * mults.length)];
    const baseWin = Math.floor(mysteryBet * chosenMult);
    const totalWin = Math.floor(baseWin * coinMultiplier);

    setOpenedBox(boxIndex);
    setBoxReward(totalWin);

    setUser(prev => ({
      ...prev,
      coins: prev.coins + totalWin,
      xp: prev.xp + 250,
      transactions: [
        {
          id: `TX-${Date.now()}`,
          type: 'earn',
          title: `🎁 Mystery Truhe Gewinn (${chosenMult}x)`,
          amount: totalWin,
          currency: 'NEX',
          timestamp: new Date().toISOString()
        },
        ...prev.transactions
      ]
    }));

    if (chosenMult > 1.5) {
      addToast('success', '🎁 Mega Truhen-Gewinn!', `Du hast +${totalWin.toLocaleString()} Coins gefunden (${chosenMult}x)!`);
      confetti({ particleCount: 120, spread: 90, origin: { y: 0.6 } });
    } else {
      addToast('info', 'Truhe geöffnet', `Du hast ${totalWin.toLocaleString()} Coins gefunden.`);
    }
  };

  const resetMystery = () => {
    setOpenedBox(null);
    setBoxReward(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-600 text-white shadow-lg shadow-purple-500/20">
            <Gamepad2 className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Nexus Minispielautomaten
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Multipliziere deine Coins in sekundenschnelle. Dein aktueller Liga-Status gewährt dir einen permanenten <span className="text-cyan-400 font-bold">{coinMultiplier}x Multiplikator</span> auf alle Gewinne!
            </p>
          </div>
        </div>

        <button
          onClick={onOpenShare}
          className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-xl shadow-cyan-500/20 transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] text-sm"
        >
          <Sparkles className="w-4 h-4" />
          <span>Erfolge teilen (+500 Coins)</span>
        </button>
      </div>

      {/* Game Selection Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-12">
        <button
          onClick={() => setActiveGame('slots')}
          className={`p-6 rounded-3xl flex flex-col items-center justify-center gap-3 transition-all border ${
            activeGame === 'slots'
              ? 'bg-gradient-to-b from-purple-900/60 to-slate-900 border-purple-500/60 shadow-2xl shadow-purple-500/20 scale-105'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          <span className="text-3xl sm:text-4xl">🎰</span>
          <span className="font-extrabold font-['Space_Grotesk'] text-sm sm:text-base">Slot Machine</span>
        </button>

        <button
          onClick={() => setActiveGame('crash')}
          className={`p-6 rounded-3xl flex flex-col items-center justify-center gap-3 transition-all border ${
            activeGame === 'crash'
              ? 'bg-gradient-to-b from-rose-900/60 to-slate-900 border-rose-500/60 shadow-2xl shadow-rose-500/20 scale-105'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          <span className="text-3xl sm:text-4xl">🚀</span>
          <span className="font-extrabold font-['Space_Grotesk'] text-sm sm:text-base">Krypto Crash</span>
        </button>

        <button
          onClick={() => setActiveGame('coinflip')}
          className={`p-6 rounded-3xl flex flex-col items-center justify-center gap-3 transition-all border ${
            activeGame === 'coinflip'
              ? 'bg-gradient-to-b from-amber-900/60 to-slate-900 border-amber-500/60 shadow-2xl shadow-amber-500/20 scale-105'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          <span className="text-3xl sm:text-4xl">🪙</span>
          <span className="font-extrabold font-['Space_Grotesk'] text-sm sm:text-base">Coin Flip</span>
        </button>

        <button
          onClick={() => setActiveGame('mystery')}
          className={`p-6 rounded-3xl flex flex-col items-center justify-center gap-3 transition-all border ${
            activeGame === 'mystery'
              ? 'bg-gradient-to-b from-cyan-900/60 to-slate-900 border-cyan-500/60 shadow-2xl shadow-cyan-500/20 scale-105'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          <span className="text-3xl sm:text-4xl">🎁</span>
          <span className="font-extrabold font-['Space_Grotesk'] text-sm sm:text-base">Mystery Box</span>
        </button>
      </div>

      {/* --- GAME 1: SLOT MACHINE --- */}
      {activeGame === 'slots' && (
        <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border border-purple-500/30 relative overflow-hidden max-w-4xl mx-auto shadow-2xl shadow-purple-500/10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="text-center mb-8">
            <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
              Nexus 3-Reel Slot Machine
            </h3>
            <p className="text-slate-300 text-sm">
              Triff 3 gleiche Symbole für den Mega Jackpot! Dein Gewinn wird mit <span className="text-cyan-400 font-bold">{coinMultiplier}x</span> multipliziert.
            </p>
          </div>

          {/* Slot Reels Display */}
          <div className="bg-slate-950 p-6 sm:p-10 rounded-3xl border-4 border-slate-800 flex items-center justify-center gap-4 sm:gap-8 mb-8 shadow-inner">
            {reels.map((symbol, idx) => (
              <div 
                key={idx}
                className={`w-24 sm:w-36 h-24 sm:h-36 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-800 border-2 border-purple-500/40 flex items-center justify-center text-5xl sm:text-7xl shadow-lg transform transition-all ${
                  isSpinningSlots ? 'animate-pulse scale-105 filter blur-[1px]' : ''
                }`}
              >
                {symbol}
              </div>
            ))}
          </div>

          {/* Bet Controls & Spin */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-4 w-full sm:w-auto justify-center">
              <span className="text-sm font-bold text-slate-400">Einsatz:</span>
              {[100, 250, 500, 1000].map((amount) => (
                <button
                  key={amount}
                  onClick={() => setSlotBet(amount)}
                  disabled={isSpinningSlots}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                    slotBet === amount
                      ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  {amount}
                </button>
              ))}
            </div>

            <button
              onClick={playSlots}
              disabled={isSpinningSlots}
              className={`w-full sm:w-auto px-10 py-4 rounded-2xl font-extrabold text-base shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] flex items-center justify-center gap-2 ${
                isSpinningSlots
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed scale-95'
                  : 'bg-gradient-to-r from-purple-500 via-indigo-600 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-white shadow-purple-500/30 animate-pulse'
              }`}
            >
              <Play className="w-5 h-5 fill-white" />
              <span>{isSpinningSlots ? 'Walzen drehen...' : 'SPIN STARTEN'}</span>
            </button>
          </div>

          {slotMessage && (
            <div className="mt-6 p-4 rounded-2xl bg-slate-900/90 border border-purple-500/50 text-center animate-fade-in shadow-xl">
              <p className="text-sm sm:text-base font-bold text-white">{slotMessage}</p>
            </div>
          )}
        </div>
      )}

      {/* --- GAME 2: CRASH GAME --- */}
      {activeGame === 'crash' && (
        <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border border-rose-500/30 relative overflow-hidden max-w-4xl mx-auto shadow-2xl shadow-rose-500/10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="text-center mb-8">
            <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
              Krypto Raketen Crash
            </h3>
            <p className="text-slate-300 text-sm">
              Die Rakete steigt und der Multiplikator klettert! Sichere deinen Gewinn (Cashout), bevor die Rakete explodiert.
            </p>
          </div>

          {/* Crash Display Screen */}
          <div className="bg-slate-950 p-12 rounded-3xl border-4 border-slate-800 flex flex-col items-center justify-center min-h-[300px] mb-8 relative overflow-hidden shadow-inner">
            <div className="absolute inset-0 bg-gradient-to-b from-rose-500/5 via-transparent to-transparent pointer-events-none" />

            <div className="z-10 flex flex-col items-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Aktueller Multiplikator</span>
              <span className={`text-6xl sm:text-8xl font-black font-['Space_Grotesk'] tracking-tight transition-all ${
                hasCrashed ? 'text-rose-500 animate-bounce' : isCrashActive ? 'text-emerald-400 animate-pulse' : 'text-white'
              }`}>
                {multiplier.toFixed(2)}x
              </span>

              {hasCrashed && (
                <span className="mt-4 px-4 py-1.5 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 font-extrabold text-sm animate-fade-in">
                  💥 RAKETE CRASHED BEI {multiplier.toFixed(2)}x
                </span>
              )}

              {cashoutWon !== null && (
                <span className="mt-4 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-extrabold text-sm animate-fade-in">
                  🎉 CASHOUT ERFOLGREICH: +{cashoutWon.toLocaleString()} Coins gewonnen!
                </span>
              )}
            </div>

            {/* Rocket Animation Graphic */}
            <div className={`absolute bottom-4 transition-all duration-300 ${
              hasCrashed ? 'hidden' : isCrashActive ? 'translate-y-[-120px] scale-150 animate-float' : 'translate-y-0'
            }`}>
              <span className="text-6xl filter drop-shadow-[0_10px_20px_rgba(244,63,94,0.5)]">🚀</span>
            </div>
          </div>

          {/* Bet & Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-4 w-full sm:w-auto justify-center">
              <span className="text-sm font-bold text-slate-400">Einsatz:</span>
              {[200, 500, 1000, 2500].map((amount) => (
                <button
                  key={amount}
                  onClick={() => setCrashBet(amount)}
                  disabled={isCrashActive}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                    crashBet === amount
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  {amount}
                </button>
              ))}
            </div>

            {/* Action Button */}
            {!isCrashActive ? (
              <button
                onClick={startCrash}
                className="w-full sm:w-auto px-10 py-4 rounded-2xl font-extrabold text-base shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] bg-gradient-to-r from-rose-500 via-red-600 to-purple-600 hover:from-rose-400 hover:to-purple-500 text-white shadow-rose-500/30"
              >
                Rakete Starten
              </button>
            ) : (
              <button
                onClick={handleCashout}
                className="w-full sm:w-auto px-10 py-4 rounded-2xl font-extrabold text-base shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 shadow-emerald-500/30 animate-bounce"
              >
                CASHOUT ({Math.floor(crashBet * multiplier * coinMultiplier).toLocaleString()} Coins)
              </button>
            )}
          </div>
        </div>
      )}

      {/* --- GAME 3: COIN FLIP --- */}
      {activeGame === 'coinflip' && (
        <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border border-amber-500/30 relative overflow-hidden max-w-4xl mx-auto shadow-2xl shadow-amber-500/10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="text-center mb-8">
            <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
              Kopf oder Zahl (Coin Flip)
            </h3>
            <p className="text-slate-300 text-sm">
              Wähle deine Seite und verdopple deinen Einsatz sofort! Inklusive <span className="text-cyan-400 font-bold">{coinMultiplier}x</span> Liga-Bonus.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 items-center mb-8">
            {/* Coin Animation */}
            <div className="bg-slate-950 p-10 rounded-3xl border-4 border-slate-800 flex flex-col items-center justify-center min-h-[250px] shadow-inner">
              <div className={`w-36 h-36 rounded-full bg-gradient-to-tr from-yellow-500 via-amber-400 to-yellow-600 border-4 border-yellow-300 flex items-center justify-center shadow-2xl shadow-amber-500/40 transition-transform duration-1000 ${
                isFlipping ? 'animate-spin-slow scale-110 filter blur-[1px]' : ''
              }`}>
                <span className="text-5xl font-black text-slate-950 font-['Space_Grotesk']">
                  {flipResult ? (flipResult === 'Kopf' ? 'KOPF' : 'ZAHL') : 'NEX'}
                </span>
              </div>
              <span className="text-xs text-slate-400 mt-6 font-semibold uppercase tracking-wider">
                {isFlipping ? 'Münze wirbelt durch die Luft...' : flipResult ? `Ergebnis: ${flipResult}` : 'Bereit zum Wurf'}
              </span>
            </div>

            {/* Controls */}
            <div className="space-y-6 bg-slate-900/60 p-6 rounded-3xl border border-slate-800">
              <div>
                <span className="block text-sm font-bold text-slate-400 mb-3">1. Wähle deine Seite:</span>
                <div className="grid grid-cols-2 gap-4">
                  {(['Kopf', 'Zahl'] as const).map((item) => (
                    <button
                      key={item}
                      onClick={() => setChoice(item)}
                      disabled={isFlipping}
                      className={`py-4 rounded-2xl font-extrabold text-base transition-all border ${
                        choice === item
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 border-yellow-400 shadow-lg shadow-amber-500/25'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="block text-sm font-bold text-slate-400 mb-3">2. Wähle deinen Einsatz:</span>
                <div className="grid grid-cols-4 gap-2">
                  {[250, 500, 1000, 2500].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setFlipBet(amount)}
                      disabled={isFlipping}
                      className={`py-2.5 rounded-xl text-xs font-extrabold transition-all ${
                        flipBet === amount
                          ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                      }`}
                    >
                      {amount}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={playCoinFlip}
                disabled={isFlipping}
                className={`w-full py-4 rounded-2xl font-extrabold text-base shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] flex items-center justify-center gap-2 ${
                  isFlipping
                    ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed scale-95'
                    : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-amber-500/30 animate-pulse'
                }`}
              >
                <Play className="w-5 h-5 fill-slate-950" />
                <span>{isFlipping ? 'Münze fliegt...' : 'MÜNZE WERFEN'}</span>
              </button>
            </div>
          </div>

          {flipMessage && (
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/50 text-center animate-fade-in shadow-xl">
              <p className="text-sm sm:text-base font-bold text-white">{flipMessage}</p>
            </div>
          )}
        </div>
      )}

      {/* --- GAME 4: MYSTERY BOX --- */}
      {activeGame === 'mystery' && (
        <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border border-cyan-500/30 relative overflow-hidden max-w-4xl mx-auto shadow-2xl shadow-cyan-500/10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="text-center mb-8">
            <h3 className="text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
              Nexus Mystery Truhen
            </h3>
            <p className="text-slate-300 text-sm">
              Öffne eine der 3 geheimnisvollen Truhen für Multiplikatoren bis zu <span className="text-amber-400 font-bold">10x</span>!
            </p>
          </div>

          {/* Boxes Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
            {[1, 2, 3].map((boxNum) => {
              const isOpened = openedBox === boxNum;
              return (
                <div
                  key={boxNum}
                  onClick={() => openBox(boxNum)}
                  className={`p-8 rounded-3xl flex flex-col items-center justify-center gap-4 transition-all cursor-pointer border-2 relative overflow-hidden ${
                    isOpened
                      ? 'bg-gradient-to-b from-cyan-500/20 to-slate-900 border-cyan-400 shadow-2xl shadow-cyan-500/30 scale-105'
                      : openedBox !== null
                      ? 'bg-slate-900/40 border-slate-800 opacity-50 cursor-not-allowed'
                      : 'bg-slate-900/80 border-slate-700 hover:border-cyan-500/50 hover:scale-105 shadow-xl'
                  }`}
                >
                  <span className={`text-6xl transition-transform duration-500 ${isOpened ? 'scale-125 animate-bounce' : ''}`}>
                    {isOpened ? '🎁' : '📦'}
                  </span>

                  <span className="font-extrabold text-white font-['Space_Grotesk'] text-lg">
                    Truhe #{boxNum}
                  </span>

                  {isOpened && boxReward !== null && (
                    <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center animate-fade-in z-10">
                      <Sparkles className="w-8 h-8 text-cyan-400 animate-spin-slow mb-2" />
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Gewinn</span>
                      <span className="text-2xl font-black text-cyan-400 font-['Space_Grotesk'] mt-1">
                        +{boxReward.toLocaleString()} Coins
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Bet Selection & Reset */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 bg-slate-900/60 p-6 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-4 w-full sm:w-auto justify-center">
              <span className="text-sm font-bold text-slate-400">Truhen-Preis:</span>
              {[500, 1000, 2500, 5000].map((amount) => (
                <button
                  key={amount}
                  onClick={() => setMysteryBet(amount)}
                  disabled={openedBox !== null}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                    mysteryBet === amount
                      ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  {amount}
                </button>
              ))}
            </div>

            {openedBox !== null && (
              <button
                onClick={resetMystery}
                className="w-full sm:w-auto px-8 py-4 rounded-2xl font-extrabold text-sm shadow-xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] bg-gradient-to-r from-slate-700 to-slate-600 hover:from-slate-600 hover:to-slate-50 text-white flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Neue Truhen laden</span>
              </button>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
