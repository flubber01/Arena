import React, { useState } from 'react';
import { UserState } from '../types';
import { Rocket, Sparkles, CheckCircle2, ShieldCheck, Award, Share2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface FreeLaunchProps {
  user: UserState;
  setUser: React.Dispatch<React.SetStateAction<UserState>>;
  onOpenShare: () => void;
  addToast: (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => void;
}

export const FreeLaunch: React.FC<FreeLaunchProps> = ({ user, setUser, onOpenShare, addToast }) => {
  const [claimStatus, setClaimStatus] = useState<string | null>(null);

  const handleClaimFreeLaunch = () => {
    if (user.freeLaunchClaimed) {
      addToast('error', 'Bereits geclaimt', 'Du hast deinen FreeLaunch Airdrop bereits erfolgreich beansprucht!');
      return;
    }

    confetti({
      particleCount: 200,
      spread: 120,
      origin: { y: 0.5 }
    });

    setUser(prev => {
      const newCoins = prev.coins + 5000;
      let newXp = prev.xp + 500;

      let newLevel = prev.level;
      let nextLevelXp = prev.nextLevelXp;
      while (newXp >= nextLevelXp && newLevel < 1200) {
        newLevel += 1;
        newXp -= nextLevelXp;
        nextLevelXp = Math.floor(nextLevelXp * 1.15) + 500;
      }

      const newTx = {
        id: `TX-${Date.now()}`,
        type: 'earn' as const,
        title: '🚀 Fairlaunch Airdrop Claim',
        amount: 5000,
        currency: 'NEX',
        timestamp: new Date().toISOString()
      };

      return {
        ...prev,
        coins: newCoins,
        xp: newXp,
        level: newLevel,
        nextLevelXp,
        freeLaunchClaimed: true,
        transactions: [newTx, ...prev.transactions]
      };
    });

    const msg = '🚀 MEGA AIRDROP ERFOLGREICH: +5.000 NEXUS Coins & +500 XP wurden deinem Wallet gutgeschrieben!';
    setClaimStatus(msg);
    addToast('drop', 'Airdrop Geclaimt!', 'Du hast +5.000 NEXUS Coins & +500 XP erhalten.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-slate-950 shadow-lg shadow-emerald-500/20">
            <Rocket className="w-8 h-8 font-extrabold" />
          </div>
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Nexus Fairlaunch & Airdrop Claim
            </h2>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
              Sichere dir deinen Anteil am Community-Airdrop. Jeder neue Teilnehmer erhält einmalig <span className="text-emerald-400 font-bold">5.000 NEXUS Coins</span> absolut kostenlos!
            </p>
          </div>
        </div>

        <button
          onClick={onOpenShare}
          className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-xl shadow-cyan-500/20 transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] text-sm"
        >
          <Share2 className="w-4 h-4" />
          <span>Airdrop teilen (+500 Coins)</span>
        </button>
      </div>

      {/* Main Claim Banner Card */}
      <div className="glass-panel-premium p-8 sm:p-12 rounded-3xl border-2 border-emerald-500/50 mb-12 relative overflow-hidden shadow-2xl shadow-emerald-500/10">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-extrabold uppercase tracking-widest animate-pulse">
                Live Fairlaunch Event
              </span>
              <span className="text-xs text-slate-400 font-semibold">Endet in 3 Tagen</span>
            </div>

            <h3 className="text-3xl sm:text-5xl font-extrabold text-white font-['Space_Grotesk'] leading-[1.1]">
              Sichere dir jetzt <br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 via-cyan-400 to-blue-500">
                5.000 NEXUS Coins
              </span>
            </h3>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-xl">
              Der NEXUS Token bildet das Rückgrat unserer Gamification- und Staking-Arena. Nutze deine geclaimten Coins sofort für Minispiele, Glücksrad-Drehs oder als Startkapital für Staking-Pools!
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={handleClaimFreeLaunch}
                disabled={user.freeLaunchClaimed}
                className={`px-10 py-5 rounded-2xl font-extrabold text-lg shadow-2xl transition-all transform hover:-translate-y-1 font-['Space_Grotesk'] flex items-center gap-3 ${
                  user.freeLaunchClaimed
                    ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed scale-95'
                    : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-emerald-500/30 animate-pulse'
                }`}
              >
                <Sparkles className="w-6 h-6 fill-slate-950" />
                <span>{user.freeLaunchClaimed ? 'Airdrop bereits geclaimt ✓' : '5.000 COINS JETZT CLAIMEN'}</span>
              </button>
            </div>

            {claimStatus && (
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/50 flex items-center gap-3 animate-fade-in shadow-xl">
                <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0 animate-bounce" />
                <p className="text-sm sm:text-base font-bold text-white">{claimStatus}</p>
              </div>
            )}
          </div>

          <div className="lg:col-span-5 bg-slate-950/80 p-6 sm:p-8 rounded-3xl border-2 border-slate-800/80 space-y-6 shadow-inner">
            <h4 className="text-xl font-extrabold text-white font-['Space_Grotesk'] flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Airdrop Zuteilungs-Details</span>
            </h4>

            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm p-3.5 bg-slate-900/60 rounded-2xl border border-slate-800">
                <span className="text-slate-400 font-medium">Airdrop Menge pro User:</span>
                <span className="font-extrabold text-emerald-400 font-['Space_Grotesk'] text-base">5.000 NEX</span>
              </div>
              <div className="flex items-center justify-between text-sm p-3.5 bg-slate-900/60 rounded-2xl border border-slate-800">
                <span className="text-slate-400 font-medium">Erfahrungspunkte (XP):</span>
                <span className="font-extrabold text-purple-400 font-['Space_Grotesk'] text-base">+500 XP Boost</span>
              </div>
              <div className="flex items-center justify-between text-sm p-3.5 bg-slate-900/60 rounded-2xl border border-slate-800">
                <span className="text-slate-400 font-medium">Vesting / Sperrfrist:</span>
                <span className="font-extrabold text-cyan-400 font-['Space_Grotesk'] text-base">0 Tage (Sofort nutzbar)</span>
              </div>
              <div className="flex items-center justify-between text-sm p-3.5 bg-slate-900/60 rounded-2xl border border-slate-800">
                <span className="text-slate-400 font-medium">Netzwerk-Gebühr (Gas):</span>
                <span className="font-extrabold text-yellow-400 font-['Space_Grotesk'] text-base">Kostenlos (Sponsored)</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              *Jeder Nutzer kann diesen Airdrop genau einmal beanspruchen. Sybil-Attacken oder mehrfache Wallets werden durch unser automatisiertes Nexus-Sicherheitssystem blockiert.
            </p>
          </div>

        </div>

      </div>

      {/* Tokenomics Section */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800">
        <h3 className="text-2xl font-extrabold text-white font-['Space_Grotesk'] mb-6 flex items-center gap-2">
          <Award className="w-6 h-6 text-cyan-400" />
          <span>Nexus Tokenomics & Verteilung</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 text-center space-y-2">
            <span className="text-3xl font-extrabold text-cyan-400 font-['Space_Grotesk'] block">40%</span>
            <span className="text-sm font-bold text-white block">Staking & Rewards Pool</span>
            <p className="text-xs text-slate-400">Reserviert für Staking-Ausschüttungen und Minispiel-Gewinne.</p>
          </div>

          <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 text-center space-y-2">
            <span className="text-3xl font-extrabold text-purple-400 font-['Space_Grotesk'] block">25%</span>
            <span className="text-sm font-bold text-white block">Community Fairlaunch</span>
            <p className="text-xs text-slate-400">Direkte Verteilung an unsere treuen Nutzer und Airdrop-Teilnehmer.</p>
          </div>

          <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 text-center space-y-2">
            <span className="text-3xl font-extrabold text-amber-400 font-['Space_Grotesk'] block">20%</span>
            <span className="text-sm font-bold text-white block">Liquidität & Börsen</span>
            <p className="text-xs text-slate-400">Gesperrte Liquidität auf dezentralen und zentralen Börsen (DEX/CEX).</p>
          </div>

          <div className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800/80 text-center space-y-2">
            <span className="text-3xl font-extrabold text-rose-400 font-['Space_Grotesk'] block">15%</span>
            <span className="text-sm font-bold text-white block">Entwicklung & Marketing</span>
            <p className="text-xs text-slate-400">Für die kontinuierliche Weiterentwicklung und globale Kampagnen.</p>
          </div>
        </div>
      </div>

    </div>
  );
};
