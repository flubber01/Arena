export type LeagueTier = 'Bronze' | 'Silver' | 'Gold' | 'Diamond' | 'Master' | 'Apex';

export interface Transaction {
  id: string;
  type: 'earn' | 'spend' | 'stake' | 'claim';
  title: string;
  amount: number;
  currency: string;
  timestamp: string;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  rewardCoins: number;
  rewardXp: number;
  completed: boolean;
  category: 'daily' | 'bounty' | 'milestone';
  progress?: number;
  maxProgress?: number;
}

export interface ChatMessage {
  id: string;
  sender: string;
  avatar: string;
  text: string;
  timestamp: string;
  isBot?: boolean;
  isCurrentUser?: boolean;
  badge?: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'drop';
  title: string;
  message: string;
}

export interface CryptoStakingPool {
  id: string;
  coin: string;
  name: string;
  icon: string;
  minAmount: number;
  maxAmount: number;
  roi: number; // 20% to 70%
  durationDays: number;
  color: string;
  popular?: boolean;
}

export interface SurveyOffer {
  id: string;
  provider: string;
  title: string;
  timeMin: number;
  rewardCoins: number;
  rewardUsd: number;
  completed: boolean;
  rating: number;
}

export interface LootChest {
  id: string;
  name: string;
  tier: LeagueTier;
  minInvest: number;
  icon: string;
  color: string;
  guaranteedLoot: string[];
  opened: boolean;
}

export interface NftItem {
  id: string;
  name: string;
  image: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
  roiBoost: number; // e.g. +5% ROI
  staked: boolean;
  valueUsd: number;
}

export interface UserState {
  id: string; // User ID for payout
  name: string;
  avatar: string;
  coins: number;
  investedAmount: number;
  level: number;
  xp: number;
  nextLevelXp: number;
  league: LeagueTier;
  dailyStreak: number;
  lastDailyClaim: string | null;
  weeklyClaimed: boolean;
  lastWeeklyClaim: string | null;
  spinsLeft: number;
  freeLaunchClaimed: boolean;
  clickMultiplierUpgrade: number;
  autoClickerCount: number;
  activeInvestments: Array<{
    id: string;
    tierName: string;
    coin: string;
    amount: number;
    roiPercentage: number;
    expectedReturn: number;
    startDate: string;
    endDate: string;
    claimed: boolean;
    isPreLaunchLocked: boolean; // Locked until coin launch
  }>;
  transactions: Transaction[];
  quests: Quest[];
  nfts: NftItem[];
  openedChests: string[]; // Chest IDs
  completedSurveys: string[]; // Survey IDs
  claimedPromoCodes: string[]; // Claimed promo codes
  energy: number;
  maxEnergy: number;
  profitPerHour: number;
  fullEnergyRefillsLeft: number;
  turboBoostsLeft: number;
  turboEndTime: number | null;
  connectedWallet: string | null;
  activeSquad: string | null;
  dailyCipherClaimed: boolean;
  kycStatus: 'unverified' | 'pending' | 'verified';
  fullName: string;
  address: string;
  idDocument: string | null;
  paymentHistory: Array<{
    id: string;
    method: string;
    amount: number;
    currency: string;
    date: string;
    status: string;
  }>;
  adminSettings: AdminSettingsConfig;
}

export interface AdminSettingsConfig {
  countdownDays: number;
  countdownHours: number;
  countdownMinutes: number;
  countdownSeconds: number;
  payAddressBtc: string;
  payAddressEth: string;
  payAddressSol: string;
  payAddressUsdt: string;
  adIntervalMinutes: number; // e.g. 8 minutes
  adDurationSeconds: number; // e.g. 35 seconds
  adClientUrl: string;
  socialYoutube: string;
  socialTelegram: string;
  socialDiscord: string;
  socialReddit: string;
  socialX: string;
  socialFacebook: string;
}

export interface LeagueInfo {
  name: LeagueTier;
  minInvestment: number;
  minLevel: number;
  roiBonus: number;
  coinMultiplier: number;
  color: string;
  bgGradient: string;
  badgeUrl: string;
  description: string;
}

export interface InvestmentPackage {
  id: string;
  name: string;
  subtitle: string;
  minAmount: number;
  maxAmount: number;
  baseRoi: number;
  durationDays: number;
  description: string;
  popular?: boolean;
  badge?: string;
  features: string[];
  color: string;
}

export type PaymentMethod = 'crypto' | 'creditcard' | 'paypal' | 'applepay' | 'klarna';

export interface LeaderboardUser {
  id: string;
  rank: number;
  name: string;
  avatar: string;
  coins: number;
  invested: number;
  level: number;
  league: LeagueTier;
  isCurrentUser?: boolean;
}

export type ActiveTab = 
  | 'dashboard' 
  | 'clicker' 
  | 'league' 
  | 'wheel' 
  | 'minigames' 
  | 'invest' 
  | 'surveys' 
  | 'chests' 
  | 'nfts' 
  | 'freelaunch' 
  | 'quests' 
  | 'history' 
  | 'analytics' 
  | 'member' 
  | 'admin' 
  | 'partners';
