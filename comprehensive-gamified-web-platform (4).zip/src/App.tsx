import React, { useState } from 'react';
import { UserState, ActiveTab, ToastMessage } from './types';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { DailyWeeklyRewards } from './components/DailyWeeklyRewards';
import { LeagueMode } from './components/LeagueMode';
import { WheelOfFortune } from './components/WheelOfFortune';
import { MiniGames } from './components/MiniGames';
import { CoinClicker } from './components/CoinClicker';
import { InvestmentStaking } from './components/InvestmentStaking';
import { SurveysOffers } from './components/SurveysOffers';
import { LootChests } from './components/LootChests';
import { NftGallery } from './components/NftGallery';
import { FreeLaunch } from './components/FreeLaunch';
import { Quests } from './components/Quests';
import { TransactionHistory } from './components/TransactionHistory';
import { PartnerSection } from './components/PartnerSection';
import { PartnerTicker } from './components/PartnerTicker';
import { TrustCommunityHub } from './components/TrustCommunityHub';
import { ShareModal } from './components/ShareModal';
import { ToastContainer } from './components/Toast';
import { LiveChat } from './components/LiveChat';
import { HelpChatbot } from './components/HelpChatbot';
import { AnalyticsAdSenseHub } from './components/AnalyticsAdSenseHub';
import { MemberArea } from './components/MemberArea';
import { AdminArea } from './components/AdminArea';
import { AdOverlay } from './components/AdOverlay';
import { INITIAL_NFTS } from './data/mockData';
import { Gift, Gamepad2, TrendingUp, MousePointer, FileText, Package, Award, Rocket } from 'lucide-react';

const App: React.FC = () => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'success' | 'error' | 'info' | 'drop', title: string, message: string) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Initial rich user state
  const [user, setUser] = useState<UserState>({
    id: '8842',
    name: 'CryptoTitan_99',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
    coins: 125000,
    investedAmount: 2500, // Starts at Gold tier
    level: 18,
    xp: 3400,
    nextLevelXp: 5000,
    league: 'Gold',
    dailyStreak: 3,
    lastDailyClaim: null,
    weeklyClaimed: false,
    lastWeeklyClaim: null,
    spinsLeft: 5,
    freeLaunchClaimed: false,
    clickMultiplierUpgrade: 0,
    autoClickerCount: 0,
    nfts: INITIAL_NFTS,
    openedChests: ['c_gold'],
    completedSurveys: ['s3'],
    claimedPromoCodes: [],
    energy: 1000,
    maxEnergy: 1000,
    profitPerHour: 250000,
    fullEnergyRefillsLeft: 3,
    turboBoostsLeft: 3,
    turboEndTime: null,
    connectedWallet: null,
    activeSquad: null,
    dailyCipherClaimed: false,
    kycStatus: 'unverified',
    fullName: '',
    address: '',
    idDocument: null,
    paymentHistory: [
      {
        id: 'PAY-8842-1',
        method: 'Krypto (BTC)',
        amount: 2500,
        currency: 'USD',
        date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'Erfolgreich'
      }
    ],
    activeInvestments: [
      {
        id: 'INV-883291',
        tierName: 'Elite Syndicate',
        coin: 'USD',
        amount: 2500,
        roiPercentage: 210, // 185% + 25% Gold boost
        expectedReturn: 5250,
        startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        endDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString(),
        claimed: false,
        isPreLaunchLocked: false
      }
    ],
    transactions: [
      {
        id: 'TX-109482',
        type: 'stake',
        title: '⚡ Staking Vertrag: Elite Syndicate',
        amount: 2500,
        currency: 'USD',
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'TX-109481',
        type: 'earn',
        title: '🎰 Slot Jackpot (💎💎💎)',
        amount: 50000,
        currency: 'NEX',
        timestamp: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'TX-109480',
        type: 'earn',
        title: '📅 Daily Login Bonus (Tag 3)',
        amount: 1800,
        currency: 'NEX',
        timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
      }
    ],
    quests: [
      {
        id: 'q1',
        title: '🚀 Airdrop Pioneer',
        description: 'Sichere dir deinen FreeLaunch Airdrop im Wert von 5.000 Coins.',
        rewardCoins: 5000,
        rewardXp: 500,
        completed: false,
        category: 'milestone',
        progress: 0,
        maxProgress: 1
      },
      {
        id: 'q2',
        title: '⚡ Staking Investor',
        description: 'Schließe deinen ersten Staking-Vertrag ab, um passives Einkommen zu generieren.',
        rewardCoins: 10000,
        rewardXp: 1000,
        completed: true,
        category: 'bounty',
        progress: 1,
        maxProgress: 1
      },
      {
        id: 'q3',
        title: '🎰 Walzen-König',
        description: 'Spiele 10 Runden an der Slot Machine im Minispiele-Tab.',
        rewardCoins: 2500,
        rewardXp: 300,
        completed: false,
        category: 'daily',
        progress: 4,
        maxProgress: 10
      },
      {
        id: 'q4',
        title: '👑 Level 50 Titan',
        description: 'Erreiche Level 50 im Nexus Ökosystem.',
        rewardCoins: 50000,
        rewardXp: 5000,
        completed: false,
        category: 'milestone',
        progress: 18,
        maxProgress: 50
      },
      {
        id: 'q5',
        title: '🐦 Twitter / X Supporter',
        description: 'Teile einen deiner Erfolge via Twitter / X mit deiner Community.',
        rewardCoins: 2000,
        rewardXp: 200,
        completed: false,
        category: 'bounty',
        progress: 0,
        maxProgress: 1
      },
      {
        id: 'q6',
        title: '🤖 Automatisierungs-Meister',
        description: 'Kaufe 5 Auto-Klicker Bots im Coin Klicker Tab.',
        rewardCoins: 15000,
        rewardXp: 1500,
        completed: false,
        category: 'milestone',
        progress: 0,
        maxProgress: 5
      }
    ],
    adminSettings: {
      countdownDays: 142,
      countdownHours: 18,
      countdownMinutes: 42,
      countdownSeconds: 12,
      payAddressBtc: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      payAddressEth: '0x71C...3842',
      payAddressSol: 'Solana...Arena99',
      payAddressUsdt: '0xUSDT...Arena2026',
      adIntervalMinutes: 8,
      adDurationSeconds: 35,
      adClientUrl: 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8842',
      socialYoutube: 'https://youtube.com',
      socialTelegram: 'https://t.me/Nexus_VIP_Support',
      socialDiscord: 'https://discord.com',
      socialReddit: 'https://reddit.com',
      socialX: 'https://x.com',
      socialFacebook: 'https://facebook.com'
    }
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isShareOpen, setIsShareOpen] = useState<boolean>(false);

  const handleQuickDeposit = () => {
    setActiveTab('invest');
  };

  // Sync quest progress based on user state
  React.useEffect(() => {
    setUser(prev => {
      const updatedQuests = prev.quests.map(q => {
        if (q.id === 'q1' && prev.freeLaunchClaimed) {
          return { ...q, progress: 1 };
        }
        if (q.id === 'q4') {
          return { ...q, progress: prev.level };
        }
        if (q.id === 'q6') {
          return { ...q, progress: prev.autoClickerCount };
        }
        return q;
      });
      return { ...prev, quests: updatedQuests };
    });
  }, [user.freeLaunchClaimed, user.level, user.autoClickerCount]);

  // Global passive mining & energy regeneration loop
  React.useEffect(() => {
    const timer = setInterval(() => {
      setUser(prev => {
        // Energy regen
        const newEnergy = Math.min(prev.maxEnergy, prev.energy + 5);

        // Passive profit per hour (divided by 3600 seconds)
        const passiveGain = Math.floor(prev.profitPerHour / 3600);

        // Turbo check
        let newTurbo = prev.turboEndTime;
        if (newTurbo && Date.now() > newTurbo) {
          newTurbo = null;
        }

        return {
          ...prev,
          energy: newEnergy,
          coins: prev.coins + passiveGain,
          turboEndTime: newTurbo
        };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col justify-between font-['Outfit',sans-serif] selection:bg-cyan-500 selection:text-black">
      
      {/* Top Navbar */}
      <Navbar
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenShare={() => setIsShareOpen(true)}
        onQuickDeposit={handleQuickDeposit}
      />

      {/* Main Content Area */}
      <main className="flex-grow">
        
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="space-y-12 pb-16 animate-fade-in">
            <HeroSection
              user={user}
              setUser={setUser}
              setActiveTab={setActiveTab}
              onQuickDeposit={handleQuickDeposit}
              addToast={addToast}
            />

            {/* Quick Feature Navigation Cards */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                
                <div 
                  onClick={() => setActiveTab('clicker')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-cyan-500/30 hover:border-cyan-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-cyan-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
                    <MousePointer className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Coin Klicker</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Klicke auf den Nexus Coin und steige bis auf <span className="text-cyan-400 font-bold">Level 1200</span> auf! Höhere Level maximieren deinen Klick-Profit.
                  </p>
                </div>

                <div 
                  onClick={() => setActiveTab('surveys')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-blue-500/30 hover:border-blue-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-blue-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400 mb-4 group-hover:scale-110 transition-transform">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Offerwall</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Verdiene massig Coins und USD durch verifizierte Partner-Umfragen. Heutiger RNG-Bonus wartet auf dich!
                  </p>
                </div>

                <div 
                  onClick={() => setActiveTab('chests')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-yellow-500/30 hover:border-yellow-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-yellow-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-yellow-500/20 border border-yellow-500/40 flex items-center justify-center text-yellow-400 mb-4 group-hover:scale-110 transition-transform">
                    <Package className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Loot Truhen</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Gestaffeltes Truhensystem. Je mehr du investierst, desto mächtiger ist deine garantierte Krypto-Beute!
                  </p>
                </div>

                <div 
                  onClick={() => setActiveTab('nfts')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 hover:border-purple-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-purple-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 mb-4 group-hover:scale-110 transition-transform">
                    <Award className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">NFT Pässe</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Binde deine NFTs direkt in das Ökosystem ein und aktiviere permanente ROI-Boosts auf alle Staking-Pools.
                  </p>
                </div>

              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                
                <div 
                  onClick={() => setActiveTab('wheel')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-rose-500/30 hover:border-rose-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-rose-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-4 group-hover:scale-110 transition-transform">
                    <Gift className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Glücksrad</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Drehe am Glücksrad und gewinne bis zu 25.000 Coins. Du hast aktuell <span className="text-rose-400 font-bold">{user.spinsLeft} Freispiele</span>!
                  </p>
                </div>

                <div 
                  onClick={() => setActiveTab('minigames')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 hover:border-purple-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-purple-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 mb-4 group-hover:scale-110 transition-transform">
                    <Gamepad2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Minispiele</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Spiele Slots, Crash oder Coinflip. Dein Liga-Status gewährt dir höhere Gewinn-Multiplikatoren!
                  </p>
                </div>

                <div 
                  onClick={() => setActiveTab('invest')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-amber-500/30 hover:border-amber-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-amber-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-4 group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Staking & ROI</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Sichere dir bis zu <span className="text-amber-400 font-bold">240% ROI</span> im Whale Fund. Je mehr du investierst, desto höher die Ausschüttung.
                  </p>
                </div>

                <div 
                  onClick={() => setActiveTab('league')}
                  className="glass-panel p-6 sm:p-8 rounded-3xl border border-yellow-500/30 hover:border-yellow-500/60 cursor-pointer transition-all transform hover:-translate-y-1 group bg-gradient-to-b from-yellow-950/20 to-transparent shadow-xl"
                >
                  <div className="w-12 h-12 rounded-2xl bg-yellow-500/20 border border-yellow-500/40 flex items-center justify-center text-yellow-400 mb-4 group-hover:scale-110 transition-transform">
                    <Award className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] mb-2">Liga Modus</h3>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    Erreiche höhere Stufen durch Aktivität und Staking. Jedes Level-Up steigert deine Rendite!
                  </p>
                </div>

              </div>
            </div>

            <DailyWeeklyRewards
              user={user}
              setUser={setUser}
              onOpenShare={() => setIsShareOpen(true)}
              addToast={addToast}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
              <div 
                onClick={() => setActiveTab('freelaunch')}
                className="glass-panel-premium p-8 rounded-3xl border-2 border-emerald-500/50 cursor-pointer hover:border-emerald-400 transition-all flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl shadow-emerald-500/10"
              >
                <div className="flex items-center gap-4">
                  <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 animate-bounce">
                    <Rocket className="w-8 h-8" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest block mb-1">Airdrop Alert</span>
                    <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-1">
                      FreeLaunch Claim: 5.000 NEXUS Coins
                    </h3>
                    <p className="text-sm text-slate-300">
                      Sichere dir dein kostenloses Startguthaben für die Arena. Nur für kurze Zeit verfügbar!
                    </p>
                  </div>
                </div>

                <button className="px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-base rounded-2xl shadow-lg shadow-emerald-500/30 whitespace-nowrap transform hover:scale-105 transition-all font-['Space_Grotesk']">
                  Jetzt Claimen &rarr;
                </button>
              </div>
            </div>

          </div>
        )}

        {/* Clicker Tab */}
        {activeTab === 'clicker' && (
          <div className="animate-fade-in">
            <CoinClicker
              user={user}
              setUser={setUser}
              onOpenShare={() => setIsShareOpen(true)}
              addToast={addToast}
            />
          </div>
        )}

        {/* League Mode Tab */}
        {activeTab === 'league' && (
          <div className="animate-fade-in">
            <LeagueMode
              user={user}
              onQuickDeposit={handleQuickDeposit}
            />
          </div>
        )}

        {/* Wheel Of Fortune Tab */}
        {activeTab === 'wheel' && (
          <div className="animate-fade-in">
            <WheelOfFortune
              user={user}
              setUser={setUser}
              onOpenShare={() => setIsShareOpen(true)}
              addToast={addToast}
            />
          </div>
        )}

        {/* Mini Games Tab */}
        {activeTab === 'minigames' && (
          <div className="animate-fade-in">
            <MiniGames
              user={user}
              setUser={setUser}
              onOpenShare={() => setIsShareOpen(true)}
              addToast={addToast}
            />
          </div>
        )}

        {/* Investment & Staking Tab */}
        {activeTab === 'invest' && (
          <div className="animate-fade-in">
            <InvestmentStaking
              user={user}
              setUser={setUser}
              onOpenShare={() => setIsShareOpen(true)}
              addToast={addToast}
            />
          </div>
        )}

        {/* Surveys Tab */}
        {activeTab === 'surveys' && (
          <div className="animate-fade-in">
            <SurveysOffers
              user={user}
              setUser={setUser}
              addToast={addToast}
            />
          </div>
        )}

        {/* Chests Tab */}
        {activeTab === 'chests' && (
          <div className="animate-fade-in">
            <LootChests
              user={user}
              setUser={setUser}
              addToast={addToast}
            />
          </div>
        )}

        {/* NFTs Tab */}
        {activeTab === 'nfts' && (
          <div className="animate-fade-in">
            <NftGallery
              user={user}
              setUser={setUser}
              addToast={addToast}
            />
          </div>
        )}

        {/* Quests Tab */}
        {activeTab === 'quests' && (
          <div className="animate-fade-in">
            <Quests
              user={user}
              setUser={setUser}
              addToast={addToast}
            />
          </div>
        )}

        {/* FreeLaunch Tab */}
        {activeTab === 'freelaunch' && (
          <div className="animate-fade-in">
            <FreeLaunch
              user={user}
              setUser={setUser}
              onOpenShare={() => setIsShareOpen(true)}
              addToast={addToast}
            />
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="animate-fade-in">
            <TransactionHistory user={user} />
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="animate-fade-in">
            <AnalyticsAdSenseHub user={user} setUser={setUser} addToast={addToast} />
          </div>
        )}

        {/* Member Area Tab */}
        {activeTab === 'member' && (
          <div className="animate-fade-in">
            <MemberArea user={user} setUser={setUser} addToast={addToast} />
          </div>
        )}

        {/* Admin Area Tab */}
        {activeTab === 'admin' && (
          <div className="animate-fade-in">
            <AdminArea user={user} setUser={setUser} addToast={addToast} />
          </div>
        )}

        {/* Partners Tab */}
        {activeTab === 'partners' && (
          <div className="animate-fade-in">
            <PartnerSection />
          </div>
        )}

      </main>

      {/* Trust Score & 24/7 Community Hub */}
      <TrustCommunityHub />

      {/* Infinite Marquee Partner Slider at the Bottom */}
      <PartnerTicker />

      {/* Footer */}
      <footer className="bg-[#070a12] border-t border-slate-800/80 py-12 text-slate-400 text-xs sm:text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white font-extrabold text-xs shadow-md shadow-cyan-500/20">
              N
            </div>
            <span className="font-extrabold text-white text-base tracking-wider font-['Space_Grotesk']">NEXUS COIN ARENA</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-slate-400">
            <button onClick={() => setActiveTab('dashboard')} className="hover:text-white transition-colors">Dashboard</button>
            <button onClick={() => setActiveTab('clicker')} className="hover:text-white transition-colors">Klicker</button>
            <button onClick={() => setActiveTab('surveys')} className="hover:text-white transition-colors">Offerwall</button>
            <button onClick={() => setActiveTab('chests')} className="hover:text-white transition-colors">Truhen</button>
            <button onClick={() => setActiveTab('nfts')} className="hover:text-white transition-colors">NFTs</button>
            <button onClick={() => setActiveTab('league')} className="hover:text-white transition-colors">Liga</button>
            <button onClick={() => setActiveTab('wheel')} className="hover:text-white transition-colors">Glücksrad</button>
            <button onClick={() => setActiveTab('minigames')} className="hover:text-white transition-colors">Minispiele</button>
            <button onClick={() => setActiveTab('invest')} className="hover:text-white transition-colors">Staking</button>
            <button onClick={() => setActiveTab('quests')} className="hover:text-white transition-colors">Quests</button>
            <button onClick={() => setActiveTab('freelaunch')} className="hover:text-white transition-colors">FreeLaunch</button>
            <button onClick={() => setActiveTab('history')} className="hover:text-white transition-colors">Logbuch</button>
            <button onClick={() => setActiveTab('analytics')} className="hover:text-white transition-colors">Analysen</button>
            <button onClick={() => setActiveTab('member')} className="hover:text-white transition-colors">Mitglieder</button>
            <button onClick={() => setActiveTab('admin')} className="hover:text-white transition-colors">Admin</button>
            <button onClick={() => setActiveTab('partners')} className="hover:text-white transition-colors">Partner werden</button>
          </div>

          <div className="text-slate-500 text-center md:text-right text-xs">
            &copy; {new Date().getFullYear()} Nexus Coin Arena. Alle Rechte vorbehalten. <br />
            Dezentrale Gamification & Hochrendite-Staking Plattform.
          </div>
        </div>
      </footer>

      {/* Ad Overlay */}
      <AdOverlay user={user} addToast={addToast} />

      {/* Share Modal */}
      <ShareModal
        user={user}
        setUser={setUser}
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        addToast={addToast}
      />

      {/* Toast Notifications Container */}
      <ToastContainer toasts={toasts} removeToast={removeToast} />

      {/* Live Community Chat */}
      <LiveChat user={user} setUser={setUser} addToast={addToast} />

      {/* Direct Help AI Chatbot & Disclaimers */}
      <HelpChatbot userId={user.id} />

    </div>
  );
};

export default App;
