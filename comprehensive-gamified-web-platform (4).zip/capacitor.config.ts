import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.nexuscoin.arena',
  appName: 'Nexus Coin Arena',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true
  },
  android: {
    backgroundColor: '#0b0f19',
    allowMixedContent: true,
    buildOptions: {
      keystorePath: 'release.keystore',
      keystoreAlias: 'nexus_alias',
    }
  },
  ios: {
    backgroundColor: '#0b0f19',
    preferredContentMode: 'mobile',
    scheme: 'NexusArena'
  }
};

export default config;
